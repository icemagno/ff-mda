# FF-MDA
Multiparty Deployer Agent for FireFly

Tested with Docker v25.0.3

I'm still working on this... 

![ff-mda](https://github.com/icemagno/ff-mda/assets/4127512/4043efa2-8fd0-4d76-8407-cdaebcdf17c1)

![local-node](https://github.com/icemagno/ff-mda/assets/4127512/8ee5dc03-caca-4063-a809-574f6a8fd3b2)

![register-remote](https://github.com/icemagno/ff-mda/assets/4127512/5ea1284a-0f9a-4198-bfc1-400cf5f4a9dc)

![dx](https://github.com/icemagno/ff-mda/assets/4127512/8f318e6c-795e-44c6-bafb-4a8a0b3b978e)

![postgresql](https://github.com/icemagno/ff-mda/assets/4127512/5516c72a-4975-422e-b115-7eea94932d08)

![graph](https://github.com/icemagno/ff-mda/assets/4127512/15d94996-5b9a-4e15-b49b-14bdc4aca924)

![ipfs](https://github.com/icemagno/ff-mda/assets/4127512/cc3c37a9-7cf3-4e66-83d4-b2d4bee99e62)

![besu](https://github.com/icemagno/ff-mda/assets/4127512/66cec74f-54bd-460e-bf05-c5731849fae7)
