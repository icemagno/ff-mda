#! /bin/sh

docker build --tag=magnoabreu/ffmda-builder:java17 --rm=true .



