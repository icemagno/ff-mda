package br.com.drwars.entites.enums;

public enum TipoTransportelEnum {
    GNC,GNL;
}
