package br.com.drwars.v1.vo;

public class EmpresaResumidaVO {

    private Long id;
    private String cnpj;
    private String razaoSocial;
    private String nomeFatasia;
}
