package br.com.drwars.entites.enums;

public enum OfertaTipoEnum {
    C,V;

}
