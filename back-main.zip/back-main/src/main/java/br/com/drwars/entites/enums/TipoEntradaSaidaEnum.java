package br.com.drwars.entites.enums;

public enum TipoEntradaSaidaEnum {
    A,E,S;
}
