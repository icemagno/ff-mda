# Backend
[![Java CI with Maven](https://github.com/cometa-rj/back/actions/workflows/maven.yml/badge.svg)](https://github.com/cometa-rj/back/actions/workflows/maven.yml)

```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```


# Save image to file ( backup )
```docker save --output="/home/cometa/backend.tar" cometa/backend:1.0```

# Restore image from file
```docker load --input /home/cometa/backend.tar```

# ALL IN ONE PULL-PACKAGE-BUILD-DEPLOY
---

```
cd /home/cometa/back && git pull && mvn clean package && DOCKER_BUILDKIT=1 docker build --tag=cometa/backend:1.0 --rm=true . && docker stop cometa && docker rm cometa && docker run --name cometa --hostname=cometa --network=interna -e DB_HOST=cometa-db -e DB_PORT=5432 -e DB_NAME=cometa -e DB_USER=postgres -e DB_PASSWORD=**** -e BLOCKCHAIN_RPC_ENDPOINT=http://j1scorpii.com.br:8545  -v /srv/calisto:/srv/calisto -v /etc/localtime:/etc/localtime:ro -p 36000:8080 -d cometa/backend:1.0 
```

# Build
```
mvn clean package
DOCKER_BUILDKIT=1 docker build --tag=cometa/backend:1.0 --rm=true .
```
# Deploy
```

docker stop cometa && docker rm cometa

docker run --name cometa --hostname=cometa --network=interna \
-e DB_HOST=cometa-db \
-e DB_PORT=5432 \
-e DB_NAME=cometa \
-e DB_USER=postgres \
-e DB_PASSWORD=**** \
-e BLOCKCHAIN_RPC_ENDPOINT=http://j1scorpii.com.br:8545 \ 
-v /etc/localtime:/etc/localtime:ro \
-v /srv/calisto:/srv/calisto \
-p 36000:8080 \
-d cometa/backend:1.0
```
