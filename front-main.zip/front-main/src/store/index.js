import { createStore } from "vuex";
import { auth } from "./auth.module";
import { offer } from "./offer.module";
import { news } from "./news.module";
import { purchase } from "./purchase.module";

const store = createStore({
  modules: {
    auth,
    offer,
    news,
    purchase
  },
});

export default store;