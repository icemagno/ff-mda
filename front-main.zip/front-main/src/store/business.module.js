import BusinessService from '../services/business.service';

export const business = {
  namespaced: true,
  state: {
    newsId: '',
  },
  actions: {
    
  },
  mutations: {
    setBusinessId(state, businessId) {
      state.businessId = businessId;
    },
  }
};
