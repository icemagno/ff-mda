import OfferService from '../services/offer.service';

export const offer = {
  namespaced: true,
//   state: initialState,
  state: {
    offerId: '',
  },
  actions: {
    register({ commit }, offer) {
      return OfferService.createOffer(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerPublica({ commit }, offer) {
      return OfferService.createOfferPublica(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerBioCert({ commit }, offer) {
      return OfferService.createOfferWithCert(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerCert({ commit }, offer) {
      return OfferService.createOfferCert(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerBuy({ commit }, offer) {
      return OfferService.createOfferBuy(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerBuyPublica({ commit }, offer) {
      return OfferService.createOfferBuyPublica(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerBuyBioCert({ commit }, offer) {
      return OfferService.createBuyOfferWithCert(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },

    registerBuyCert({ commit }, offer) {
      return OfferService.createOfferBuyCert(offer).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    },
  },
  mutations: {
    setOfferId(state, offerId) {
      state.offerId = offerId;
    },
  }
};
