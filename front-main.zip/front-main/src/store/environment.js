
export const environment = {
    API_URL : 'http://146.190.221.30/v1/'
    //API_URL : 'http://146.190.221.30:36000/drwars/api/'
}