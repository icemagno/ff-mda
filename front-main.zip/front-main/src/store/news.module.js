import NewsService from '../services/news.service';

export const news = {
  namespaced: true,
  state: {
    newsId: '',
  },
  actions: {
    register({ commit }, news) {
      return NewsService.register(news).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    }
  },
  mutations: {
    setNewsId(state, newsId) {
      state.newsId = newsId;
    },
  }
};
