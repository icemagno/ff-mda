import PurchaseService from '../services/purchase.service';

export const purchase = {
  namespaced: true,
  state: {
    purchaseId: '',
  },
  actions: {
    // register({ commit }, purchase) {
    //   return PurchaseService.register(purchase).then(
    //     response => {
    //       return Promise.resolve(response.data);
    //     },
    //     error => {
    //       return Promise.reject(error);
    //     }
    //   );
    // }
    saveContrato({ commit }, contrato) {
      return PurchaseService.saveContrato(contrato).then(
        response => {
          return Promise.resolve(response.data);
        },
        error => {
          return Promise.reject(error);
        }
      );
    }
  },
  mutations: {
    setPurchaseId(state, purchaseId) {
      state.purchaseId = purchaseId;
    },
  }
};
