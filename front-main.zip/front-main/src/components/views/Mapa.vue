<template>
  
    <HeaderMain v-if="!currentUser"/>
    <DetalheEmpresa v-show="showEmpresa"  />
    <div class="legenda-mapa-full">
      <LegendaMapa />
    </div>
    <SelectLayerPanel/>
    <div id="map" style="width: 100%; height: 100%; position:absolute"></div>
  
</template>

<script>
import MapaService from '../../services/mapa.service';
import HeaderMain from '../common/HeaderMain.vue';
import DetalheEmpresa from '../common/DetalheEmpresa.vue';
import LegendaMapa from '../common/LegendaMapa.vue';
import SelectLayerPanel from '../common/SelectLayerPanel.vue';

export default {
  name: 'Mapa',
  components: {
    HeaderMain,
    DetalheEmpresa,
    LegendaMapa,
    SelectLayerPanel
  }, 
  data() {
    return {
        showEmpresa: false
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    /*
      --------------------------------------------------------------------------------------------------------------------
        Tive que colocar a carga de script externo porque não sei fazer da forma correta.
        Ver com o Ed como faz.
      --------------------------------------------------------------------------------------------------------------------
    */

    let openlayers = document.createElement('script');
    openlayers.setAttribute('src', 'https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/build/ol.js');
    document.head.appendChild(openlayers);

    let olstyle = document.createElement('link');
    olstyle.setAttribute('href', 'https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/css/ol.css');
    olstyle.setAttribute('type', 'text/css');
    olstyle.setAttribute('rel', 'stylesheet');
    document.head.appendChild(olstyle);
    /*
      --------------------------------------------------------------------------------------------------------------------
    */

    MapaService.getEmpresas().then(
      response => {
        MapaService.prepareMapa( true, response.data, ( empresa ) => {
          this.showEmpresa = true;
          this.emitter.emit('onClickEmpresa', empresa);
        });  
      },
      error => {
        this.content =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
      }
    );
    
  }
};



</script>
