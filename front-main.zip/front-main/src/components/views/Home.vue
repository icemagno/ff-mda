<template>
  <HeaderMain v-if="!currentUser" />
  <div class="container pb-4">
    <div class="row mt-4">
      <div class="col-sm-12 col-md-6">
        <div class="home-section-title">
          <h2>O mercado de<br><span class="color-2">biometano</span></h2>
          <span class="subtitle">no Brasil</span>
        </div>
        <div>
          <img
                src="@/assets/images/illustration-market.png"
                class="float-right"
            >
          <p>No mundo atual, o consenso sobre a necessidade de qualificação exige a precisão e a definição das posturas dos órgãos dirigentes com relação às suas atribuições.</p>
          <p>Por outro lado, o consenso sobre a necessidade de qualificação exige a precisão e a definição dos relacionamentos verticais entre as hierarquias.Gostaria de enfatizar que o desafiador cenário globalizado talvez venha a ressaltar a relatividade dos procedimentos normalmente adotados.</p>
        </div>
        <router-link class="btn btn-primary" :to="{ name: 'mercado' }">
          Saiba Mais
        </router-link>
      </div>
      <div class="col-sm-12 col-md-6">
        <div class="home-section-title">
          <h2>Sobre o<br><span class="color-2">BiometanoTrade</span></h2>
          <span class="subtitle">como funciona a plataforma</span>
        </div>
        <div>
          <img
                src="@/assets/images/illustration-the-app.png"
                class="float-right"
            >
          <p>No mundo atual, o consenso sobre a necessidade de qualificação exige a precisão e a definição das posturas dos órgãos dirigentes com relação às suas atribuições.</p>
          <p>Por outro lado, o consenso sobre a necessidade de qualificação exige a precisão e a definição dos relacionamentos verticais entre as hierarquias.Gostaria de enfatizar que o desafiador cenário globalizado talvez venha a ressaltar a relatividade dos procedimentos normalmente adotados.</p>
        </div>
        <router-link class="btn btn-primary" :to="{ name: 'biometanotrade' }">
          Saiba Mais
        </router-link>
      </div>
    </div>
  </div>
  <div class="container container-full pb-5" style="background: #fff;">
    <div class="container">
      <div>
        <hr class="center-diamond">
      </div>
      <div class="row">
        <div class="col-sm-12 col-md-9">
          <div class="row">
            <div class="col-sm-12 col-md-4">
              <img
                  src="@/assets/images/detalhes-1-home.png"
              >
            </div>
            <div class="col-sm-12 col-md-8">
              <img
                  src="@/assets/images/detalhes-2-home.png"
              >
            </div>
          </div>
          <div class="mt-5 mapa-home">
            <h1 style="color: #00A78E; font-size:20px">Mapa de Fornecedores e Consumidores</h1>
            <MapaSimples />
          </div>
        </div>
        <div class="col-sm-12 col-md-3">
            <h1 style="color: #00A78E; font-size:20px">Últimas notícias</h1>
            <div class="mt-3" v-for="news in lastNews">
              <h3 style="color: #000; font-size:17px">{{news.titulo}}</h3>
              <p>{{news.texto}}</p>
              <a @click="openModal(news)">Saiba Mais</a>
            </div>
            <Modal :activeNews="activeNews" :showModal="modalVisible" @close="modalVisible = false" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import UserService from '../../services/user.service';
import HeaderMain from '../common/HeaderMain.vue';
import MapaSimples from './MapaSimples.vue';
import Modal from '../common/Modal.vue';
import axios from 'axios';
import { environment } from '@/store/environment';

export default {
  name: 'Home',
  components: {
    HeaderMain,
    MapaSimples,
    Modal
  }, 
  data() {
    return {
      lastNews: {},
      activeNews: {}, 
      modalVisible: false
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    this.getLastNews();
  },
  methods: {
    formatDate(inputDate) {
      const date = new Date(inputDate);
      
      // Extract date components
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based
      const year = date.getFullYear();

      // Construct the formatted date string
      const formattedDate = `${day}/${month}/${year}`;

      return formattedDate;
    },
    async getLastNews() {
        try {
          let res = await axios.get(`${environment.API_URL}drwars/api/v1/noticias/aprovadas?page=0&size=3&direction=desc`);
          console.log("noticias home", res.data.content)
          this.lastNews = res.data.content
          this.lastNews.forEach((item) => {
            if (item.texto.length > 150) {
                item.texto = item.texto.substring(0, 150) + '...';
            }
            item.data = this.formatDate(item.data)
        });
        } catch (err) {
            console.log(err);
        }
    },
    openModal(news) {
      this.activeNews = news; 
      this.modalVisible = true;
      console.log("selecionada", this.selectedNews)
      console.log("selecionada", this.modalVisible)
    }
  }
};
</script>
<style scoped lang="scss">
  img {
    max-width: 100%;
  }
  hr {
    border: 0;
    height: 2px;
    width: 30%;
    position: relative;
    margin: 30px auto;
    
    &.center-diamond{
      background: green;
      
      &:before{
        content: "";
        width: 10px;
        height: 10px;
        background: green;
        display: inline-block;
        border: 2px solid green;
        position: absolute;
        top: -3px;
        left: 50%;
        margin: 0 0 0 -3px;
        transform:rotate(45deg);
        -ms-transform:rotate(45deg); /* IE 9 */
        -webkit-transform:rotate(45deg); /* Opera, Chrome, and Safari */
      }
    }
    
    &.center-square{
      background: green;
      
      &:before{
        content: "";
        width: 6px;
        height: 6px;
        background: green;
        display: inline-block;
        border: 2px solid green;
        position: absolute;
        top: -5px;
        left: 50%;
        margin: 0 0 0 -3px;
      }
    }
    
  }
  .subtitle {
      color: #346003;
    }
  .home-section-title {
    h2 {
      color: #78C424;
      font-weight: 900;

      .color-2 {
        color: #46780D;
      }
    }
  }
</style>