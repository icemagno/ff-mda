<template>
  <div class="container loggedin">
    <div class="title d-flex align-items-start pt-4">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3>Ofertas de Compra</h3>
    </div>
    <div class="breadcrumb">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <span class="active"> Ofertas de Compra</span>
    </div>
    <div class="row row-cols-1 row-cols-md-1 row-cols-lg-2">
        <div v-for="offer in offers" :key="offer.id" class="col offer-card">
            <div v-if="offer.ofertaTipo.id == 1 || offer.ofertaTipo.id == 2" class="card card-offer h-100">
                <div class="tag-tipoferta">
                    <span v-if="offer.empresaPrivada">Oferta Exclusiva Para {{offer.empresaPrivada.nomeFatasia}}</span>
                    <span v-else>Oferta Pública</span>
                    <br>
                    <small v-if="offer.ofertaTipo.id == 1">Biometano</small>
                    <small v-if="offer.ofertaTipo.id == 2">Biometano c/ Certificado</small>
                </div>
                <div class="card-header bg-transparent">
                    <div class="row justify-content-between">
                        <div class="d-flex">
                            <div class="icon-box mr-1">
                                <i class='bx bxs-factory'></i>
                            </div>
                            <div>
                                <label>Empresa</label>
                                <template v-if="currentUser.roles == 'CONSUMIDOR'">
                                    <p class="card-data" v-if="offer.exibeNomeEmpresa && currentUser.roles == 'CONSUMIDOR'">{{offer.empresa.nomeFatasia}}</p>
                                    <p class="card-data" v-else>Não Divulgado</p>
                                </template>
                                <template v-else>
                                    <p class="card-data">{{offer.empresa.nomeFatasia}}</p>
                                </template>
                            </div>
                        </div>
                        <div class="px-2">
                            <label>Quantidade total</label>
                            <vue-number class="card-data card-data-masked" v-model="offer.quantidade" v-bind="maskTotalBiometano"></vue-number>
                        </div>
                        <div>
                            <label>Preço<small> (por m³)</small></label>
                            <template v-if="currentUser.roles == 'FORNECEDOR' || currentUser.roles == 'ADMIN'">
                                <template v-if="(offer.exibeNomeEmpresa && currentUser.roles == 'FORNECEDOR') || offer.exibeNomeEmpresa && currentUser.roles == 'ADMIN'" v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                    <p class="card-data" v-if="negotiationItem.idItem === 13">
                                        <!-- Check if idItem is equal to 5 -->
                                        {{ formatAsCurrency(negotiationItem.valor) }}                                    
                                    </p>
                                </template>
                                <p class="card-data" v-else>Não divulgado</p>
                            </template>
                            <template v-if="currentUser.roles == 'CONSUMIDOR'" v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                <p class="card-data" v-if="negotiationItem.idItem === 13">
                                    <!-- Check if idItem is equal to 5 -->
                                    {{ formatAsCurrency(negotiationItem.valor) }}                                    
                                </p>
                            </template>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div>
                        <label>Tipo</label>
                        <p class="card-data">Sazonal (Flexível)</p>
                    </div>
                    <div>
                        <label>Período de fornecimento</label>
                        <div class="d-flex">
                            <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                <p class="card-data" v-if="negotiationItem.idItem === 18">
                                    {{negotiationItem.valor}}                                    
                                </p>
                            </template>
                            <span class="mx-3">até</span>
                            <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                <p class="card-data" v-if="negotiationItem.idItem === 21">
                                    {{negotiationItem.valor}}                                    
                                </p>
                            </template>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-md-5">
                            <label>Fornecimento mensal</label>
                            <table class="table table-borderless table-sm">
                                <tbody>
                                    <tr v-for="monthlyDelivery in offer.listaNegociacaoRodada[0].listaEntregaSazonais">
                                        <td>{{monthlyDelivery.mes}}</td>
                                        <td class="text-right">{{ formatM3(monthlyDelivery.valorMes) }}m³</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col col-md-7">
                            <label class="text-uppercase">Local de Entrega</label>
                            <div>
                                <label>Local</label>
                                <p class="card-data">{{offer.deliveryLocation.nome}}</p>
                                <!--<p class="card-data">{{offer.empresa.endereco.logradouro}} {{offer.empresa.endereco.numero}} {{offer.empresa.endereco.complemento}}. {{offer.empresa.endereco.bairro}}</p>-->
                            </div>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <label>Cidade</label>
                                    <p class="card-data">{{offer.deliveryLocation.endereco.cidade}}</p>
                                    <!--<p class="card-data">{{offer.empresa.endereco.cidade}}</p>-->
                                </div>
                                <div>
                                    <label>UF</label>
                                    <p class="card-data">{{offer.deliveryLocation.endereco.estado}}</p>
                                    <!--<p class="card-data">{{offer.empresa.endereco.estado}}</p>-->
                                </div>
                            </div>
                            <div>
                                <label>Endereço</label>
                                <template v-if="offer.deliveryLocation.endereco.logradouro">
                                    <p class="card-data">{{offer.deliveryLocation.endereco.logradouro}} {{offer.deliveryLocation.endereco.numero}}. {{offer.deliveryLocation.endereco.bairro}}. {{offer.deliveryLocation.endereco.complemento}}</p>
                                </template>
                                <p v-else class="card-data">-</p>
                            </div>
                            <label class="text-uppercase">INFORMAÇÕES DE FRETE</label>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <label>Tipo de frete</label>
                                    <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 14">
                                            {{ negotiationItem.valor }}
                                        </p>
                                    </template>
                                </div>
                                <div>
                                    <label>Logística</label>
                                    <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 15">
                                            {{ negotiationItem.valor }}
                                        </p>
                                    </template>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between">
                                <!--
                                <div>
                                    <label>Meio de transporte</label>
                                    <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 20">
                                            {{ negotiationItem.valor }}
                                        </p>
                                    </template>
                                </div>
                                -->
                                <div>
                                    <label>Preço do frete (por m³)</label>
                                    <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 19">
                                            <!-- Check if idItem is equal to 5 -->
                                            {{ formatAsCurrency(negotiationItem.valor) }}
                                        </p>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-if="currentUser.roles == 'FORNECEDOR' || currentUser.roles == 'ADMIN'" class="card-footer bg-transparent d-flex justify-content-center">
                    <button @click="editItem(offer.id)" class="btn btn-primary position-absolute">Ver Oferta</button>
                </div>
            </div>
            <div v-else class="card card-offer h-100">
                <div class="tag-tipoferta">
                    <span v-if="offer.empresaPrivada">Oferta Exclusiva Para {{offer.empresaPrivada.nomeFatasia}}</span>
                    <span v-else>Oferta Pública</span>
                    <br>
                    <small v-if="offer.ofertaTipo.id == 3">Somente Certificado</small>
                </div>
                <div class="card-header bg-transparent">
                    <div class="row justify-content-between">
                        <div class="d-flex">
                            <div class="icon-box mr-1">
                                <i class='bx bxs-factory'></i>
                            </div>
                            <div>
                                <label>Empresa</label>
                                <!--
                                <p class="card-data" v-if="(offer.exibeNomeEmpresa && currentUser.roles == 'FORNECEDOR') || (offer.exibeNomeEmpresa && currentUser.roles == 'ADMIN')">{{offer.empresa.nomeFatasia}}</p>
                                <p class="card-data" v-else>Não divulgado</p>
                                -->
                                <p class="card-data">{{offer.empresa.nomeFatasia}}</p>
                            </div>
                        </div>
                        <div class="px-2">
                            <label>Quantidade de certificados</label>
                            <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                <p class="card-data" v-if="negotiationItem.idItem === 22">
                                    <!-- Check if idItem is equal to 5 -->
                                    {{negotiationItem.valor}}
                                </p>
                            </template>
                        </div>
                        <div>
                            <label>Preço<small> (por certificado)</small></label>
                            <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                <p class="card-data" v-if="negotiationItem.idItem === 17">
                                    <!-- Check if idItem is equal to 5 -->
                                    {{ formatAsCurrency(negotiationItem.valor) }}
                                </p>
                            </template>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                </div>
                <div v-if="currentUser.roles == 'FORNECEDOR' || currentUser.roles == 'ADMIN'" class="card-footer bg-transparent d-flex justify-content-center">
                    <button @click="editItem(offer.id)" class="btn btn-primary position-absolute">Ver Oferta</button>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import OfferService from '../../services/offer.service';
import LocaisEntregaService from '../../services/locaisentrega.service';
import { component as VueNumber } from '@coders-tm/vue-number-format'

export default {
  name: 'Buy-Offer',
  components: {
    VueNumber,
  },
  data() {
    return {
      content: '',
      page: 0,
      size: 50,
      idTipoOferta: '1,2,3',
      idSituacao: "1",
      tipoOferta: "C",
      offers:{},
      priceMask: {
        decimal: ",",
        separator: ".",
        prefix: "R$",
        suffix: "",
        precision: 2,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      maskTotalBiometano: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      number: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
    };
  },
  computed: {
    // Define a computed property to format the "valor" as currency
    formatAsCurrency() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
            let valueInCentavos = valor;
            let valueInReais = valueInCentavos / 100
            let formattedValue = valueInReais.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
            return formattedValue;
          //return Number(valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        return '';
      };
    },
    formatM3() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
          return Number(valor).toLocaleString('de-DE');
        }
        return '';
      };
    },
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    this.getOffers();
  },
  methods: {
    async getOffers() {
        try {
            const response = await OfferService.getAll(this.page, this.size, this.tipoOferta, this.idSituacao);

            console.log("Ofertas", response.data.content);
            this.offers = response.data.content;
        
            this.offers.forEach((offer) => {
            // Inserting the "teste" property to each offer object
                offer.deliveryLocation = { 
                    descricao: '',
                    endereco: {
                        logradouro: '',
                        numero: '',
                        complemento: '',
                        bairro: '',
                        cep: '',
                        cidade: '',
                        estado: '',
                        pais: '',
                        telefone: '',
                        email: ''
                    },
                    nome: '',
                };
            });
            this.offers.forEach(async (item) => {
                if(item.listaNegociacaoRodada) {
                    const biomethaneMonthlyDelivery = item.listaNegociacaoRodada[0].listaEntregaSazonais
                    const negotiationItems = item.listaNegociacaoRodada[0].listaNegociacaoPropostas
                    
                    for (const negotiation of negotiationItems) {
                        if (negotiation.idItem === 5) {
                            let getDeliverylocation = await this.getLocalEntregaById(negotiation.valor);
                            console.log("location", getDeliverylocation);

                            // Create delivery location object if it doesn't exist
                            item.deliveryLocation = {
                                nome: getDeliverylocation.nome,
                                endereco: {
                                    estado: getDeliverylocation.endereco.estado,
                                    bairro: getDeliverylocation.endereco.bairro,
                                    logradouro: getDeliverylocation.endereco.logradouro,
                                    numero: getDeliverylocation.endereco.numero,
                                    complemento: getDeliverylocation.endereco.complemento
                                }
                            };
                        }
                    }
                    
                    if(biomethaneMonthlyDelivery) {
                        biomethaneMonthlyDelivery.forEach((month) => {
                            if (month.mes == 1) month.mes = "Janeiro"
                            if (month.mes == 2) month.mes = "Fevereiro"
                            if (month.mes == 3) month.mes = "Março"
                            if (month.mes == 4) month.mes = "Abril"
                            if (month.mes == 5) month.mes = "Maio"
                            if (month.mes == 6) month.mes = "Junho"
                            if (month.mes == 7) month.mes = "Julho"
                            if (month.mes == 8) month.mes = "Agosto"
                            if (month.mes == 9) month.mes = "Setembro"
                            if (month.mes == 10) month.mes = "Outubro"
                            if (month.mes == 11) month.mes = "Novembro"
                            if (month.mes == 12) month.mes = "Dezembro"
                            // console.log("entregas mes", month.mes)
                        });
                    }
                }
                
            });
        } catch (error) {
            console.log(error);
        }
    },

    async getLocalEntregaById(id) {
        try {
            
          let res = await LocaisEntregaService.getById(id);
          //console.log("local de entrega", res.data)
          return res.data
          

        } catch (err) {
            console.log(err);
        }
    },

    editItem(itemId) {
        this.$store.commit('offer/setOfferId', itemId);
        this.$router.push({ name: "edit-item"});
        // OfferService.editItem(itemId).then(
        //     response => {
        //         console.log("Ofertas editar", response.data)
        //         this.$router.push({ name: 'edit-item', params: { itemData: response.data, itemId: response.data.id } });
        //     },
        //     error => {
        //         console.log("Erro", error)
        //         // this.content =
        //         //   (error.response && error.response.data && error.response.data.message) ||
        //         //   error.message ||
        //         //   error.toString();
        //     }
        // );
    }
  }
};
</script>

<style lang="scss" scoped>
    @import '../../assets/styles/variables';
    .tag-tipoferta {
        position: absolute; left:0;
        right:0;
        margin-left:auto;
        margin-right:auto;
        top: -32px;
        background: rgb(226 236 243);
        color: rgb(3 78 134);
        padding: 3px 10px;
        font-weight: 600;
        box-shadow: 0px 7px 15px -16px #000;
        text-align: center;
        font-size: 14px;
        border-radius: 10px;
    }
    .offer-card {
        margin-bottom: 80px !important
    }
    .card{
        &.card-offer {
            padding: 10px;
            font-size: 0.9rem;
            label {
                font-weight: 600;
            }
            .table {
                font-weight: 300;
                font-size: 0.9rem;
                color: #666565;
                line-height: 0.7rem;
            }
            .card-data {
                font-weight: 300;
                font-size: 0.9rem;
            }
            .card-data-masked {
                font-weight: 300;
                font-size: 0.9rem;
                display: block;
                border: 0;
                width: 180px
            }
            .card-header {
                label {
                    color: $secondary-complementary-color;
                    font-weight: 600;
                }
                .card-data {
                    color: $secondary-complementary-color;
                    font-weight: 300;
                    font-size: 1.2rem;
                }
            }
        }
    }
</style>