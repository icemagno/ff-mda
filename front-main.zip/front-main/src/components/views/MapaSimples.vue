<template>
  
    <HeaderMain v-if="!currentUser"/>
    <LegendaMapa />
    <div id="map" style="width: 100%; height: 100%;"></div>
  
</template>

<script>
import MapaService from '../../services/mapa.service';
import HeaderMain from '../common/HeaderMain.vue';
import LegendaMapa from '../common/LegendaMapa.vue';

export default {
  name: 'MapaSimples',
  components: {
    HeaderMain,
    LegendaMapa
  }, 
  data() {
    return {
        showEmpresa: false
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    /*
      --------------------------------------------------------------------------------------------------------------------
        Tive que colocar a carga de script externo porque não sei fazer da forma correta.
        Ver com o Ed como faz.
      --------------------------------------------------------------------------------------------------------------------
    */

    let openlayers = document.createElement('script');
    openlayers.setAttribute('src', 'https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/build/ol.js');
    document.head.appendChild(openlayers);

    let olstyle = document.createElement('link');
    olstyle.setAttribute('href', 'https://cdn.rawgit.com/openlayers/openlayers.github.io/master/en/v5.3.0/css/ol.css');
    olstyle.setAttribute('type', 'text/css');
    olstyle.setAttribute('rel', 'stylesheet');
    document.head.appendChild(olstyle);
    /*
      --------------------------------------------------------------------------------------------------------------------
    */

    MapaService.getEmpresas().then(
      response => {
        MapaService.prepareMapa( false, response.data, ( empresa ) => {
          this.showEmpresa = true;
        });  
      },
      error => {
        this.content =
          (error.response && error.response.data && error.response.data.message) ||
          error.message ||
          error.toString();
      }
    );
    
  }
};

</script>

<style lang="scss" scoped>

  #content-container {
    height: calc(100vh - 95px);
  }
  .mapa-home {
      .navbar {
        display: none;
      }
  }
</style>