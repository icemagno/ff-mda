<template>

  <div class="container pl-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link :to="{ name: 'offers' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3>Cadastrar Oferta de Compra de Certificado</h3>
    </div>
    <div class="breadcrumb">
    
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link :to="{ name: 'buyOffers' }">
        <span class="mr-1"> Ofertas de compra > </span>
      </router-link>
      <span class="active"> Cadastrar oferta de compra de certificado</span>
    
    </div>
    <Form @submit="handleRegister">
      <div class="form-row">
        <div class="col-sm-12 col-md-auto mr-4">
          <label>Oferta pública ou privada?</label>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="offerType" type="radio" value="publica" v-model="offerType"  />
            <label class="form-check-label">
              Pública
            </label>
          </div>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="offerType" type="radio" value="privada" v-model="offerType" />
            <label class="form-check-label">
              Privada
            </label>
          </div>
        </div>
        <div class="col-sm-12 col-md-auto" v-if="offerType == 'publica'">
          <label>Exibir nome da empresa e preço na oferta?</label>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="exibeNomeEmpresa" type="radio" value="true" v-model="showCompanyName"/>
            <label class="form-check-label">
              Sim
            </label>
          </div>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="exibeNomeEmpresa" type="radio" value="false" v-model="showCompanyName"/>
            <label class="form-check-label">
              Não
            </label>
          </div>
        </div>
      </div>
      <div class="form-row" v-if="offerType == 'privada'">
        <div class="col-sm-12 col-md-4">
          <label>Enviar oferta para (Nome da Empresa)</label>
          <div class="input-group mb-2 mr-sm-2">
            <select class="form-control" name="company" as="select" v-model="selectedCompany">
              <option v-for="company in companies" :key="company.id" :value="company">{{company.nomeFatasia}}</option>
            </select>
          </div>
        </div>
        <div class="col-sm-12 col-md-8">
          <label>Razão Social</label>
          <Field class="form-control" name="razao-social" type="text" v-model="selectedCompany.razaoSocial" readonly />
        </div>
      </div>
      <div class="mt-5">
        <h5 class="form-section-title">Informações do certificado</h5>
        <div class="row justify-content-between">
          <div class="col-sm-12 col-md-12">
            <div>
              <div class="row">
                <div class="col-sm-12 col-md-4">
                  <label>Quantidade de certificados</label>
                  <Field class="form-control" v-model="offerData.qntCertificados" name="qntCertificado" type="number" min="0" />
                </div>
                <div class="col-sm-12 col-md-4">
                  <label>Preço (por certificado)</label>
                  <vue-number class="form-control" v-model="offerData.certPrice" name="precoCertificado" v-bind="priceMask"></vue-number>
                </div>
                <div class="col-sm-12 col-md-4">
                  <label for="preco-total">Preço total da oferta</label>
                  <vue-number class="form-control" v-model="certTotalPrice" name="precoTotal" v-bind="priceMask" readonly></vue-number>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        v-if="message"
        class="alert mt-5"
        :class="successful ? 'alert-success' : 'alert-danger'"
      >
        {{ message }}
      </div>
      <div class="d-flex justify-content-center mt-5 pb-5">
          <button class="btn btn-primary mr-3">Salvar oferta</button>
          <router-link class="btn btn-secondary" :to="{ name: 'offers' }">
            <span class="mr-1"> Voltar </span>
          </router-link>
      </div>
    </Form>
    
  </div>
</template>

<script>
import { Form, Field, ErrorMessage } from "vee-validate";
import * as yup from "yup";
import Calendar from '@/components/common/CalendarInput.vue';
import { vMaska } from "maska";
import { component as VueNumber } from '@coders-tm/vue-number-format'
import BusinessService from '../../../services/business.service';
import axios from 'axios';

export default {
  name: "create-offer-cert",
  components: {
    Form,
    Field,
    ErrorMessage,
    Calendar,
    VueNumber,
  },
  directives: { maska: vMaska},
  data() {
    

    return {
      successful: false,
      loading: false,
      message: "",
      offerType: 'publica',
      showCompanyName: "true",
      companies: {},
      offerData: {
        certPrice: 0,
        qntCertificados: 0,
      },
      priceMask: {
        decimal: ",",
        separator: ".",
        prefix: "R$",
        suffix: "",
        precision: 2,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      maskTotalBiometano: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      number: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      monthValues: [
        { month: 1, qty: 0, legend: 'JAN'},
        { month: 2, qty: 0, legend: 'FEV'},
        { month: 3, qty: 0, legend: 'MAR'},
        { month: 4, qty: 0, legend: 'ABR'},
        { month: 5, qty: 0, legend: 'MAI'},
        { month: 6, qty: 0, legend: 'JUN'},
        { month: 7, qty: 0, legend: 'JUL'},
        { month: 8, qty: 0, legend: 'AGO'},
        { month: 9, qty: 0, legend: 'SET'},
        { month: 10, qty: 0, legend: 'OUT'},
        { month: 11, qty: 0, legend: 'NOV'},
        { month: 12, qty: 0, legend: 'DEZ'}
      ],
      deliveryLocations: [
        {
          name: "Local 1",
          desc: "Descrição do local",
          address: "Rua do carmo",
          city: "Rio de Janeiro",
          state: "RJ",
        },
        {
          name: "Local 2",
          desc: "Descrição do local 2",
          address: "Rua dos Andradas",
          city: "Rio de Janeiro",
          state: "RJ",
        },
      ],
      selectedLocation: {
        name: "",
        desc: "",
        address: "",
        city: "",
        state: "",
      },
      selectedCompany: {}
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    certTotalPrice() {
      
      let certTotal = Number(this.offerData.qntCertificados);
      console.log("total de certificados", certTotal);
      console.log("calculo do preço total", this.offerData.certPrice);
      let maskedNumber = this.offerData.certPrice.toString();
      let removeMask = maskedNumber.replaceAll(".","").replaceAll(",","").replace("R$","");
      let removeMaskToNumber = Number(removeMask);
      let total = certTotal * removeMaskToNumber;

      console.log("calculo do preço total", total)

      return total;
    },
    processedMonths() {
      const processed = [];
      const tempArray = [...this.monthValues];

      while (tempArray.length > 0) {
        processed.push(tempArray.splice(0, 2));
      }

      return processed;
    }
  },
  mounted() {
    this.getCompanies();
  },
  watch: {
    offerType(newVal) {
      // You can perform additional actions when the selected option changes
      if(newVal == "publica") {
        this.selectedCompany = {};
      }
      console.log('Selected Option:', newVal);
    },
  },
  methods: {
    setSelectedLocation(data) {
    },
    getCompanies() {
        BusinessService.getAllWithoutLoggedCompany('2,3').then(
            response => {
                console.log("Empresas", response.data.content)
                this.companies = response.data.content
            },
            error => {
                console.log("Erro", error)
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    handleRegister(offer) {
      let maskedNumber = this.offerData.certPrice.toString();
      let removeMask = maskedNumber.replaceAll(".","").replaceAll(",","").replace("R$","");
      let removeMaskToNumber = Number(removeMask);
      
      offer.precoCertificado = removeMaskToNumber;
      offer.empresaPrivadaId = this.selectedCompany.id ? this.selectedCompany.id : null;
      if (offer.qntCertificado === 0 || offer.qntCertificado == null) {
        this.successful = false;
        this.message = "Informe um valor no campo 'Quantidade de certificados'";
        return
      }
      if (offer.precoCertificado === 0) {
        this.successful = false;
        this.message = "Informe um valor no campo 'Preço (por certificado)'";
        return
      }
      // console.log("registra oferta", offer);
      //console.log("envio da oferta", offer)
      this.message = "";

      this.loading = true;

      this.$store.dispatch("offer/registerBuyCert", offer).then(
        (data) => {
          this.message = "Oferta Cadastrada com Sucesso.";
          this.successful = true;
          this.loading = false;
          this.offerData.qntCertificados = 0;
          this.offerData.certPrice = 0;
        },
        (error) => {
          console.log("erro registra oferta de compra de certificado", error)
          this.message =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          this.successful = false;
          this.loading = false;
        }
      );
    },
    
  },
};
</script>

<style scoped lang="scss">
label {
  display: block;
  margin-top: 10px;
}
.form-section-title {
  font-size: 1.1rem;
  font-weight: 400;
  text-transform: uppercase;
}
small {
  font-size: 0.7rem;
}

.fieldset {
  border: 1px solid #ccc;
  border-radius: 8px;
  legend {
    font-weight: 400;
    font-size: 15px;
    width: auto;
    min-width: auto;
    padding: 0 15px 0 5px;
    margin-left: 7px;
  }
}

.card-container.card {
  max-width: 450px !important;
  padding: 40px 40px;
}

.card {
  background-color: #fff;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  margin-top: 50px;
  -moz-border-radius: 10px;
  -webkit-border-radius: 10px;
  border-radius: 10px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
}

.profile-img-card {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
}

.error-feedback {
  color: red;
}
a {
  cursor: pointer
}

</style>
