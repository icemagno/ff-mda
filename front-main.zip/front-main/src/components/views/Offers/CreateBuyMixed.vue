<template>

  <div class="container pl-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link :to="{ name: 'offers' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3>Cadastrar Oferta de Compra de Biometano com Certificado</h3>
    </div>
    <div class="breadcrumb">
    
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link :to="{ name: 'buyOffers' }">
        <span class="mr-1"> Ofertas de compra > </span>
      </router-link>
      <span class="active"> Cadastrar oferta de compra de biometano com certificado</span>
    
    </div>
    <Form @submit="handleRegister">
      <div class="form-row">
        <div class="col-sm-12 col-md-auto mr-4">
          <label style="text-transform: none;">Oferta Pública ou Privada?</label>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="offerType" type="radio" value="publica" v-model="offerType" />
            <label class="form-check-label">
              Pública
            </label>
          </div>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="offerType" type="radio" value="privada" v-model="offerType" />
            <label class="form-check-label">
              Privada
            </label>
          </div>
        </div>
        <div class="col-sm-12 col-md-auto" v-if="offerType == 'publica'">
          <label style="text-transform: none;">Exibir Nome da Empresa e Preço na Oferta?</label>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="exibeNomeEmpresa" type="radio" value="true" v-model="showCompanyName" />
            <label class="form-check-label">
              Sim
            </label>
          </div>
          <div class="form-check form-check-inline">
            <Field class="form-check-input" name="exibeNomeEmpresa" type="radio" value="false" v-model="showCompanyName" />
            <label class="form-check-label">
              Não
            </label>
          </div>
        </div>
      </div>
      <div class="form-row" v-if="offerType == 'privada'">
        <div class="col-sm-12 col-md-4">
          <label style="text-transform: none;">Enviar Oferta Para (Nome da Empresa)</label>
          <div class="input-group mb-2 mr-sm-2">
            <select class="form-control" name="company" as="select" v-model="selectedCompany">
              <option v-for="company in companies" :key="company.id" :value="company">{{company.nomeFatasia}}</option>
            </select>
          </div>
        </div>
        <div class="col-sm-12 col-md-8">
          <label>Razão Social</label>
          <Field class="form-control" name="razao-social" type="text" v-model="selectedCompany.razaoSocial" readonly />
        </div>
      </div>
      <div class="mt-5">
        <h5 class="form-section-title" style="text-transform: none;">Informações de Entrega</h5>
        <div class="row justify-content-center">
          <div class="col-sm-12 col-md-auto">
            <label style="text-transform: none;">Tipo de Frete</label>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" name="tipoFrete" type="radio" value="CIF" v-model="offerData.deliverryType" />
              <label class="form-check-label">
                CIF
              </label>
            </div>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" name="tipoFrete" type="radio" value="FOB" v-model="offerData.deliverryType" />
              <label class="form-check-label">
                FOB
              </label>
            </div>
          </div>
          <div class="col-sm-12 col-md-auto">
            <label>Logística</label>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" type="radio" name="logistica" value="duto transporte" v-model="offerData.logType" />
              <label class="form-check-label" style="text-transform: none;">
                Duto de Transporte
              </label>
            </div>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" type="radio" name="logistica" value="duto distribuicao" v-model="offerData.logType" />
              <label class="form-check-label" style="text-transform: none;">
                Duto de Distribuição
              </label>
            </div>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" type="radio" name="logistica" value="GNC" v-model="offerData.logType" />
              <label class="form-check-label">
                GNC
              </label>
            </div>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" type="radio" name="logistica" value="GNL" v-model="offerData.logType" />
              <label class="form-check-label">
                GNL
              </label>
            </div>
          </div>
          <div class="col-sm-12 col-md-3">
            <label style="text-transform: none;">Valor do Frete (Por m³)</label>
            <vue-number class="form-control" v-model="offerData.shippingPrice" name="precofrete" v-bind="priceMask"></vue-number>
            <!--
            <Field class="form-control" name="valorFrete" type="text" id="valor-frete"  />
            -->
          </div>
        </div>
        <div class="form-row">
          <div class="col-sm-12 col-md-4">
            <label style="text-transform: none;">Local de Entrega</label>
            <div class="input-group mb-2 mr-sm-2">
              <select class="form-control" name="locationName" as="select" v-model="selectedLocation">
                <option v-for="location in deliveryLocations" :key="location.nome" :value="location">{{location.nome}}</option>
              </select>
              <!--
              <div class="input-group-prepend">
                <button class="btn btn-primary ml-1"><i class="bi bi-plus-square"></i></button>
              </div>
              -->
            </div>
          </div>
          <div class="col-sm-12 col-md-8">
            <label for="desc">Descrição</label>
            <Field class="form-control" name="desc" type="text" id="desc" v-model="selectedLocation.descricao" readonly />
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <label for="address">Endereço</label>
            <Field class="form-control" name="address" type="text" id="address" v-model="selectedLocation.endereco.logradouro" readonly />
          </div>
          <div class="col-sm-12 col-md-4">
            <label for="city">Cidade</label>
            <Field class="form-control" name="city" type="text" id="city" v-model="selectedLocation.endereco.cidade" readonly />
          </div>
          <div class="col-sm-12 col-md-2">
            <label for="state">UF</label>
            <Field class="form-control" name="state" type="text" id="state" v-model="selectedLocation.endereco.estado" readonly />
          </div>
        </div>
      </div>
      <div class="mt-5">
        <h5 class="form-section-title" style="text-transform: none;">Informações de Fornecimento</h5>
        <div class="row justify-content-between">
          <div class="col-sm-12 col-md-5">
            <div class="row">
              <div class="col-sm-12 col-md-auto">
                <label>Modalidade</label>
                <div class="form-check form-check-inline">
                  <Field class="form-check-input" name="modalidade" type="radio" value="S" v-model="offerData.modality" />
                  <label class="form-check-label">
                    Firme
                  </label>
                </div>
                <div class="form-check form-check-inline">
                  <Field class="form-check-input" name="modalidade" type="radio" value="N" v-model="offerData.modality" />
                  <label class="form-check-label">
                    Flexível
                  </label>
                </div>
              </div>
              <div class="col-sm-12 col-md-auto">
                <label>Tipo</label>
                <div class="form-check form-check-inline">
                  <Field class="form-check-input" type="radio" name="tipoFornecimento" value="S" v-model="offerData.supplyType" />
                  <label class="form-check-label">
                    Sazonal
                  </label>
                </div>
                <div class="form-check form-check-inline">
                  <Field class="form-check-input" type="radio" name="tipoFornecimento" value="N" v-model="offerData.supplyType" />
                  <label class="form-check-label">
                    Contínua
                  </label>
                </div>
              </div>
            </div>
            <div>
              <label style="text-transform: none;">Período de Fornecimento</label>
              <div class="row">
                <div class="col-sm-12 col-md-6">
                  <Field class="form-control" type="text" name="inicioFornecimento" v-maska data-maska="##/##/####" v-model="startDate"/>
                  <!--
                  <Calendar placeholder="de"/>
                  -->
                </div>
                <div class="col-sm-12 col-md-6">
                  <Field class="form-control" type="text" name="fimFornecimento" v-maska data-maska="##/##/####" v-model="endDate"/>
                  <!--
                  <Calendar placeholder="até"/>
                  -->
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12">
                  <label for="total-biometano" style="text-transform: none;">Total de Biometano no Período</label>
                  <vue-number class="form-control" name="totalBiometano" v-model="biomethaneTotal" v-bind="maskTotalBiometano" readonly></vue-number>
                  <!--
                  <Field class="form-control" name="totalBiometano" v-model="opa" type="text" id="total-biometano"  />
                  -->
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12 col-md-6">
                  <label for="preco-m3" style="text-transform: none;">Valor do Biometano <small>(Por m³)</small></label>
                  <!--
                  <Field class="form-control" name="precoM3" type="text" id="preco-m3"  />
                  -->
                  <vue-number class="form-control" v-model="offerData.biomethanePrice" name="precoBiometano" v-bind="priceMask"></vue-number>
                </div>
                <div class="col-sm-12 col-md-6">
                  <label for="preco-total" style="text-transform: none;">Valor Total do Biometano</label>
                  <vue-number class="form-control" v-model="biomethaneTotalPrice" name="precoTotal" v-bind="priceMask" readonly></vue-number>
                  <!--
                  <Field class="form-control" name="totalPreco" type="text" id="preco-total"  />
                  -->
                </div>
              </div>
              <div class="row">
                <div class="col-sm-12 col-md-6">
                  <label for="preco-m3" style="text-transform: none;">N de Certificados</label>
                  <Field class="form-control" type="number" name="qntCertificado" />
                </div>
                <div class="col-sm-12 col-md-6">
                  <label for="preco-m3" style="text-transform: none;">Preço por Certificado</label>
                  <vue-number class="form-control" v-model="offerData.biomethaneWithCertPrice" name="precoBiometanoCertificado" v-bind="priceMask"></vue-number>
                </div>
              </div>
              <!--
              <div class="row">
                <div class="col-sm-12 col-md-4">
                  <div class="custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="customSwitch1">
                    <label class="custom-control-label" for="customSwitch1">oferta com<br>certificado</label>
                  </div>
                </div>
                <div class="col-sm-12 col-md-4">
                  <label for="preco-m3">Qnt de certificados</label>
                  <Field class="form-control" name="precoM3" type="text" id="preco-m3"  />
                </div>
                <div class="col-sm-12 col-md-4">
                  <label for="preco-total">Preço por certificado</label>
                  <Field class="form-control" name="totalPreco" type="text" id="preco-total"  />
                </div>
              </div>
              -->
            </div>
          </div>
          <div class="col-sm-12 col-md-6">
            <label style="text-transform: none;">Quantidades de Biometano</label>
            <table class="monthly-biomethane">
              <tbody>
                <tr v-for="(month, index) in processedMonths" :key="index">
                  <td class="p-2" v-for="(item, columnIndex) in month" :key="columnIndex">
                    <div v-if="item" style="display: flex; align-items: center;">
                      <span class="pr-1" style="width:55px">{{ item.legend }}</span>
                      <vue-number class="form-control" :name="item.legend" v-model="item.qty" @input="handleInputChange(item)" v-bind="number"></vue-number>
                    </div>
                  </td>
                </tr>
                <!--
                <tr v-for="month in monthValues" :key="month.month">
                  <td>{{month.legend}}</td>
                  <td class="pr-5">
                    <vue-number class="form-control" :name="month.legend" v-model="month.qty" @input="handleInputChange(month)" v-bind="number"></vue-number>
                  </td>
                </tr>
                
                <tr>
                  <td>JAN</td>
                  <td class="pr-5"><Field class="form-control" name="qntBiometano1" type="text" /></td>
                  <td>JUL</td>
                  <td><Field class="form-control" name="qntBiometano7" type="text" /></td>
                </tr>
                <tr>
                  <td>FEV</td>
                  <td class="pr-5"><Field class="form-control" name="qntBiometano2" type="text" /></td>
                  <td>AGO</td>
                  <td><Field class="form-control" name="qntBiometano8" type="text" /></td>
                </tr>
                <tr>
                  <td>MAR</td>
                  <td class="pr-5"><Field class="form-control" name="qntBiometano3" type="text" /></td>
                  <td>SET</td>
                  <td><Field class="form-control" name="qntBiometano9" type="text" /></td>
                </tr>
                <tr>
                  <td>ABR</td>
                  <td class="pr-5"><Field class="form-control" name="qntBiometano4" type="text" /></td>
                  <td>OUT</td>
                  <td><Field class="form-control" name="qntBiometano10" type="text" /></td>
                </tr>
                <tr>
                  <td>MAI</td>
                  <td class="pr-5"><Field class="form-control" name="qntBiometano5" type="text" /></td>
                  <td>NOV</td>
                  <td><Field class="form-control" name="qntBiometano11" type="text" /></td>
                </tr>
                <tr>
                  <td>JUN</td>
                  <td class="pr-5"><Field class="form-control" name="qntBiometano6" type="text" /></td>
                  <td>DEZ</td>
                  <td><Field class="form-control" name="qntBiometano12" type="text" /></td>
                </tr>
                -->
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div
        v-if="message"
        class="alert"
        :class="successful ? 'alert-success' : 'alert-danger'"
      >
        {{ message }}
      </div>
      <div class="d-flex justify-content-center mt-5 pb-5">
          <button class="btn btn-primary mr-3">Salvar oferta</button>
          <button class="btn btn-secondary">Voltar</button>
      </div>
    </Form>
    
  </div>
</template>

<script>
import BusinessService from '../../../services/business.service';
import OfferService from '../../../services/offer.service';
import { Form, Field, ErrorMessage } from "vee-validate";
import * as yup from "yup";
import Calendar from '@/components/common/CalendarInput.vue';
import { vMaska } from "maska";
import { component as VueNumber } from '@coders-tm/vue-number-format'
import axios from 'axios';

export default {
  name: "create-offer-mixed",
  components: {
    Form,
    Field,
    ErrorMessage,
    Calendar,
    VueNumber,
  },
  directives: { maska: vMaska},
  data() {
    

    return {
      successful: false,
      loading: false,
      message: "",
      showCompanyName: "true",
      startDate: "",
      endDate: "",
      offerType: 'publica',
      companies: {},
      offerData: {
        biomethaneTotal: 0,
        biomethanePrice: 0,
        biomethaneTotalPrice: 0,
        biomethaneWithCertPrice: 0,
        shippingPrice: 0,
        certPrice: 0,
        deliverryType: "CIF",
        logType: "duto transporte",
        modality: "S",
        supplyType: "S"
      },
      priceMask: {
        decimal: ",",
        separator: ".",
        prefix: "R$",
        suffix: "",
        precision: 2,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      maskTotalBiometano: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      number: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      monthValues: [
        { month: 1, qty: 0, legend: 'JAN'},
        { month: 2, qty: 0, legend: 'FEV'},
        { month: 3, qty: 0, legend: 'MAR'},
        { month: 4, qty: 0, legend: 'ABR'},
        { month: 5, qty: 0, legend: 'MAI'},
        { month: 6, qty: 0, legend: 'JUN'},
        { month: 7, qty: 0, legend: 'JUL'},
        { month: 8, qty: 0, legend: 'AGO'},
        { month: 9, qty: 0, legend: 'SET'},
        { month: 10, qty: 0, legend: 'OUT'},
        { month: 11, qty: 0, legend: 'NOV'},
        { month: 12, qty: 0, legend: 'DEZ'}
      ],
      deliveryLocations: {},
      selectedLocation: {
        id: "",
        nome: "",
        descricao: "",
        endereco: {
          bairro: "",
          cidade: "",
          complemento: "",
          estado: "",
          logradouro: "",
          numero: "",
        }
      },
      selectedCompany: {}
    };
  },
  watch: {
    offerType(newVal) {
      // You can perform additional actions when the selected option changes
      if(newVal == "publica") {
        this.selectedCompany = {};
      }
      console.log('Selected Option:', newVal);
    },
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    biomethaneTotal() {
      const [startDay, startMonth, startYear] = this.startDate.split('/').map(Number);
      const [endDay, endMonth, endYear] = this.endDate.split('/').map(Number);

      const start = new Date(startYear, startMonth - 1, startDay);
      const end = new Date(endYear, endMonth - 1, endDay);

      let totalSum = 0;

      while (start <= end) {
        const month = start.getMonth() + 1; // getMonth() returns zero-based month
        const year = start.getFullYear();

        const monthValue = this.monthValues.find(entry => entry.month === month);
        if (monthValue) {
          let maskedNumber = monthValue.qty.toString();
          let removeMask = maskedNumber.replaceAll(".","").replace("m³","");
          let removeMaskToNumber = Number(removeMask);
          console.log("valor", removeMaskToNumber)
          totalSum += removeMaskToNumber;
        }

        start.setMonth(start.getMonth() + 1); // Move to the next month
      }
      
      this.offerData.biomethaneTotal = totalSum

      return totalSum;
    },
    biomethaneTotalPrice() {
      
      let biomethaneTotal = this.offerData.biomethaneTotal;
      console.log("calculo do preço total", biomethaneTotal);
      console.log("calculo do preço total", this.offerData.biomethanePrice);
      let maskedNumber = this.offerData.biomethanePrice.toString();
      let removeMask = maskedNumber.replaceAll(".","").replaceAll(",","").replace("R$","");
      let removeMaskToNumber = Number(removeMask);
      let total = biomethaneTotal * removeMaskToNumber;

      console.log("calculo do preço total", total)

      return total;
    },
    processedMonths() {
      const processed = [];
      const tempArray = [...this.monthValues];

      while (tempArray.length > 0) {
        processed.push(tempArray.splice(0, 2));
      }

      return processed;
    }
  },
  mounted() {
    this.getLocaisEntrega();
    this.getCompanies();
    this.setTodayDate();
  },
  methods: {
    getLocaisEntrega() {
        OfferService.getAllLocaisEntrega().then(
            response => {
                console.log("locais de entrega", response.data)
                this.deliveryLocations = response.data;
            },
            error => {
                console.log("Erro", error)
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    setSelectedLocation(data) {
      
    },
    getCompanies() {
        BusinessService.getAllWithoutLoggedCompany('2,3').then(
            response => {
                console.log("Empresas", response.data.content)
                this.companies = response.data.content
            },
            error => {
                console.log("Erro", error)
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    handleInputChange(month) {
      // This method will be called whenever the Field input changes
      console.log(`Input changed for ${month.legend}. New value: ${month.qty}`);

      // You can perform additional operations here based on the input change
      // For example, you can call a specific method or update other data properties.
    },
    handleDateChange(data) {
      // This method will be called whenever the Field input changes
      console.log(`Input changed for ${data}`);

      // You can perform additional operations here based on the input change
      // For example, you can call a specific method or update other data properties.
    },
    getConversationStateDate(value) {
      console.log('data incio conversa', value);
      emit('date', { type: 'date', value });
    },
    setTodayDate(){
      let today = new Date();
      let dd = String(today.getDate()).padStart(2, '0');
      let mm = String(today.getMonth() + 1).padStart(2, '0');
      let yyyy = today.getFullYear();
      let nextyear = today.getFullYear() + 1;
      today = dd + '/' + mm + '/' + yyyy;
      this.startDate = today;
      this.endDate = dd + '/' + mm + '/' + nextyear;
    },
    compareDates(dateString1, dateString2) {
      // Parse the date strings into Date objects
      const date1Parts = dateString1.split('/');
      const date2Parts = dateString2.split('/');
      
      // Note: Months are 0-indexed in JavaScript Dates, so subtract 1 from the month value
      const date1 = new Date(date1Parts[2], date1Parts[1] - 1, date1Parts[0]);
      const date2 = new Date(date2Parts[2], date2Parts[1] - 1, date2Parts[0]);

      // Compare the dates
      if (date1 < date2) {
        return -1; // dateString1 is earlier than dateString2
      } else if (date1 > date2) {
        return 1; // dateString1 is later than dateString2
      } else {
        return 0; // Both dates are equal
      }
    },
    handleRegister(offer) {
      this.monthValues.forEach((month) => {
          let maskedNumber = month.qty.toString();
          let removeMask = maskedNumber.replaceAll(".","").replace("m³","");
          let removeMaskToNumber = Number(removeMask);
          month.qty = removeMaskToNumber
      });
      offer.entregasSazonais = this.monthValues;
      offer.precoBiometano = this.offerData.biomethanePrice;
      offer.precoTotalBiometano = this.biomethaneTotalPrice;
      offer.totalBiometano = this.biomethaneTotal;
      offer.precoFrete = this.offerData.shippingPrice;
      offer.precoCertificado = this.offerData.certPrice;
      offer.localEntregaId = this.selectedLocation.id
      let today = new Date();
      let dd = String(today.getDate()).padStart(2, '0');
      let mm = String(today.getMonth() + 1).padStart(2, '0');
      let yyyy = today.getFullYear();
      today = dd + '/' + mm + '/' + yyyy;
      const resultDates = this.compareDates(offer.inicioFornecimento, today);
      const resultDatesFimFornecimento = this.compareDates(offer.inicioFornecimento, offer.fimFornecimento)
      // console.log("compara data", resultDates)
      // console.log("compara data 2", resultDatesFimFornecimento)
      //console.log("envio da oferta", today)
      // console.log("envio da oferta", offer)
      this.message = "";

      if (resultDates === -1) {
        this.successful = false;
        this.message = "A data de inicio do fornecimento não pode ser menor que a data de hoje";
        return
      }
      if (resultDatesFimFornecimento === 1) {
        this.successful = false;
        this.message = "A data de fim do fornecimento não pode ser menor que a data do inicio do fornecimento";
        return
      }

      if (this.offerData.biomethanePrice === 0) {
        this.successful = false;
        this.message = "Informe um valor no campo 'Preço (por m³)'";
        return
      }
      
      if (this.offerData.biomethaneWithCertPrice === 0) {
        this.message = "Informe um valor no campo 'Preço por certificado'";
        return
      }

      if (offer.qntCertificado === 0 || offer.qntCertificado == null) {
        this.message = "Informe um valor no campo 'N de certificados'";
        return
      }

      if (this.offerData.shippingPrice === 0) {
        this.successful = false;
        this.message = "Informe um valor no campo 'Valor do frete (por m³)'";
        return
      }

      if (this.selectedLocation.nome == "") {
        this.successful = false;
        this.message = "Informe o local de entrega";
        return
      }

      this.$store.dispatch("offer/registerBuyBioCert", offer).then(
        (data) => {
          this.message = "Oferta Cadastrada com Sucesso.";
          this.successful = true;
          this.loading = false;
          this.offerData.biomethaneTotal = 0;
          this.offerData.biomethanePrice = 0;
          this.offerData.biomethaneTotalPrice = 0;
          this.offerData.shippingPrice = 0;
          for (const monthObj of this.monthValues) {
            monthObj.qty = 0;
          }
        },
        (error) => {
          this.message =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          this.successful = false;
          this.loading = false;
        }
      );
    },
    
  },
};
</script>

<style scoped lang="scss">
label {
  display: block;
  margin-top: 10px;
}
.form-section-title {
  font-size: 1.1rem;
  font-weight: 400;
  text-transform: uppercase;
}
small {
  font-size: 0.7rem;
}

.fieldset {
  border: 1px solid #ccc;
  border-radius: 8px;
  legend {
    font-weight: 400;
    font-size: 15px;
    width: auto;
    min-width: auto;
    padding: 0 15px 0 5px;
    margin-left: 7px;
  }
}

.card-container.card {
  max-width: 450px !important;
  padding: 40px 40px;
}

.card {
  background-color: #fff;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  margin-top: 50px;
  -moz-border-radius: 10px;
  -webkit-border-radius: 10px;
  border-radius: 10px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
}

.profile-img-card {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
}

.error-feedback {
  color: red;
}
a {
  cursor: pointer
}

</style>
