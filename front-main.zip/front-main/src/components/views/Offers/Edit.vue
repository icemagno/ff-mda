<template>
  <div class="container pl-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link :to="{ name: 'offers' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h1>Enviar Proposta</h1>
    </div>
    <div class="breadcrumb">
        <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
            <span class="mr-1">Painel > </span>
        </router-link>
        <router-link v-else :to="{ name: 'fornecedor' }">
            <span class="mr-1">Painel > </span>
        </router-link>
        <router-link :to="{ name: 'transactions' }">
            <span class="mr-1"> Minhas Negociações > </span>
        </router-link>
        <span class="active"> Enviar Proposta</span>
    </div>
    <div v-for="item in offer.listaNegociacaoRodada">
        {{item.nomeFatasia}}
    </div>
    <div
        v-if="messageSentSuccessfully"
        class="alert"
        :class="successful ? 'alert-success' : 'alert-danger'"
    >
        {{ messageSentSuccessfully }}
    </div>
    <h5>Rodadas de Negociação</h5>
    <div class="accordion" id="accordionExample">
        <div class="card" v-for="(item, index) in offer.listaNegociacaoRodada">
            <div :class="['card-header', { 'even': index % 2 === 0, 'odd': index % 2 !== 0 }]" :id="'heading' + item.id">
                <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left d-flex justify-content-between" type="button" data-toggle="collapse" :data-target="'#multiCollapse' + item.id" aria-expanded="false" :aria-controls="'multiCollapse' + item.id">
                        <div>
                            <span class="company-name">{{item.empresaProponente.nomeFatasia}}</span>
                            <span v-if="index === 0" style="
                                padding: 5px 10px;
                                background: #e4c512;
                                color: #634304;
                                font-size: 12px;
                                font-weight: 600;
                                margin: 0 0 0 10px;
                                border-radius: 5px;
                            ">Última proposta enviada</span>
                        </div>
                        <span class="send-date">Data de envio: {{item.dataRodada}}</span>
                    </button>
                </h2>
            </div>

            <!--<div :id="'multiCollapse' + item.id" :class="[{ 'collapse': index > 0}, 'multi-collapse']" >-->
            <div :id="'multiCollapse' + item.id" class="collapse multi-collapse" >
                <div class="card-body">
                    <div v-if="displayProposal" class="modal-contraproposta">
                        <button @click.prevent="hideProposal" class="close-modal">X</button>
                        <div v-if="index === 0 && displayProposal" class="panel-send-proposal px-4 py-3">
                            <h4>Informações da sua proposta</h4>
                            <Form v-if="offer.ofertaTipo.id == 3" @submit="sendProposal">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <label>Quantidade de certificados</label>
                                        <Field class="form-control" type="text" name="qntCertificado" v-model="qntCertificados"/>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <label for="preco-total">Preço por certificado</label>
                                        <vue-number class="form-control" v-model="valorCertificado" name="precoCertificado" v-bind="priceMask"></vue-number>
                                    </div>
                                </div>
                                <div
                                    v-if="message"
                                    class="alert"
                                    :class="successful ? 'alert-success' : 'alert-danger'"
                                >
                                    {{ message }}
                                </div>
                                <div class="d-flex justify-content-center mt-5 pb-5">
                                    <button @click.prevent="saveChangesOnlyCert" class="btn btn-primary mx-2">Enviar contraproposta</button>
                                    <button @click.prevent="hideProposal" class="btn btn-secondary mx-2">Fechar</button>
                                </div>
                            </Form>
                            
                            <Form v-else @submit="sendProposal">
                                <div>
                                    <h5 class="form-section-title">Informações de entrega</h5>
                                    <div class="row justify-content-center">
                                    <div class="col-sm-12 col-md-auto">
                                        <label>Tipo de Frete</label>
                                        <div class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" name="tipofrete" value="CIF" v-model="tipoFrete"  />
                                            <label class="form-check-label">
                                                CIF
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" name="tipofrete" value="FOB" v-model="tipoFrete"  />
                                            <label class="form-check-label">
                                                FOB
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-auto">
                                        <label>Logística</label>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" type="radio" name="logistica" value="duto transporte" v-model="logistica" />
                                        <label class="form-check-label">
                                            Duto de transporte
                                        </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" type="radio" name="logistica" value="duto distribuicao" v-model="logistica"/>
                                        <label class="form-check-label">
                                            Duto de distribuição
                                        </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" type="radio" name="logistica" value="GNC" v-model="logistica"/>
                                        <label class="form-check-label">
                                            GNC
                                        </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" type="radio" name="logistica" value="GNL" v-model="logistica"/>
                                        <label class="form-check-label">
                                            GNL
                                        </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <label>Valor do frete (por m³)</label>
                                        <vue-number class="form-control" v-model="valorFrete" name="precofrete" v-bind="priceMask"></vue-number>
                                        <!--
                                        <Field class="form-control" name="valorFrete" type="text" id="valor-frete"  />
                                        -->
                                    </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-sm-12 col-md-4">
                                            <label>Local de entrega</label>
                                            <div class="input-group mb-2 mr-sm-2">
                                            <select class="form-control" name="locationName" as="select" v-model="selectedLocation.id">
                                                <option v-for="location in deliveryLocations" :key="location.id" :value="location.id">{{location.nome}}</option>
                                            </select>
                                            <!--
                                            <div class="input-group-prepend">
                                                <button class="btn btn-primary ml-1"><i class="bi bi-plus-square"></i></button>
                                            </div>
                                            -->
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-8">
                                            <label for="desc">Descrição</label>
                                            <Field class="form-control" name="desc" type="text" id="desc" v-model="selectedLocation.descricao" readonly />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                            <label for="address">Endereço</label>
                                            <Field class="form-control" name="address" type="text" id="address" v-model="selectedLocation.endereco.logradouro" readonly />
                                        </div>
                                        <div class="col-sm-12 col-md-4">
                                            <label for="city">Cidade</label>
                                            <Field class="form-control" name="city" type="text" id="city" v-model="selectedLocation.endereco.cidade" readonly />
                                        </div>
                                        <div class="col-sm-12 col-md-2">
                                            <label for="state">UF</label>
                                            <Field class="form-control" name="state" type="text" id="state" v-model="selectedLocation.endereco.cidade" readonly />
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-5">
                                <template v-if="offer.ofertaTipo.id == 2">
                                    <h5 class="form-section-title">Informações do Certificado</h5>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-4">
                                            <label>Quantidade de certificados</label>
                                            <Field class="form-control" type="text" name="qntCertificado" v-model="qntCertificados"/>
                                        </div>
                                        <div class="col-sm-12 col-md-4">
                                            <label for="preco-m3">Preço (por certificado)</label>
                                            <vue-number class="form-control" name="precoCertificado" v-bind="priceMask" v-model="valorCertificado"></vue-number>
                                        </div>
                                    </div>
                                </template>
                                <h5 class="form-section-title mt-5">Informações de fornecimento</h5>
                                <div class="row justify-content-between">
                                <div class="col-sm-12 col-md-5">
                                    <div class="row">
                                    <div class="col-sm-12 col-md-auto">
                                        <label>Modalidade</label>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" name="modalidade" type="radio" value="S" v-model="modalidade" />
                                        <label class="form-check-label">
                                            Firme
                                        </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" name="modalidade" type="radio" value="N" v-model="modalidade"/>
                                        <label class="form-check-label">
                                            Flexível
                                        </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-auto">
                                        <label>Tipo</label>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" type="radio" name="tipoFornecimento" value="S" v-model="sazonalidade" />
                                        <label class="form-check-label">
                                            Sazonal
                                        </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                        <Field class="form-check-input" type="radio" name="tipoFornecimento" value="N" v-model="sazonalidade" />
                                        <label class="form-check-label">
                                            Contínua
                                        </label>
                                        </div>
                                    </div>
                                    </div>
                                    <div>
                                    <label>Período de fornecimento</label>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                        <Field class="form-control" type="text" name="inicioFornecimento" v-maska data-maska="##/##/####" v-model="startDate"/>
                                        </div>
                                        <div class="col-sm-12 col-md-6">
                                        <Field class="form-control" type="text" name="fimFornecimento" v-maska data-maska="##/##/####" v-model="endDate"/>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                        <label for="total-biometano">Total de Biometano no Período</label>
                                        <vue-number class="form-control" name="totalBiometano" v-model="biomethaneTotal" v-bind="maskTotalBiometano" readonly></vue-number>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                        <label for="preco-m3">Preço (por m³)</label>
                                        <vue-number class="form-control" v-model="valorBiometano" name="precoBiometano" v-bind="priceMask"></vue-number>
                                        </div>
                                        <div class="col-sm-12 col-md-6">
                                        <label for="preco-total">Preço total da oferta</label>
                                        <vue-number class="form-control" v-model="biomethaneTotalPrice" name="precoTotal" v-bind="priceMask" readonly></vue-number>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <label>Quantidades de Biometano</label>
                                    <table class="monthly-biomethane">
                                    <tbody>
                                        <tr v-for="(month, index) in processedMonths" :key="index">
                                        <td class="p-2" v-for="(item, columnIndex) in month" :key="columnIndex">
                                            <div v-if="item" style="display: flex; align-items: center;">
                                            <span class="pr-1">{{ item.legend }}</span>
                                            <vue-number class="form-control" :name="item.legend" v-model="item.qty" v-bind="number"></vue-number>
                                            </div>
                                        </td>
                                        </tr>
                                    </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                                <div
                                    v-if="message"
                                    class="alert"
                                    :class="successful ? 'alert-success' : 'alert-danger'"
                                >
                                    {{ message }}
                                </div>
                                <div class="d-flex justify-content-center mt-5 pb-5">
                                    <button v-if="offer.ofertaTipo.id == 1" @click.prevent="saveChanges" class="btn btn-primary mx-2">Enviar contraproposta</button>
                                    <button v-if="offer.ofertaTipo.id == 2" @click.prevent="saveChangesWithCert" class="btn btn-primary mx-2">Enviar contraproposta</button>
                                    <button @click.prevent="hideProposal" class="btn btn-secondary mx-2">Fechar</button>
                                </div>
                            </Form>
                        </div>
                    </div>
                    <template v-else>
                        <div v-if="offer.ofertaTipo.id == 3" class="round-data">
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <label>Quantidade de certificados</label>
                                    <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 22">
                                            {{ negotiationItem.valor }}
                                        </p>
                                    </template>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <label>Preço por certificado</label>
                                    <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 17">
                                            {{ formatAsCurrency(negotiationItem.valor) }}
                                        </p>
                                    </template>
                                </div>
                            </div>
                        </div>
                        <div v-else class="round-data">
                            <div>
                                <label>Tipo</label>
                                <p class="card-data">Sazonal (Flexível)</p>
                            </div>
                            <div class="row">
                                <div class="col col-md-5">
                                    <label>Período de fornecimento</label>
                                    <div class="d-flex">
                                        <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                            <p class="card-data" v-if="negotiationItem.idItem === 18">
                                                {{negotiationItem.valor}}                                    
                                            </p>
                                        </template>
                                        <span class="mx-3">até</span>
                                        <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                            <p class="card-data" v-if="negotiationItem.idItem === 21">
                                                {{negotiationItem.valor}}                                    
                                            </p>
                                        </template>
                                    </div>
                                </div>
                                <div class="col col-md-5">
                                    <label for="preco-m3">Preço (por m³)</label>
                                    <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <p class="card-data" v-if="negotiationItem.idItem === 13">
                                            {{ formatAsCurrency(negotiationItem.valor) }}     
                                        </p>
                                    </template>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-6">
                                    <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <template v-if="negotiationItem.idItem === 22">
                                            <label>Quantidade de certificados</label>
                                            <p class="card-data">
                                                {{ negotiationItem.valor }}
                                            </p>
                                        </template>
                                    </template>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                        <template v-if="negotiationItem.idItem === 17">
                                            <label for="preco-total">Preço por certificado</label>
                                            <p class="card-data">
                                                {{ formatAsCurrency(negotiationItem.valor) }} 
                                            </p>
                                        </template>
                                    </template>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col col-md-5">
                                    <label>Fornecimento mensal</label>
                                    <table class="table table-borderless table-sm">
                                        <tbody>
                                            <tr v-for="monthlyDelivery in item.listaEntregaSazonais">
                                                <td v-if="monthlyDelivery.mes == 1">Janeiro</td>
                                                <td v-if="monthlyDelivery.mes == 2">Fevereiro</td>
                                                <td v-if="monthlyDelivery.mes == 3">Março</td>
                                                <td v-if="monthlyDelivery.mes == 4">Abril</td>
                                                <td v-if="monthlyDelivery.mes == 5">Maio</td>
                                                <td v-if="monthlyDelivery.mes == 6">Junho</td>
                                                <td v-if="monthlyDelivery.mes == 7">Julho</td>
                                                <td v-if="monthlyDelivery.mes == 8">Agosto</td>
                                                <td v-if="monthlyDelivery.mes == 9">Setembro</td>
                                                <td v-if="monthlyDelivery.mes == 10">Outubro</td>
                                                <td v-if="monthlyDelivery.mes == 11">Novembro</td>
                                                <td v-if="monthlyDelivery.mes == 12">Dezembro</td>
                                                <td class="text-right">{{ formatM3(monthlyDelivery.valorMes) }}m³</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col col-md-7">
                                    <label class="text-uppercase" style="border-bottom: 1px solid #ccc;">Local de Entrega</label>
                                    <div>
                                        <label>Local</label>
                                        <p class="card-data">{{offerData.localEntrega.nome}}</p>
                                        <!--<p class="card-data">{{offer.empresa.endereco.logradouro}} {{offer.empresa.endereco.numero}} {{offer.empresa.endereco.complemento}}. {{offer.empresa.endereco.bairro}}</p>-->
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <label>Cidade</label>
                                            <p class="card-data">{{offerData.localEntrega.endereco.cidade}}</p>
                                            <!--<p class="card-data">{{offer.empresa.endereco.cidade}}</p>-->
                                        </div>
                                        <div>
                                            <label>UF</label>
                                            <p class="card-data">{{offerData.localEntrega.endereco.estado}}</p>
                                            <!--<p class="card-data">{{offer.empresa.endereco.estado}}</p>-->
                                        </div>
                                    </div>
                                    <div>
                                        <label>Endereço</label>
                                        <p v-if="offerData.localEntrega.endereco.logradouro" class="card-data">{{offerData.localEntrega.endereco.logradouro}}, {{offerData.localEntrega.endereco.numero}}. {{offerData.localEntrega.endereco.complemento}}. {{offerData.localEntrega.endereco.bairro}}</p>
                                        <p v-else class="card-data">Não informado</p>
                                        <!--<p class="card-data">{{offer.empresa.endereco.logradouro}} {{offer.empresa.endereco.numero}} {{offer.empresa.endereco.complemento}}. {{offer.empresa.endereco.bairro}}</p>-->
                                    </div>
                                    <label class="mt-5 text-uppercase" style="border-bottom: 1px solid #ccc;">INFORMAÇÕES DE FRETE</label>
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <label>Tipo de frete</label>
                                            <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                                <p class="card-data" v-if="negotiationItem.idItem === 14">
                                                    {{ negotiationItem.valor }}
                                                </p>
                                            </template>
                                        </div>
                                        <div>
                                            <label>Logística</label>
                                            <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                                <p class="card-data" v-if="negotiationItem.idItem === 15">
                                                    {{ negotiationItem.valor }}
                                                </p>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <!--
                                        <div>
                                            <label>Meio de transporte</label>
                                            <template v-for="negotiationItem in offer.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                                                <p class="card-data" v-if="negotiationItem.idItem === 20">
                                                    {{ negotiationItem.valor }}
                                                </p>
                                            </template>
                                        </div>
                                        -->
                                        <div>
                                            <label>Preço do frete (por m³)</label>
                                            <template v-for="negotiationItem in item.listaNegociacaoPropostas" :key="negotiationItem.id">
                                                <p class="card-data" v-if="negotiationItem.idItem === 19">
                                                    <!-- Check if idItem is equal to 5 -->
                                                    {{ formatAsCurrency(negotiationItem.valor) }}
                                                </p>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            v-if="messagePropostaAceita"
                            class="alert"
                            :class="propostaAceita ? 'alert-success' : 'alert-danger'"
                        >
                            {{ messagePropostaAceita }}
                        </div>
                        <template v-if="currentUser.razaoSocial != item.empresaProponente.razaoSocial">
                            <div v-if="index === 0" class="d-flex justify-content-center mt-5 pb-5">
                                <button @click.prevent="acceptProposal(offerId)" :class="[{ 'disable-button': propostaAceita }]" class="btn btn-primary mx-3">Aceitar Proposta</button>
                                <button @click.prevent="showProposal" :class="[{ 'disable-button': propostaAceita }]" class="btn btn-primary mx-3">Criar Contraproposta</button>
                                <button @click.prevent="cancelNegotiation(offerId)" :class="[{ 'hide-button': offer.listaNegociacaoRodada.length == 1 }]" class="btn btn-primary mx-3">Desistir da Negociação</button>
                            </div>
                        </template>
                        <template v-else>
                            <div v-if="index === 0" class="d-flex justify-content-center mt-5 pb-5">
                                <button @click.prevent="cancelNegotiation(offerId)" :class="[{ 'hide-button': offer.listaNegociacaoRodada.length == 1 }]" class="btn btn-primary mx-3">Desistir da Negociação</button>
                            </div>
                        </template>
                        <div style="height: 150px"></div>
                        <div v-if="offer.ofertaTipo.id == 2" style="height: 150px"></div>
                    </template>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import OfferService from '../../../services/offer.service';
import LocaisEntregaService from '../../../services/locaisentrega.service';
import { Form, Field, ErrorMessage } from "vee-validate";
import { component as VueNumber } from '@coders-tm/vue-number-format'
import axios from 'axios';

export default {
    components: {
        Form,
        Field,
        ErrorMessage,
        VueNumber,
  },
  data() {
    return {
        successful: false,
        offer:{},
        displayProposal: 0,
        message: '',
        messagePropostaAceita: '',
        messageSentSuccessfully: '',
        sazonalidade: '',
        logistica: '',
        estadoGas: '',
        modalidade: '',
        tipoFrete: '',
        inicioEntrega: '',
        fimEntrega: '',
        valorBiometano: 0,
        valorFre: 0,
        valorCertificado: 0,
        qntCertificados: 0,
        startDate: '',
        endDate: '',
        propostaAceita: false,
        offerData: {
            biomethaneTotal: 0,
            biomethanePrice: 0,
            biomethaneTotalPrice: 0,
            biomethaneWithCertPrice: 0,
            shippingPrice: 0,
            localEntrega: {
                id: '',
                descricao:'',
                empresa:'',
                nome:'',
                endereco: {
                    id: '',
                    logradouro: '-',
                    numero: '-',
                    complemento: '-',
                    bairro: '-',
                    cep: '-',
                    cidade: '-',
                    estado: '-',
                    pais: '-',
                    telefone: '-',
                    email: '-'
                }
            }
        },
        proposal:{
            oferta:{
                id:null,
                ofertaTipo:{
                    id:null
                },
                tipo:""
            },
            observacaoRodada:"",
            listaNegociacaoProposta:[],
            entregasSazonais: null
        },
        priceMask: {
            decimal: ",",
            separator: ".",
            prefix: "R$",
            suffix: "",
            precision: 2,
            nullValue: "",
            masked: true,
            reverseFill: true,
            prefill: true
        },
        maskTotalBiometano: {
            decimal: ".",
            separator: ".",
            prefix: "",
            suffix: "m³",
            precision: 0,
            nullValue: "",
            masked: true,
            reverseFill: true,
            prefill: true
        },
        number: {
            decimal: ".",
            separator: ".",
            prefix: "",
            suffix: "m³",
            precision: 0,
            nullValue: "",
            masked: true,
            reverseFill: true,
            prefill: true
        },
        monthValues: [
            { month: 1, qty: 0, legend: 'JAN'},
            { month: 2, qty: 0, legend: 'FEV'},
            { month: 3, qty: 0, legend: 'MAR'},
            { month: 4, qty: 0, legend: 'ABR'},
            { month: 5, qty: 0, legend: 'MAI'},
            { month: 6, qty: 0, legend: 'JUN'},
            { month: 7, qty: 0, legend: 'JUL'},
            { month: 8, qty: 0, legend: 'AGO'},
            { month: 9, qty: 0, legend: 'SET'},
            { month: 10, qty: 0, legend: 'OUT'},
            { month: 11, qty: 0, legend: 'NOV'},
            { month: 12, qty: 0, legend: 'DEZ'}
        ],
        deliveryLocations: {},
        selectedLocation: {
            id: "",
            nome: "",
            descricao: "",
            endereco: {
                bairro: "",
                cidade: "",
                complemento: "",
                estado: "",
                logradouro: "",
                numero: "",
            }
        },
    };
  },
  mounted() {

    this.getLocaisEntrega();
    this.getOffer();
    
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    offerId() {
      return this.$store._state.data.offer.offerId;
    },
    formatAsCurrency() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
            let valueInCentavos = valor;
            let valueInReais = valueInCentavos / 100
            let formattedValue = valueInReais.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
            return formattedValue;
          //return Number(valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        return '';
      };
    },
    formatM3() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
          return Number(valor).toLocaleString('de-DE');
        }
        return '';
      };
    },
    biomethaneTotal() {
      const [startDay, startMonth, startYear] = this.startDate.split('/').map(Number);
      const [endDay, endMonth, endYear] = this.endDate.split('/').map(Number);

      const start = new Date(startYear, startMonth - 1, startDay);
      const end = new Date(endYear, endMonth - 1, endDay);

      let totalSum = 0;

      while (start <= end) {
        const month = start.getMonth() + 1; // getMonth() returns zero-based month
        const year = start.getFullYear();

        const monthValue = this.monthValues.find(entry => entry.month === month);
        if (monthValue) {
          let maskedNumber = monthValue.qty.toString();
          let removeMask = maskedNumber.replaceAll(".","").replace("m³","");
          let removeMaskToNumber = Number(removeMask);
          console.log("valor", removeMaskToNumber)
          totalSum += removeMaskToNumber;
        }

        start.setMonth(start.getMonth() + 1); // Move to the next month
      }
      
      this.offerData.biomethaneTotal = totalSum

      return totalSum;
    },
    biomethaneTotalPrice() {
      
      let biomethaneTotal = this.offerData.biomethaneTotal;
    //   console.log("calculo do preço total", biomethaneTotal);
    //   console.log("calculo do preço total", this.offerData.biomethanePrice);
      let maskedNumber = this.valorBiometano.toString();
      let removeMask = maskedNumber.replaceAll(".","").replaceAll(",","").replace("R$","");
      let removeMaskToNumber = Number(removeMask);
      let total = biomethaneTotal * removeMaskToNumber;
      total = this.formatAsCurrency(total);

    //   console.log("calculo do preço total", total)

      return total;
    },
    processedMonths() {
      const processed = [];
      const tempArray = [...this.monthValues];

      while (tempArray.length > 0) {
        processed.push(tempArray.splice(0, 2));
      }

      return processed;
    }
  },
  methods: {
    showProposal () {
        this.displayProposal = 1;
    },
    hideProposal () {
        this.displayProposal = 0;
    },
    radioSazonal() {
    //   this.offer. = v;
    //   if (this.currentSeller.user.role == 3) {
    //     this.isAdmBusinessRole = false;
    //     this.isSellerRole = true;
    //   } else {
    //     this.isAdmBusinessRole = true;
    //     this.isSellerRole = false;
    //   }
    },

    getOffer() {
        OfferService.editItem(this.offerId).then(
            response => {
                const vaivai = response.data.listaNegociacaoRodada.sort((a, b) => b.id - a.id);
                console.log("carrega os dados", response.data)
                // console.log("carrega os dados", response.data.listaNegociacaoRodada)
                // console.log("carrega os dados lista negocia normal", vaivai)
                // console.log("carrega os dados lista negocia reversa", vaivai.reverse())
                this.offer = response.data
                this.offer.listaNegociacaoRodada.sort((a, b) => b.id - a.id);
                this.proposal.oferta.id = this.offer.id
                this.proposal.oferta.ofertaTipo.id = response.data.ofertaTipo.id
                this.proposal.oferta.tipo = response.data.tipo
            
                const negotiationItems = this.offer.listaNegociacaoRodada[0].listaNegociacaoPropostas
                const roundDate = this.offer.listaNegociacaoRodada
                this.offer.listaNegociacaoRodada.forEach((rodada) => {
                    rodada.dataRodada = this.formatDate(rodada.dataRodada)
                })
                // console.log("entregas", biomethaneMonthlyDelivery)
                // console.log("negociação", biomethaneMonthlyDelivery)
                if (response.data.ofertaTipo.id == 3){
                    negotiationItems.forEach((item) => {
                        if (item.idItem == 17) {
                            this.valorCertificado = this.formatAsCurrency(item.valor);
                            console.log("preco certificado", this.valorCertificado)
                        }
                        if (item.idItem == 22) this.qntCertificados = item.valor
                    });
                }
                if (response.data.ofertaTipo.id == 1 || response.data.ofertaTipo.id == 2){
                    const biomethaneMonthlyDelivery = this.offer.listaNegociacaoRodada[0].listaEntregaSazonais
                    biomethaneMonthlyDelivery.forEach((month) => {
                        if (month.mes == 1) {
                            this.monthValues[0].qty = month.valorMes
                            //month.mes = "Janeiro"
                        }
                        if (month.mes == 2) {
                            this.monthValues[1].qty = month.valorMes
                            //month.mes = "Fevereiro"
                        }
                        if (month.mes == 3) {
                            this.monthValues[2].qty = month.valorMes
                            //month.mes = "Março"
                        }
                        if (month.mes == 4) {
                            this.monthValues[3].qty = month.valorMes
                            //month.mes = "Abril"
                        }
                        if (month.mes == 5) {
                            this.monthValues[4].qty = month.valorMes
                            //month.mes = "Maio"
                        }
                        if (month.mes == 6) {
                            this.monthValues[5].qty = month.valorMes
                            //month.mes = "Junho"
                        }
                        if (month.mes == 7) {
                            this.monthValues[6].qty = month.valorMes
                            //month.mes = "Julho"
                        }
                        if (month.mes == 8) {
                            this.monthValues[7].qty = month.valorMes
                            //month.mes = "Agosto"
                        }
                        if (month.mes == 9) {
                            this.monthValues[8].qty = month.valorMes
                            //month.mes = "Setembro"
                        }
                        if (month.mes == 10) {
                            this.monthValues[9].qty = month.valorMes
                            //month.mes = "Outubro"
                        }
                        if (month.mes == 11) {
                            this.monthValues[10].qty = month.valorMes
                            //month.mes = "Novembro"
                        }
                        if (month.mes == 12) {
                            this.monthValues[11].qty = month.valorMes
                            //month.mes = "Dezembro"
                        }
                        // console.log("entregas mes", month.mes)
                    });
                    
                    negotiationItems.forEach((item) => {
                        if (item.idItem == 3) this.sazonalidade = item.valor
                        if (item.idItem == 5) {
                            this.getLocalEntregaById(item.valor)
                        }
                        if (item.idItem == 8) this.modalidade = "S"
                        if (item.idItem == 13) this.valorBiometano = this.formatAsCurrency(item.valor)
                        if (item.idItem == 14) this.tipoFrete = item.valor
                        if (item.idItem == 15) this.logistica = item.valor
                        if (item.idItem == 17) this.valorCertificado = this.formatAsCurrency(item.valor)
                        if (item.idItem == 18) this.startDate = item.valor
                        if (item.idItem == 19) this.valorFrete = this.formatAsCurrency(item.valor)
                        if (item.idItem == 21) this.endDate = item.valor
                        if (item.idItem == 22) this.qntCertificados = item.valor
                        //console.log("item", item.valor)
                        // console.log("entregas mes", month.mes)
                    });
                }
            
                //this.$router.push({ name: 'edit-item', params: { itemData: response.data, itemId: response.data.id } });
            },
            error => {
                console.log("Erro", error)
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },

    async getLocalEntregaById(id) {
        try {
            
          let res = await LocaisEntregaService.getById(id);
          console.log("local de entrega", res.data)
          this.selectedLocation.id = res.data.id
          this.selectedLocation.nome = res.data.nome
          this.selectedLocation.descricao = res.data.descricao
          this.selectedLocation.endereco.cidade = res.data.endereco.cidade
          this.selectedLocation.endereco.estado = res.data.endereco.estado
          
          this.offerData.localEntrega.nome = res.data.nome
          this.offerData.localEntrega.endereco.cidade = res.data.endereco.cidade
          this.offerData.localEntrega.endereco.estado = res.data.endereco.estado
          this.offerData.localEntrega.endereco.bairro = res.data.endereco.bairro
          this.offerData.localEntrega.endereco.logradouro = res.data.endereco.logradouro
          this.offerData.localEntrega.endereco.numero = res.data.endereco.numero
          this.offerData.localEntrega.endereco.complemento = res.data.endereco.complemento

        } catch (err) {
            console.log(err);
        }
    },
    getLocaisEntrega() {
        OfferService.getAllLocaisEntrega().then(
            response => {
                console.log("locais de entrega", response.data)
                this.deliveryLocations = response.data;
            },
            error => {
                console.log("Erro", error)
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    acceptProposal(offerId) {
        OfferService.acceptProposal(offerId).then(
            response => {
                console.log("proposta aceita com sucesso", response.data)
                this.propostaAceita = true;
                this.messagePropostaAceita = "Proposta aceita com sucesso!"
            },
            error => {
                console.log("Erro", error)
                this.propostaAceita = false;
                this.messagePropostaAceita = error.response.data.message
                //console.log("Error data", error.config.data)
                //this.message = error.response.data.message
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    cancelNegotiation(offerId) {
        OfferService.cancelNegotiation(offerId).then(
            response => {
                console.log("proposta cencelada com sucesso", response.data)
                this.propostaAceita = false;
                this.messagePropostaAceita = "Proposta cancelada com sucesso!"
            },
            error => {
                console.log("Erro", error)
                this.propostaAceita = false;
                this.messagePropostaAceita = error.response.data.message
                //console.log("Error data", error.config.data)
                //this.message = error.response.data.message
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    formatDate(inputDate) {
        const date = new Date(inputDate);
        
        // Extract date components
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based
        const year = date.getFullYear();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        // Construct the formatted date string
        const formattedDate = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;

        return formattedDate;
    },
    saveChanges() {
      // Handle saving changes, for example, by making a PUT request with Axios
      // After saving, you can navigate back to the list or perform other actions
      // this.proposal.entregasSazonais = this.offer.listaNegociacaoRodada[0].listaEntregaSazonais
        this.monthValues.forEach((month) => {
            let maskedNumber = month.qty.toString();
            let removeMask = maskedNumber.replaceAll(".","").replace("m³","");
            let removeMaskToNumber = Number(removeMask);
            month.qty = removeMaskToNumber
        });

        let maskedValorBiometano = this.valorBiometano.toString();
        let removeMaskValorBiometano = maskedValorBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
        let removeMaskValorBiometanoToNumber = Number(removeMaskValorBiometano);
        
        let maskedValorFrete = this.valorFrete.toString();
        let removeMaskValorFrete = maskedValorFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
        let removeMaskValorFreteToNumber = Number(removeMaskValorFrete);
        

        this.proposal.entregasSazonais = [
            {mes: 1, valorMes: this.monthValues[0].qty},
            {mes: 2, valorMes: this.monthValues[1].qty},
            {mes: 3, valorMes: this.monthValues[2].qty},
            {mes: 4, valorMes: this.monthValues[3].qty},
            {mes: 5, valorMes: this.monthValues[4].qty},
            {mes: 6, valorMes: this.monthValues[5].qty},
            {mes: 7, valorMes: this.monthValues[6].qty},
            {mes: 8, valorMes: this.monthValues[7].qty},
            {mes: 9, valorMes: this.monthValues[8].qty},
            {mes: 10, valorMes: this.monthValues[9].qty},
            {mes: 11, valorMes: this.monthValues[10].qty},
            {mes: 12, valorMes: this.monthValues[11].qty}
        ]
        this.proposal.listaNegociacaoProposta = [
            {
                idItem: 3,
                valor:this.sazonalidade
            },
            {
                idItem: 5,
                valor: this.selectedLocation.id
            },
            {
                idItem: 8,
                valor:this.modalidade
            },
            {
                idItem: 13,
                valor:removeMaskValorBiometanoToNumber
            },
            {
                idItem: 14,
                valor:this.tipoFrete
            },
            {
                idItem: 15,
                valor:this.logistica
            },
            {
                idItem: 18,
                valor:this.startDate
            },
            {
                idItem: 19,
                valor:removeMaskValorFreteToNumber
            },
            {
                idItem: 21,
                valor:this.endDate
            },
            
        ]

        if (this.selectedLocation.nome == "") {
            this.successful = false;
            this.message = "Informe o local de entrega";
            return
        }
 
        OfferService.sendProposal(this.proposal).then(
            response => {
                console.log("sucesso", response.data)
                this.successful = true;
                this.messageSentSuccessfully = "Proposta enviada com sucesso!"
            
                this.hideProposal();
                this.getOffer();
            },
            error => {
                console.log("Erro", error)
                console.log("Error data", error.config.data)
                //this.message = error.response.data.message
                this.successful = false;
                this.message =
                  (error.response && error.response.data && error.response.data.message) ||
                  error.message ||
                  error.toString();
            }
        );
      
    },
    saveChangesWithCert() {
        this.monthValues.forEach((month) => {
            let maskedNumber = month.qty.toString();
            let removeMask = maskedNumber.replaceAll(".","").replace("m³","");
            let removeMaskToNumber = Number(removeMask);
            month.qty = removeMaskToNumber
        });

        let maskedValorBiometano = this.valorBiometano.toString();
        let removeMaskValorBiometano = maskedValorBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
        let removeMaskValorBiometanoToNumber = Number(removeMaskValorBiometano);

        let maskedValorCertificado = this.valorCertificado.toString();
        let removeMaskValorCertificado = maskedValorCertificado.replaceAll(".","").replaceAll(",","").replace("R$","");
        let removeMaskValorCertificadoToNumber = Number(removeMaskValorCertificado);
        
        let maskedValorFrete = this.valorFrete.toString();
        let removeMaskValorFrete = maskedValorFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
        let removeMaskValorFreteToNumber = Number(removeMaskValorFrete);
        

        this.proposal.entregasSazonais = [
            {mes: 1, valorMes: this.monthValues[0].qty},
            {mes: 2, valorMes: this.monthValues[1].qty},
            {mes: 3, valorMes: this.monthValues[2].qty},
            {mes: 4, valorMes: this.monthValues[3].qty},
            {mes: 5, valorMes: this.monthValues[4].qty},
            {mes: 6, valorMes: this.monthValues[5].qty},
            {mes: 7, valorMes: this.monthValues[6].qty},
            {mes: 8, valorMes: this.monthValues[7].qty},
            {mes: 9, valorMes: this.monthValues[8].qty},
            {mes: 10, valorMes: this.monthValues[9].qty},
            {mes: 11, valorMes: this.monthValues[10].qty},
            {mes: 12, valorMes: this.monthValues[11].qty}
        ]
        
        this.proposal.listaNegociacaoProposta = [
            {
                idItem: 3,
                valor:this.sazonalidade
            },
            {
                idItem: 5,
                valor: this.selectedLocation.id
            },
            {
                idItem: 8,
                valor:this.modalidade
            },
            {
                idItem: 13,
                valor:removeMaskValorBiometanoToNumber
            },
            {
                idItem: 14,
                valor:this.tipoFrete
            },
            {
                idItem: 15,
                valor:this.logistica
            },
            {
                idItem: 17,
                valor:removeMaskValorCertificadoToNumber
            },
            {
                idItem: 18,
                valor:this.startDate
            },
            {
                idItem: 19,
                valor:removeMaskValorFreteToNumber
            },
            {
                idItem: 21,
                valor:this.endDate
            },
            {
                idItem: 22,
                valor:this.qntCertificados
            },
            
        ]

        if (this.selectedLocation.nome == "") {
            this.successful = false;
            this.message = "Informe o local de entrega";
            return
        }

        OfferService.sendProposal(this.proposal).then(
            response => {
                console.log("sucesso", response.data)
                this.successful = true;
                this.message = "Proposta enviada com sucesso!"
            },
            error => {
                console.log("Erro", error)
                console.log("Error data", error.config.data)
                this.successful = false;
                this.message = error.response.data.message
            }
        );
      
    },
    saveChangesOnlyCert() {

        let maskedValorCertificado = this.valorCertificado.toString();
        let removeMaskValorCertificado = maskedValorCertificado.replaceAll(".","").replaceAll(",","").replace("R$","");
        let removeMaskValorCertificadoToNumber = Number(removeMaskValorCertificado);
        
        this.proposal.listaNegociacaoProposta = [
            {
                idItem: 17,
                valor:removeMaskValorCertificadoToNumber
            },
            {
                idItem: 22,
                valor:this.qntCertificados
            },
            
        ]

        OfferService.sendProposal(this.proposal).then(
            response => {
                console.log("sucesso", response.data)
                this.successful = true;
                this.message = "Proposta enviada com sucesso!"
            },
            error => {
                console.log("Erro", error)
                console.log("Error data", error.config.data)
                this.successful = false;
                this.message = error.response.data.message
            }
        );
    },
  },
};
</script>

<style scoped lang="scss">
    .round-data label {
        font-weight: 600;
    }
    label {
        display: block;
        margin-top: 10px;
    }
    .card-body {
        position: relative;
    }
    .panel-send-proposal {
        background: #fff;
        border-radius: 10px;
        overflow-y: hidden;
        
    height: 100%;

    }
    .close-modal {
        position: absolute;
        right: 5%;
        border: 0;
        background: #00a790;
        border-radius: 100%;
        font-size: 12px;
        font-weight: 900;
        color: #fff;
        padding: 5px 10px;
        margin: 10px;
    }
    .form-section-title {
        font-size: 1.1rem;
        font-weight: 400;
        text-transform: uppercase;
    }
    small {
        font-size: 0.7rem;
    }

    .hide-button.btn {
        display: none;
    }
    .disable-button.btn {
        opacity: 0.2;
        cursor: not-allowed;
        pointer-events: none;
    }
    .fieldset {
        border: 1px solid #ccc;
        border-radius: 8px;
        legend {
            font-weight: 400;
            font-size: 15px;
            width: auto;
            min-width: auto;
            padding: 0 15px 0 5px;
            margin-left: 7px;
        }
    }
    .modal-contraproposta {
        position: fixed;
        width: 100%;
        height: 100vh;
        background: #0000008a;
        z-index: 999;
        top: 0;
        left: 0;
        padding: 10px 5%;
        form {
            overflow-y: auto;
            height: 100%;
            overflow-x: hidden;
        }
    }
    .accordion {
        .card-header {
            background: #F2F2F2;
            &.even {
                border-bottom: solid;
                border-color: #8A0D67;
                padding: 0;
                .company-name {
                    color: #8A0D67;
                    font-weight: 600;
                    font-size: 15px;
                }
                .send-date {
                    color: #666565;
                    font-weight: 300;
                    font-size: 15px;
                }
            }
            &.odd {
                border-bottom: solid;
                border-color: #0D4C8A;
                padding: 0;
                .company-name {
                    color: #0D4C8A;
                    font-weight: 600;
                    font-size: 15px;
                }
                .send-date {
                    color: #666565;
                    font-weight: 300;
                    font-size: 15px;
                }
            }
        }
    }
    .box-company-data {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px 10px  0;
        background: #42782714;
    }

    fieldset {
        border: 1px solid #dcdcdc;
        border-radius: 8px;
        height: auto;
    }

    legend {
        width: auto;
        padding-right: 5px;
        font-size: 16px;
        font-weight: 500;
    }
</style>