<template>

  <div class="container pl-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link :to="{ name: 'list-news' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3>Cadastrar Notícia</h3>
    </div>
    <div class="breadcrumb">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link :to="{ name: 'list-news' }">
        <span class="mr-1"> Notícias > </span>
      </router-link>
      <span class="active"> Cadastrar notícia</span>
    </div>
    <Form @submit="handleRegister" :validation-schema="schema">
        <div class="form-row">
          <div class="col-12">
            <label>Título</label>
            <Field class="form-control" name="title" type="text" />
            <ErrorMessage name="title" class="error-feedback" />
          </div>
        </div>
        <div class="form-row">
          <div class="col-12">
            <label>Notícia</label>
            <Field class="form-control" name="text" as="textarea" rows="10" />
            <ErrorMessage name="text" class="error-feedback" />
          </div>
        </div>
        <div
          v-if="message"
          class="alert"
          :class="successful ? 'alert-success' : 'alert-danger'"
        >
          {{ message }}
        </div>
        <div class="d-flex justify-content-center mt-5 pb-5">
            <button class="btn btn-primary mr-3" :disabled="loading">
                <span v-show="loading" class="spinner-border spinner-border-sm"></span>
                Salvar
            </button>
            <router-link :to="{ name: 'list-news' }" class="btn btn-secondary">
                Voltar
            </router-link>
        </div>
    </Form>
  </div>
</template>

<script>
import { Form, Field, ErrorMessage } from "vee-validate";
import * as yup from "yup";
import axios from 'axios';

export default {
  name: "create-news",
  components: {
    Form,
    Field,
    ErrorMessage
  },
  //directives: { maska: vMaska },
  data() {
    const schema = yup.object().shape({
      title: yup
        .string()
        .required("Este campo é obrigatório."),
      text: yup
        .string()
        .required("Este campo é obrigatório."),
    });
    
    return {
        successful: false,
        loading: false,
        message: "",
        schema,
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    
  },
  methods: {
    handleRegister(news) {
        this.message = "";
        this.loading = true;

        this.$store.dispatch("news/register", news).then(
            (data) => {
                console.log("salvou a noticia");
                this.message = "Cadastro Realizado com Sucesso.";
                this.successful = true;
                this.loading = false;
            },
            (error) => {
                console.log("erro ao salvar a noticia", error);
                this.message =
                    // (error.response &&
                    // error.response.data &&
                    // error.response.data.message) ||
                    // error.message ||
                    error.response.data.message;
                this.successful = false;
                this.loading = false;
            }
        );
    },
  },
};
</script>

<style scoped lang="scss">
label {
  display: block;
  margin-top: 10px;
}
.form-section-title {
  font-size: 1.1rem;
  font-weight: 400;
  text-transform: uppercase;
}
small {
  font-size: 0.7rem;
}

</style>
