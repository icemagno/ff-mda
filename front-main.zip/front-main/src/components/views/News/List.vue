<template>

  <div class="container pl-5 pb-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link :to="{ name: 'offers' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3>Notícias</h3>
    </div>
    <div class="breadcrumb">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <span class="mr-1"> Notícias</span>
    </div>
    <div class="d-flex justify-content-end">
        <router-link :to="{ name: 'create-news' }" class="btn btn-primary mb-1">
            Cadastrar Notícia
        </router-link>
    </div>
    <vue-good-table
          styleClass="vgt-table condensed custom-table"
          :columns="columns"
          :rows="news"
          :pagination-options="{
            enabled: true,
            nextLabel: '',
            prevLabel: '',
            rowsPerPageLabel: 'Registros por página',
            ofLabel: 'de',
            pageLabel: 'página', // for 'pages' mode
            allLabel: 'Todos',
            mode: 'pages'
          }"
          :search-options="{ 
            enabled: true,
            placeholder: 'Filtrar',
          }"
          class="table-action"
          >
        <template #table-row="props">
            <span v-if="props.column.field == 'action'" class="d-flex">
                <span class="mr-2">
                    <a @click="viewNews(props.row.id)">
                    <i class="bi bi-eye"></i>
                    </a>
                </span>
                <!--
                <span class="mr-2">
                    <i class="bi bi-pencil-square"></i>
                </span>
                -->
                </span>
        </template>
    </vue-good-table>
  </div>
</template>

<script>
import { Form, Field, ErrorMessage } from "vee-validate";
import { VueGoodTable } from 'vue-good-table-next';
import NewsService from '../../../services/news.service';
import * as yup from "yup";
import axios from 'axios';

export default {
  name: "list-news",
  components: {
    Form,
    Field,
    ErrorMessage,
    VueGoodTable
  },
  //directives: { maska: vMaska },
  data() {
    return {
        columns: [
            {
                label: 'Título',
                field: 'titulo',
            },
            {
                label: 'Notícia',
                field: 'texto',
            },
            {
                label: 'Situação',
                field: 'situacao.descricao',
            },
            {
                label: 'Data',
                field: 'data',
            },
            {
                label: '',
                field: 'action',
            }
        ],
        news: [],
        page: 0,
        size: 24,
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    NewsService.getAll(this.page, this.size).then(
      response => {
        console.log("noticias", response.data.content)
        this.news = response.data.content;
        this.news.forEach((item) => {
            if (item.texto.length > 120) {
                item.texto = item.texto.substring(0, 120) + '...';
            }
        });
        
      },
      error => {
        console.log("Erro", error)
        // this.content =
        //   (error.response && error.response.data && error.response.data.message) ||
        //   error.message ||
        //   error.toString();
      }
    );
    
  },
  methods: {
    viewNews(newsId) {
        this.$store.commit('news/setNewsId', newsId);
        this.$router.push({ name: "view-news"});
    }
  },
};
</script>

<style scoped lang="scss">

</style>
