<template>
  <div class="container pl-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link :to="{ name: 'list-news' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h1>Notícias</h1>
    </div>
    <div class="breadcrumb">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link :to="{ name: 'list-news' }">
        <span class="mr-1"> Notícias > </span>
      </router-link>
      <span class="active"> {{news.titulo}}</span>
    </div>
    
    <h5>{{news.titulo}}</h5>
    <div>
      {{news.texto}}
    </div>
    
  </div>
</template>

<script>

import { Form, Field, ErrorMessage } from "vee-validate";
import NewsService from '../../../services/news.service';

export default {
  name: "view-news",
  components: {
      Form,
      Field,
      ErrorMessage
  },
  data() {
    return {
      news:{}
    };
  },
  mounted() {
    NewsService.viewNews(this.newsId).then(
        response => {
            console.log("noticia", response.data)
            this.news = response.data
            
        },
        error => {
            console.log("Erro", error)
            // this.content =
            //   (error.response && error.response.data && error.response.data.message) ||
            //   error.message ||
            //   error.toString();
        }
    );
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    newsId() {
      return this.$store._state.data.news.newsId;
    },
  },
  methods: {
    
  },
};
</script>

<style scoped lang="scss">
    label {
        display: block;
        margin-top: 10px;
    }
    .card-body {
        position: relative;
    }
    .panel-send-proposal {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #fff;
        z-index: 999;
    }
    .form-section-title {
        font-size: 1.1rem;
        font-weight: 400;
        text-transform: uppercase;
    }
    small {
        font-size: 0.7rem;
    }

    .fieldset {
        border: 1px solid #ccc;
        border-radius: 8px;
        legend {
            font-weight: 400;
            font-size: 15px;
            width: auto;
            min-width: auto;
            padding: 0 15px 0 5px;
            margin-left: 7px;
        }
    }
    .accordion {
        .card-header {
            background: #F2F2F2;
            &.even {
                border-bottom: solid;
                border-color: #8A0D67;
                padding: 0;
                .company-name {
                    color: #8A0D67;
                    font-weight: 600;
                    font-size: 15px;
                }
                .send-date {
                    color: #666565;
                    font-weight: 300;
                    font-size: 15px;
                }
            }
            &.odd {
                border-bottom: solid;
                border-color: #0D4C8A;
                padding: 0;
                .company-name {
                    color: #0D4C8A;
                    font-weight: 600;
                    font-size: 15px;
                }
                .send-date {
                    color: #666565;
                    font-weight: 300;
                    font-size: 15px;
                }
            }
        }
    }
    .box-company-data {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px 10px  0;
        background: #42782714;
    }

    fieldset {
        border: 1px solid #dcdcdc;
        border-radius: 8px;
        height: auto;
    }

    legend {
        width: auto;
        padding-right: 5px;
        font-size: 16px;
        font-weight: 500;
    }
</style>