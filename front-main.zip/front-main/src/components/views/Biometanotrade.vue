<template>
  <HeaderMain v-if="!currentUser" />
  <div class="container pb-4">
    <div class="row mt-4">
      <div class="col-sm-12">
        <router-link :to="{ name: 'home' }">
          <span class="mr-1"> Voltar para home</span>
        </router-link>
        <div class="home-section-title my-4">
          <h2>Sobre o<br><span class="color-2">BiometanoTrade</span></h2>
          <span class="subtitle">como funciona a plataforma</span>
        </div>
        <div>
          <img
                src="@/assets/images/illustration-the-app.png"
                class="float-right"
            >
          <p>No mundo atual, o consenso sobre a necessidade de qualificação exige a precisão e a definição das posturas dos órgãos dirigentes com relação às suas atribuições.</p>
          <p>Por outro lado, o consenso sobre a necessidade de qualificação exige a precisão e a definição dos relacionamentos verticais entre as hierarquias.Gostaria de enfatizar que o desafiador cenário globalizado talvez venha a ressaltar a relatividade dos procedimentos normalmente adotados.</p>
          <p>No mundo atual, o consenso sobre a necessidade de qualificação exige a precisão e a definição das posturas dos órgãos dirigentes com relação às suas atribuições.</p>
          <p>Por outro lado, o consenso sobre a necessidade de qualificação exige a precisão e a definição dos relacionamentos verticais entre as hierarquias.Gostaria de enfatizar que o desafiador cenário globalizado talvez venha a ressaltar a relatividade dos procedimentos normalmente adotados.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import UserService from '../../services/user.service';
import HeaderMain from '../common/HeaderMain.vue';

export default {
  name: 'Biometanotrade',
  components: {
    HeaderMain
  }, 
  data() {
    return {
      content: ''
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  mounted() {
    // UserService.getPublicContent().then(
    //   response => {
    //     this.content = response.data;
    //   },
    //   error => {
    //     this.content =
    //       (error.response && error.response.data && error.response.data.message) ||
    //       error.message ||
    //       error.toString();
    //   }
    // );
  }
};
</script>
<style scoped lang="scss">
  img {
    max-width: 100%;
  }
  hr {
    border: 0;
    height: 2px;
    width: 30%;
    position: relative;
    margin: 30px auto;
    
    &.center-diamond{
      background: green;
      
      &:before{
        content: "";
        width: 10px;
        height: 10px;
        background: green;
        display: inline-block;
        border: 2px solid green;
        position: absolute;
        top: -3px;
        left: 50%;
        margin: 0 0 0 -3px;
        transform:rotate(45deg);
        -ms-transform:rotate(45deg); /* IE 9 */
        -webkit-transform:rotate(45deg); /* Opera, Chrome, and Safari */
      }
    }
    
    &.center-square{
      background: green;
      
      &:before{
        content: "";
        width: 6px;
        height: 6px;
        background: green;
        display: inline-block;
        border: 2px solid green;
        position: absolute;
        top: -5px;
        left: 50%;
        margin: 0 0 0 -3px;
      }
    }
    
  }
  .subtitle {
      color: #346003;
    }
  .home-section-title {
    h2 {
      color: #78C424;
      font-weight: 900;

      .color-2 {
        color: #46780D;
      }
    }
  }
</style>