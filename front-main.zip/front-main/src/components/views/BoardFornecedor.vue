<template>
  <div class="container pt-5">
    <div class="row">
      <div class="col-sm-12 col-md-8">
        <div class="row">
          <div class="col-sm-6">
            <div class="card card-dash p-3">
              <h5 class="card-dash-title" style="text-transform: none;">Ofertas de Venda</h5>
              <div class="row">
                <div class="col-sm-12 my-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="@/assets/images/icon-cenergy.png"
                      class="mr-2"
                    >
                    <div>
                      <div>
                        <span>Biometano</span>
                      </div>
                      <div>
                        <span class="card-dash-data  mr-1">{{totalBioSellOffers}}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 my-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="@/assets/images/icon-cenergy.png"
                      class="mr-2"
                    >
                    <div>
                      <div>
                        <span>Biometano com Certificado</span>
                      </div>
                      <div>
                        <span class="card-dash-data  mr-1">{{totalBioCertSellOffers}}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 my-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="@/assets/images/icon-cenergy.png"
                      class="mr-2"
                    >
                    <div>
                      <div>
                        <span>Certificado</span>
                      </div>
                      <div>
                        <span class="card-dash-data  mr-1">{{totalCertSellOffers}}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card card-dash p-3">
              <h5 class="card-dash-title" style="text-transform: none;">Ofertas de Compra</h5>
              <div class="row">
                <div class="col-sm-12 my-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="@/assets/images/icon-cenergy.png"
                      class="mr-2"
                    >
                    <div>
                      <div>
                        <span>Biometano</span>
                      </div>
                      <div>
                        <span class="card-dash-data  mr-1">{{totalBioBuyOffers}}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 my-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="@/assets/images/icon-cenergy.png"
                      class="mr-2"
                    >
                    <div>
                      <div>
                        <span>Biometano com Certificado</span>
                      </div>
                      <div>
                        <span class="card-dash-data  mr-1">{{totalBioCertBuyOffers}}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 my-2">
                  <div class="d-flex align-items-center">
                    <img
                      src="@/assets/images/icon-cenergy.png"
                      class="mr-2"
                    >
                    <div>
                      <div>
                        <span>Certificado</span>
                      </div>
                      <div>
                        <span class="card-dash-data  mr-1">{{totalCertBuyOffers}}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row mt-4" style="
    height: 300px;
">
          <div class="col-sm-12">
            <div class="card card-dash dash-map p-3">
              <h4 class="card-dash-title">Fornecedores e Consumidores</h4>
              <MapaSimples />
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-4">
        <div class="card card-dash p-3">
          <h4 class="card-dash-title">Últimas Notícias</h4>
          <div class="last-news" v-for="(item, index) in news">
            <template v-if="index < 3">
              <div class="mb-2">
                <h5 class="last-news-title">{{item.titulo}}</h5>
                <small>{{item.data}}</small>
              </div>
              <p>{{item.texto}}</p>
              <a @click="viewNews(item.id)">Leia Mais +</a>
            </template>
          </div>
          <router-link class="link-news" :to="{ name: 'list-news' }">
            <span class="mr-1">Todas as notícias</span>
          </router-link>
        </div>
      </div>
    </div>
    <div class="row my-4">
      <div class="col-sm-12 col-md-6">
        <div class="card card-dash p-3">
          <h4 class="card-dash-title" style="text-transform: none;">Ofertas de Venda</h4>
          <table class="table-home">
            <thead>
              <tr>
                <th>Tipo</th>
                <th>Fornecedor</th>
                <th>Quantidade Total</th>
                <th>Preço</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in sellOffers">
                  <td class="p-2 my-2">{{item.ofertaTipo.nome}}</td>
                  <td class="p-2 my-2">{{item.empresa.nomeFatasia}}</td>
                  <template v-if="item.ofertaTipo.id == 1 || item.ofertaTipo.id == 2">
                    <td class="p-2 my-2">{{item.quantidade}}</td>
                  </template>
                  <template v-else v-for="negotiationItem in item.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                    <td class="p-2 my-2" v-if="negotiationItem.idItem === 22">
                      {{ negotiationItem.valor }}
                    </td>
                  </template>
                  <template v-if="item.ofertaTipo.id == 1 || item.ofertaTipo.id == 2 " v-for="negotiationItem in item.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                      <td class="p-2 my-2" v-if="negotiationItem.idItem === 13">
                          {{ formatAsCurrency(negotiationItem.valor) }}(por m³)
                      </td>
                  </template>
                  <template v-if="item.ofertaTipo.id == 3 " v-for="negotiationItem in item.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                      <td class="p-2 my-2" v-if="negotiationItem.idItem === 17">
                          {{ formatAsCurrency(negotiationItem.valor) }}(por certificado)
                      </td>
                  </template>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-sm-12 col-md-6">
        <div class="card card-dash p-3" style="min-height: 97%">
          <h4 class="card-dash-title" style="text-transform: none;">Ofertas de Compra</h4>
          <table class="table-home">
            <thead>
              <tr>
                <th>Tipo</th>
                <th>Consumidor</th>
                <th>Quantidade Total</th>
                <th>Preço</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in buyOffers">
                <td class="p-2 my-2">{{item.ofertaTipo.nome}}</td>
                <td class="p-2 my-2">{{item.empresa.nomeFatasia}}</td>
                <template v-if="item.ofertaTipo.id == 1 || item.ofertaTipo.id == 2 ">
                  <td class="p-2 my-2">{{item.quantidade}}</td>
                </template>
                <template v-if="item.ofertaTipo.id == 3 " v-for="negotiationItem in item.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                    <td class="p-2 my-2" v-if="negotiationItem.idItem === 22">
                        {{ negotiationItem.valor }}
                    </td>
                </template>
                <template v-if="item.ofertaTipo.id == 1 || item.ofertaTipo.id == 2 " v-for="negotiationItem in item.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                    <td class="p-2 my-2" v-if="negotiationItem.idItem === 13">
                        {{ formatAsCurrency(negotiationItem.valor) }}<small>(por m³)</small>
                    </td>
                </template>
                <template v-if="item.ofertaTipo.id == 3 " v-for="negotiationItem in item.listaNegociacaoRodada[0].listaNegociacaoPropostas" :key="negotiationItem.id">
                    <td class="p-2 my-2" v-if="negotiationItem.idItem === 17">
                        {{ formatAsCurrency(negotiationItem.valor) }}<small>(por certificado)</small>
                    </td>
                </template>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="row mt-4 pb-5">
      <div class="col-12">
        <div class="card card-dash p-3 mt-2">
          <h4 class="card-dash-title">Minhas Negociações</h4>
          <table class="table-home">
            <thead>
              <tr>
                <th>Tipo de oferta</th>
                <th>Fornecedor</th>
                <th>Consumidor</th>
                <th>Rodada Atual</th>
                <th>Data da Rodada</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in negotiationSellOffers">
                <td class="p-2 my-2">Compra ({{item.ofertaTipo.nome}})</td>
                <td class="p-2 my-2">{{item.empresa.nomeFatasia}}</td>
                <td class="p-2 my-2">{{item.empresaPrivada.nomeFatasia}}</td>
                <td class="p-2 my-2">Rodada {{item.listaNegociacaoRodada[0].rodada}}. Enviada por {{item.listaNegociacaoRodada[0].empresaProponente.nomeFatasia}}</td>
                <td class="p-2 my-2">{{formatDate(item.listaNegociacaoRodada[0].dataRodada)}}</td>
                <td class="p-2 my-2">
                  <button @click="editItem(item.id)" class="btn btn-only-icon-primary">
                    <i class="bi bi-pencil-square"></i>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import UserService from '../../services/user.service';
import NewsService from '../../services/news.service';
import OfferService from '../../services/offer.service';
import Mapa from './Mapa.vue';
import MapaSimples from './MapaSimples.vue';

export default {
  name: 'Fornecedor',
  components: {
    Mapa,
    MapaSimples
  },
  data() {
    return {
      news: [],
      responseMsg: '',
      page: 0,
      size: 5,
      idTipoOferta: 1,
      idSituacaoIniciada: "1",
      idSituacaoAndamento: "3",
      tipoOfertaVenda: "V",
      tipoOfertaCompra: "C",
      sellOffers:{},
      buyOffers:{},
      negotiationSellOffers:{},
      totalBioSellOffers: 0,
      totalBioCertSellOffers: 0,
      totalCertSellOffers: 0,
      totalBioBuyOffers: 0,
      totalBioCertBuyOffers: 0,
      totalCertBuyOffers: 0,
      priceMask: {
        decimal: ",",
        separator: ".",
        prefix: "R$",
        suffix: "",
        precision: 2,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      maskTotalBiometano: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
      number: {
        decimal: ".",
        separator: ".",
        prefix: "",
        suffix: "m³",
        precision: 0,
        nullValue: "",
        masked: true,
        reverseFill: true,
        prefill: true
      },
    };
  },
  mounted() {
    NewsService.getAll(this.page, this.limit).then(
      response => {
        this.news = response.data.content;
        this.news.forEach((item) => {
            if (item.texto.length > 120) {
                item.texto = item.texto.substring(0, 120) + '...';
            }
            item.data = this.formatDate(item.data)
        });
        
      },
      error => {
        console.log("Erro", error)
        this.responseMsg = error.response.data.message
        // this.content =
        //   (error.response && error.response.data && error.response.data.message) ||
        //   error.message ||
        //   error.toString();
      }
    );
    this.getSellOffers();
    this.getBuyOffers();
    this.getNegotiations();
    this.getBiomethaneSellOffers();
    this.getBiomethaneCertSellOffers();
    this.getCertSellOffers();
    this.getBiomethaneBuyOffers();
    this.getBiomethaneCertBuyOffers();
    this.getCertBuyOffers();
    // UserService.getModeratorBoard().then(
    //   response => {
    //     this.content = response.data;
    //   },
    //   error => {
    //     this.content =
    //       (error.response && error.response.data && error.response.data.message) ||
    //       error.message ||
    //       error.toString();
    //   }
    // );
  },
  computed: {
    // Define a computed property to format the "valor" as currency
    formatAsCurrency() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
            let valueInCentavos = valor;
            let valueInReais = valueInCentavos / 100
            let formattedValue = valueInReais.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
            return formattedValue;
          //return Number(valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        return '';
      };
    },
  },
  methods: {
    formatDate(inputDate) {
      const date = new Date(inputDate);
      
      // Extract date components
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based
      const year = date.getFullYear();

      // Construct the formatted date string
      const formattedDate = `${day}/${month}/${year}`;

      return formattedDate;
    },
    getSellOffers() {
      OfferService.getAll(this.page, this.size, this.tipoOfertaVenda, this.idSituacaoIniciada).then(
        response => {
          console.log("Ofertas venda", response.data.content)
          this.sellOffers = response.data.content
          this.sellOffers.forEach((item) => {
            if(item.listaNegociacaoRodada) {
              const biomethaneMonthlyDelivery = item.listaNegociacaoRodada[0].listaEntregaSazonais
              const negotiationItems = item.listaNegociacaoRodada[0].listaNegociacaoPropostas
              // console.log("entregas", biomethaneMonthlyDelivery)
              //console.log("negociação", biomethaneMonthlyDelivery)
              
              if(biomethaneMonthlyDelivery) {
                  biomethaneMonthlyDelivery.forEach((month) => {
                      if (month.mes == 1) month.mes = "Janeiro"
                      if (month.mes == 2) month.mes = "Fevereiro"
                      if (month.mes == 3) month.mes = "Março"
                      if (month.mes == 4) month.mes = "Abril"
                      if (month.mes == 5) month.mes = "Maio"
                      if (month.mes == 6) month.mes = "Junho"
                      if (month.mes == 7) month.mes = "Julho"
                      if (month.mes == 8) month.mes = "Agosto"
                      if (month.mes == 9) month.mes = "Setembro"
                      if (month.mes == 10) month.mes = "Outubro"
                      if (month.mes == 11) month.mes = "Novembro"
                      if (month.mes == 12) month.mes = "Dezembro"
                      // console.log("entregas mes", month.mes)
                  });
              }
            }
          });
          
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getBuyOffers() {
      OfferService.getAll(this.page, this.size, this.tipoOfertaCompra, this.idSituacaoIniciada).then(
        response => {
          console.log("Ofertas de compra", response.data.content)
          this.buyOffers = response.data.content
          this.buyOffers.forEach((item) => {
            if(item.listaNegociacaoRodada) {
              const biomethaneMonthlyDelivery = item.listaNegociacaoRodada[0].listaEntregaSazonais
              const negotiationItems = item.listaNegociacaoRodada[0].listaNegociacaoPropostas
              // console.log("entregas", biomethaneMonthlyDelivery)
              console.log("negociação", biomethaneMonthlyDelivery)
              
              if(biomethaneMonthlyDelivery) {
                  biomethaneMonthlyDelivery.forEach((month) => {
                      if (month.mes == 1) month.mes = "Janeiro"
                      if (month.mes == 2) month.mes = "Fevereiro"
                      if (month.mes == 3) month.mes = "Março"
                      if (month.mes == 4) month.mes = "Abril"
                      if (month.mes == 5) month.mes = "Maio"
                      if (month.mes == 6) month.mes = "Junho"
                      if (month.mes == 7) month.mes = "Julho"
                      if (month.mes == 8) month.mes = "Agosto"
                      if (month.mes == 9) month.mes = "Setembro"
                      if (month.mes == 10) month.mes = "Outubro"
                      if (month.mes == 11) month.mes = "Novembro"
                      if (month.mes == 12) month.mes = "Dezembro"
                      // console.log("entregas mes", month.mes)
                  });
              }
            }
          });
          
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getNegotiations() {
      OfferService.getAll(this.page, this.size, 'C,V', this.idSituacaoAndamento).then(
        response => {
          console.log("Ofertas em negociação", response.data.content)
          this.negotiationSellOffers = response.data.content
          this.negotiationSellOffers.forEach((item) => {
            if(item.listaNegociacaoRodada) {
              const biomethaneMonthlyDelivery = item.listaNegociacaoRodada[0].listaEntregaSazonais
              const negotiationItems = item.listaNegociacaoRodada[0].listaNegociacaoPropostas
              // console.log("entregas", biomethaneMonthlyDelivery)
              console.log("negociação", biomethaneMonthlyDelivery)
              
              if(biomethaneMonthlyDelivery) {
                  biomethaneMonthlyDelivery.forEach((month) => {
                      if (month.mes == 1) month.mes = "Janeiro"
                      if (month.mes == 2) month.mes = "Fevereiro"
                      if (month.mes == 3) month.mes = "Março"
                      if (month.mes == 4) month.mes = "Abril"
                      if (month.mes == 5) month.mes = "Maio"
                      if (month.mes == 6) month.mes = "Junho"
                      if (month.mes == 7) month.mes = "Julho"
                      if (month.mes == 8) month.mes = "Agosto"
                      if (month.mes == 9) month.mes = "Setembro"
                      if (month.mes == 10) month.mes = "Outubro"
                      if (month.mes == 11) month.mes = "Novembro"
                      if (month.mes == 12) month.mes = "Dezembro"
                      // console.log("entregas mes", month.mes)
                  });
              }
            }
          });
          
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getBiomethaneSellOffers() {
      OfferService.getAllOnlyBiomethane(this.page, 50, this.tipoOfertaVenda, this.idSituacaoIniciada).then(
        response => {
          console.log("total bio", response.data.content.length)
          this.totalBioSellOffers = response.data.content.length;
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getBiomethaneCertSellOffers() {
      OfferService.getAllBiomethaneCert(this.page, 50, this.tipoOfertaVenda, this.idSituacaoIniciada).then(
        response => {
          console.log("total bio certificado", response.data.content.length)
          this.totalBioCertSellOffers = response.data.content.length;
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getCertSellOffers() {
      OfferService.getAllOnlyCert(this.page, 50, this.tipoOfertaVenda, this.idSituacaoIniciada).then(
        response => {
          console.log("total certificados", response.data.content.length)
          this.totalCertSellOffers = response.data.content.length;
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getBiomethaneBuyOffers() {
      OfferService.getAllOnlyBiomethane(this.page, 50, this.tipoOfertaCompra, this.idSituacaoIniciada).then(
        response => {
          console.log("total bio COmpra", response.data.content.length)
          this.totalBioBuyOffers = response.data.content.length;
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getBiomethaneCertBuyOffers() {
      OfferService.getAllBiomethaneCert(this.page, 50, this.tipoOfertaCompra, this.idSituacaoIniciada).then(
        response => {
          console.log("total bio certificado Compra", response.data.content.length)
          this.totalBioCertBuyOffers = response.data.content.length;
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    getCertBuyOffers() {
      OfferService.getAllOnlyCert(this.page, 50, this.tipoOfertaCompra, this.idSituacaoIniciada).then(
        response => {
          console.log("total certificados compra", response.data.content.length)
          this.totalCertBuyOffers = response.data.content.length;
        },
        error => {
          console.log("Erro", error)
          // this.content =
          //   (error.response && error.response.data && error.response.data.message) ||
          //   error.message ||
          //   error.toString();
        }
      );
    },
    editItem(itemId) {
        this.$store.commit('offer/setOfferId', itemId);
        this.$router.push({ name: "edit-item"});
    },
    viewNews(newsId) {
        this.$store.commit('news/setNewsId', newsId);
        this.$router.push({ name: "view-news"});
    }
  }
};
</script>
<style scoped lang="scss">
  .table-home {
    font-size: 14px;
    width: 100%;
  }
  .last-news-title {
    font-size: 15px;
    margin: 0;
    font-weight: 600
    small {
      font-size: 11px;
      text-align: right;
      display: block;
    }
  }
  .last-news {
    margin-bottom: 20px;
    border-bottom: 1px solid #ccc;
  }
  .card-dash-title {
    color: #00A78E;
    font-weight: 600;
    font-size: 18px;
    
  }
  .card-dash-data {
   color: #46780D;
   font-weight: 600;
   font-size: 18px;
  }
  .card-dash-legend {
    color: #46780D;
    font-weight: 300;
    font-size: 13px;
  }
  .card-dash-currency {
    color: #46780D;
    font-weight: 300;
    font-size: 14px;
  }
  .link-news {
    color: #8A0D67;
    text-decoration: underline;
    text-align: right;
    margin-top: 20px
  }
</style>