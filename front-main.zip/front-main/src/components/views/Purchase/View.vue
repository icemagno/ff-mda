<template>
  <div class="container pl-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3 v-if="currentUser.roles == 'CONSUMIDOR'">Compras</h3>
      <h3 v-if="currentUser.roles == 'FORNECEDOR'">Vendas</h3>
      <h3 v-if="currentUser.roles == 'ADMIN'">Vendas</h3>
    </div>
    <div class="breadcrumb">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <span v-if="currentUser.roles == 'CONSUMIDOR'" class="active"> Compras</span>
      <span v-else class="active"> Vendas</span>
    </div>
    <div v-if="purchase.oferta?.ofertaTipo.id == 1 || purchase.oferta?.ofertaTipo.id == 2" class="d-flex tabs-menu mt-4">
      <div @click="setSelectedTab(1)" :class="{ active: selectedTab === 1 }" class="tab">Dados da Venda</div>
      <div @click="setSelectedTab(2)" :class="{ active: selectedTab === 2 }" class="tab">Contrato</div>
      <div @click="setSelectedTab(3)" :class="{ active: selectedTab === 3 }" class="tab">Acompanhamento do Contrato</div>
    </div>
    <div class="tabs-container">
      <div class="tab-content" :class="{ active: selectedTab === 1 }">
        <template v-if="purchase.oferta?.ofertaTipo.id == 3">
          <h5 class="form-section-title">Dados do comprador</h5>
          <div class="form-row">
            <div class="col-sm-12 col-md-7">
              <label for="desc">Razão social</label>
              <div class="form-control readonly-field">{{purchase.empresa?.razaoSocial}}</div>
            </div>
            <div class="col-sm-12 col-md-3">
              <label for="desc">Nome fantasia</label>
              <div class="form-control readonly-field">{{purchase.empresa?.nomeFatasia}}</div>
            </div>
            <div class="col-sm-12 col-md-2">
              <label for="desc">CNPJ</label>
              <div v-maska data-maska="##.###.###/####-##" class="form-control readonly-field">{{purchase.empresa?.cnpj}}</div>
            </div>
          </div>
          <h5 class="form-section-title mt-4">Dados do Certificado</h5>
          <div class="form-row justify-content-center">
            <div class="col-sm-12 col-md-4">
              <label for="desc">Quantidade de certificados</label>
              <div class="form-control readonly-field">{{purchase?.quantidadeCertificado}}</div>
            </div>
            <div class="col-sm-12 col-md-4">
              <label for="desc">Preço por certificado</label>
              <div class="form-control readonly-field">{{formatAsCurrency(purchase?.valorCertificado)}}</div>
            </div>
          </div>
        </template>
        <template v-else>
          <h5 class="form-section-title">Dados do comprador</h5>
          <div class="form-row">
            <div class="col-sm-12 col-md-7">
              <label for="desc">Razão social</label>
              <div class="form-control readonly-field">{{purchase.empresa?.razaoSocial}}</div>
            </div>
            <div class="col-sm-12 col-md-3">
              <label for="desc">Nome fantasia</label>
              <div class="form-control readonly-field">{{purchase.empresa?.nomeFatasia}}</div>
            </div>
            <div class="col-sm-12 col-md-2">
              <label for="desc">CNPJ</label>
              <div v-maska data-maska="##.###.###/####-##" class="form-control readonly-field">{{purchase.empresa?.cnpj}}</div>
            </div>
          </div>
          <h5 class="form-section-title mt-5">Dados da entrega</h5>
          <div class="form-row">
            <div class="col-sm-12 col-md-7">
              <label for="desc">Tipo frete</label>
              <div class="form-control readonly-field">{{purchase.freteTipo?.sigla}}</div>
            </div>
            <div class="col-sm-12 col-md-3">
              <label for="desc">Logística</label>
              <div class="form-control readonly-field">Duto de transporte</div>
            </div>
            <div class="col-sm-12 col-md-2">
              <label for="desc">Valor total do frete</label>
              <div class="form-control readonly-field">{{purchase?.valorFrete}}</div>
            </div>
          </div>
          <div class="form-row">
            <div class="col-sm-12 col-md-3">
              <label for="desc">Local de entrega</label>
              <div class="form-control readonly-field">{{purchase.localEntrega?.nome}}</div>
            </div>
            <div class="col-sm-12 col-md-5">
              <label for="desc">Endereço</label>
              <div class="form-control readonly-field">{{purchase.localEntrega?.endereco.logradouro}}</div>
            </div>
            <div class="col-sm-12 col-md-2">
              <label for="desc">Cidade</label>
              <div class="form-control readonly-field">{{purchase.localEntrega?.endereco.cidade}}</div>
            </div>
            <div class="col-sm-12 col-md-2">
              <label for="desc">Estado</label>
              <div class="form-control readonly-field">{{purchase.localEntrega?.endereco.estado}}</div>
            </div>
          </div>
          <h5 class="form-section-title mt-5">Dados de fornecimento</h5>
          <div class="form-row">
            <div class="col-sm-12 col-md-3">
              <label for="desc">Inicio do fornecimento</label>
              <div class="form-control readonly-field">{{purchase.dataInicioEntrega}}</div>
            </div>
            <div class="col-sm-12 col-md-3">
              <label for="desc">Fim do fornecimento</label>
              <div class="form-control readonly-field">{{purchase.dataFimEntrega}}</div>
            </div>
            <div class="col-sm-12 col-md-3">
              <label for="desc">Modalidade</label>
              <div class="form-control readonly-field">{{purchase.flexibilidade ? 'Firme' : 'Flexível'}}</div>
            </div>
            <div class="col-sm-12 col-md-3">
              <label for="desc">Tipo de fornecimento</label>
              <div class="form-control readonly-field">{{purchase.sazonalidade ? 'Sazonal' : 'Contínua'}}</div>
            </div>
          </div>
          <div class="form-row">
            <div class="col-sm-12 col-md-4">
              <label for="desc">Quantidade total (m³)</label>
              <div class="form-control readonly-field">{{purchase.quantidade}}</div>
            </div>
            <div class="col-sm-12 col-md-4">
              <label for="desc">Valor total</label>
              <div class="form-control readonly-field">{{purchase.valor}}</div>
            </div>
          </div>
        </template>
      </div>
      <div class="tab-content" :class="{ active: selectedTab === 2 }">
        <fieldset class="px-4 py-2">
          <legend class="mx-2 px-2">Informações adicionais do contrato</legend>
          <Form @submit="saveContrato" :validation-schema="schema">
            <div class="row">
              <div class="col-sm-12 col-md-4">
                <label for="desc">Pressão de fornecimento</label>
                <div class="d-flex input-with-suffix">
                  <Field v-maska data-maska="['#.#','##.#','###.#','#.###.#','##.###.#','###.###.#','#.###.###.#','##.###.###.#','###.###.###.#','###.###.###.###.#']" class="form-control" type="text" name="pressao" />
                  <div class="legend">kgf/cm2g</div>
                </div>
                <ErrorMessage name="pressao" class="error-feedback" />
              </div>
              <div class="col-sm-12 col-md-4">
                <label for="desc">Vazão de fornecimento</label>
                <div class="d-flex input-with-suffix">
                  <Field v-maska data-maska="['#.#','##.#','###.#','#.###.#','##.###.#','###.###.#','#.###.###.#','##.###.###.#','###.###.###.#','###.###.###.###.#']" class="form-control" type="text" name="vazao" />
                  <div class="legend">mil m3/h</div>
                </div>
                <ErrorMessage name="vazao" class="error-feedback" />
              </div>
              <div class="col-sm-12 col-md-4">
                <label for="desc">Poder Calorifico ref</label>
                <div class="d-flex input-with-suffix">
                  <Field class="form-control" type="text" name="poderref" />
                  <div class="legend">kcal/m3</div>
                </div>
                  <ErrorMessage name="poderref" class="error-feedback" />
              </div>
            </div>
            <div class="row justify-content-center">
              <div class="col-sm-12 col-md-4">
                <label for="desc">Poder Calorifico sup</label>
                <div class="d-flex input-with-suffix">
                  <Field class="form-control" type="text" name="podersup" />
                  <div class="legend">kcal/m3</div>
                </div>
                <ErrorMessage name="podersup" class="error-feedback" />
              </div>
              <div class="col-sm-12 col-md-4">
                <label for="desc">Ponto de entrega</label>
                <Field class="form-control" type="text" name="ponto" />
                <ErrorMessage name="ponto" class="error-feedback" />
              </div>
              <div class="col-sm-12 col-md-4">
                <label for="desc">Qualidade do gás</label>
                <Field class="form-control" type="text" name="qualidade" />
                <ErrorMessage name="qualidade" class="error-feedback" />
              </div>
            </div>
            <div
                v-if="message"
                class="alert"
                :class="successful ? 'alert-success' : 'alert-danger'"
            >
                {{ message }}
            </div>
            <div class="d-flex justify-content-center mt-5 pb-5">
                <button class="btn btn-primary mr-3">Atualizar contrato</button>
                <button @click.prevent="downloadContratoDoc()" class="btn btn-primary mr-3">Download do contrato (.doc)</button>
            </div>
          </Form>
        </fieldset>
        <Object class="embed-pdf" :data="contrato"> </Object>
      </div>
      <div class="tab-content" :class="{ active: selectedTab === 3 }">
        <div class="mb-4">
          <fieldset class="p-3">
            <legend>Envio de relatório anual</legend>
            <input type="file" ref="fileInput" @change="handleFileChange" />
            <button class="btn btn-primary ml-3" @click="uploadFile">Enviar arquivo selecionado</button>
          </fieldset>
        </div>

        <div class="row" v-if="relatoriosContrato.length > 0">
          <div class="col-2 relatorios-list">
            
              <template v-for="(upload, index) in relatoriosContrato" :key="upload.id">
                <div class="btn-relatorio mb-1" @click="selectRelatorio(upload.id)">Relatório {{index + 1}}</div>
              </template>
            
            
          </div>
          <div class="col-10">
            <Object v-if="selectedRelatorio" class="embed-pdf" :data="selectedRelatorio"> </Object>
            <div v-else>Selecione um relatório.</div>
          </div>
        </div>
        <div class="row" v-else>
          <div class="col-12">
            <div>Nenhum relatório enviado até o momento.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { environment } from '@/store/environment';
import authHeader from '@/services/auth-header';
import { Form, Field, ErrorMessage } from "vee-validate";
import { atob } from 'atob';
import PurchaseService from '../../../services/purchase.service';
import VuePdfEmbed from 'vue-pdf-embed';
import { vMaska } from "maska";
import { saveAs } from 'file-saver';
import * as yup from "yup";

export default {
  name: "view-purchase",
  components: {
      Form,
      Field,
      ErrorMessage,
      VuePdfEmbed
  },
  directives: { maska: vMaska },
  data() {
    const schema = yup.object().shape({
      pressao: yup.string().required("Preencha este campo"),
      vazao: yup.string().required("Preencha este campo"),
      poderref: yup.string().required("Preencha este campo"),
      podersup: yup.string().required("Preencha este campo"),
      ponto: yup.string().required("Preencha este campo"),
      qualidade: yup.string().required("Preencha este campo"),
    });
    return {
      purchase:{},
      contrato: null,
      file: null,
      selectedTab: 1,
      idContrato: null,
      relatoriosContrato: {},
      selectedRelatorio: null,
      schema
    };
  },
  mounted() {
    this.getPurchase();
    //this.getContrato();
    //this.getPdf();
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    purchaseId() {
      return this.$store._state.data.purchase.purchaseId;
    },
    empresaRazaoSocial() {
      return this.purchase && this.purchase.empresa ? this.purchase.empresa.razaoSocial : '';
    },
    formatAsCurrency() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
            let valueInCentavos = valor;
            let valueInReais = valueInCentavos / 100
            let formattedValue = valueInReais.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
            return formattedValue;
          //return Number(valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        return '';
      };
    },
  },
  methods: {
    formatDate(inputDate) {
      const date = new Date(inputDate);
      
      // Extract date components
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based
      const year = date.getFullYear();

      // Construct the formatted date string
      const formattedDate = `${day}/${month}/${year}`;

      return formattedDate;
    },
    handleFileChange(event) {
      this.file = event.target.files[0];
    },
    uploadFile() {
      if (!this.file) {
        console.error('Please select a file.');
        return;
      }

      const formData = new FormData();
      formData.append('arquivo', this.file);
      formData.append('Content-Type', 'multipart/form-data');

      axios.post(`${environment.API_URL}drwars/api/v1/relatorioanuais?idcompra=${this.purchaseId}`, formData, {
        headers: authHeader(),
      })
      .then(response => {
        this.listAcompanhamentosContrato();
        console.log('File uploaded successfully:', response.data);
        // Handle the response as needed
      })
      .catch(error => {
        console.error('Error uploading file:', error);
        // Handle the error as needed
      });
    },
    saveContrato(contrato) {
        contrato.IdDoContrato = this.idContrato;
        this.$store.dispatch("purchase/saveContrato", contrato).then(
          (data) => {
            console.log("teste", contrato.pressao)
            if(!contrato.pressao) {
              this.message = "Erro";
            }
            this.message = "Contrato atualizado.";
            this.successful = true;
            this.loading = false;
            this.getPdf();
          },
          (error) => {
            console.log("erro ao salvar contrato", error)
            this.message =
              (error.response &&
                error.response.data &&
                error.response.data.message) ||
              error.message ||
              error.toString();
            this.successful = false;
            this.loading = false;
          }
        );
    },
    setSelectedTab(tab) {
      this.selectedTab = tab;
      if(tab === 2 ) {
        //this.listContratos();
        this.getPdf();
      }
      if(tab === 3 ) {
        //this.listContratos();
        this.listAcompanhamentosContrato();
      }
    },
    getPurchase() {
      PurchaseService.viewPurchase(this.purchaseId).then(
        response => {
            console.log("compra", response.data)
            this.purchase = response.data;
            this.purchase.dataFimEntrega = this.formatDate(this.purchase.dataFimEntrega)
            this.purchase.dataInicioEntrega = this.formatDate(this.purchase.dataInicioEntrega)
            this.purchase.valor = this.formatAsCurrency(this.purchase.valor)
            this.purchase.valorFrete = this.formatAsCurrency(this.purchase.valorFrete)
        },
        error => {
            console.log("Erro", error)
            // this.content =
            //   (error.response && error.response.data && error.response.data.message) ||
            //   error.message ||
            //   error.toString();
        }
      );
    },
     async listAcompanhamentosContrato(){
      try {
        const response = await axios.get(`${environment.API_URL}drwars/api/v1/relatorioanuais/compra/${this.purchaseId}`, {
          headers: authHeader()
        });
        console.log("relatorios", response)
        this.relatoriosContrato = response.data;
        
        
      } catch (error) {
        console.error('Error fetching PDF:', error);
      }
    },
    async listContratos(){
      try {
        const response = await axios.get(`${environment.API_URL}drwars/api/v1/contratos/compra/${this.purchaseId}`, {
          headers: authHeader()
        });
        console.log("os contratos", response)
        this.idContrato = response.data[0].id;
        
        
      } catch (error) {
        console.error('Error fetching PDF:', error);
      }
    },
    async getPdf() {
      try {
        const contratos = await this.listContratos();
        const response = await axios.get(`${environment.API_URL}drwars/api/v1/contratos/pdf/${this.idContrato}`, {
          headers: authHeader(),
          responseType: 'arraybuffer'
        });

        const base64String = btoa(new Uint8Array(response.data).reduce((data, byte) => data + String.fromCharCode(byte), ''));
        this.displayPdf(base64String);
      } catch (error) {
        console.error('Error fetching PDF:', error);
      }
    },
    async downloadContratoDoc() {
      try {
        const contratos = await this.listContratos();
        const response = await axios.get(`${environment.API_URL}drwars/api/v1/contratos/doc/${this.idContrato}`, {
          headers: authHeader(),
          responseType: 'arraybuffer'
        });

        const blob = new Blob([response.data], { type: 'application/msword' });

        // Use FileSaver to trigger the download
        saveAs(blob, 'Contrato.doc');
      } catch (error) {
        console.error('Error fetching PDF:', error);
      }
    },
    async selectRelatorio(id) {
      try {
        const response = await axios.get(`${environment.API_URL}drwars/api/v1/relatorioanuais/download/${id}`, {
          headers: authHeader(),
          responseType: 'arraybuffer'
        });

        const base64String = btoa(new Uint8Array(response.data).reduce((data, byte) => data + String.fromCharCode(byte), ''));
        this.displayRelatorio(base64String);
      } catch (error) {
        console.error('Error fetching PDF:', error);
      }
    },
    // getContrato() {
    //   PurchaseService.getContrato(1).then(
    //     response => {
    //         //console.log("contrato", response.data)
    //         //this.contrato = response.data;
    //         const pdfData = response.data;
    //         this.displayPdf(pdfData);
    //     },
    //     error => {
    //         console.log("Erro", error)
    //         // this.content =
    //         //   (error.response && error.response.data && error.response.data.message) ||
    //         //   error.message ||
    //         //   error.toString();
    //     }
    //   );
    // },
    displayPdf(pdfData) {
      this.contrato = 'data:application/pdf;base64,' + pdfData;;
    },
    displayRelatorio(pdfData) {
      this.selectedRelatorio = 'data:application/pdf;base64,' + pdfData;;
    },
    arrayBufferToBase64(buffer) {
      let binary = '';
      const bytes = new Uint8Array(buffer);
      const len = bytes.byteLength;

      for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
      }

      return btoa(binary);
    },
  },
};
</script>

<style scoped lang="scss">
  .tabs-menu {
      border-bottom: 1px solid #d1b5e4;
      margin-bottom: 30px;
      font-size: .85rem;
      color: #ae5de3;
      font-weight: 300;
    .tab {
      margin-right: 10px;
      padding: 0 10px;
      cursor: pointer;
      &.active {
        font-weight: 600;
        border-bottom: 2px solid #ae5de3;
      }
    }
  }
  .tab-content {
    display: none;
    padding: 0 30px 50px;
    &.active {
      display: block;
    }
  }
  .btn-relatorio {
    width: 100%;
    cursor: pointer;
    border: 1px solid #3e9611;
    padding: 10px;
    border-radius: 8px;
    color: #3e9611;
    font-weight: 600;
  }
  .relatorios-list {
    border-right: 1px solid #ccc;
  }
  .form-section-title {
    font-size: 1.1rem;
    font-weight: 400;
    text-transform: uppercase;
  }
  .readonly-field {
    background-color: #e9ecef;
  }
    .embed-pdf {
      width: 100%;
      height: 500px;
    }
    label {
        display: block;
        margin-top: 10px;
    }
    .card-body {
        position: relative;
    }
    .panel-send-proposal {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #fff;
        z-index: 999;
    }
    .form-section-title {
        font-size: 1.1rem;
        font-weight: 400;
        text-transform: uppercase;
    }
    small {
        font-size: 0.7rem;
    }

    .fieldset {
        border: 1px solid #ccc;
        border-radius: 8px;
        legend {
            font-weight: 400;
            font-size: 15px;
            width: auto;
            min-width: auto;
            padding: 0 15px 0 5px;
            margin-left: 7px;
        }
    }
    .accordion {
        .card-header {
            background: #F2F2F2;
            &.even {
                border-bottom: solid;
                border-color: #8A0D67;
                padding: 0;
                .company-name {
                    color: #8A0D67;
                    font-weight: 600;
                    font-size: 15px;
                }
                .send-date {
                    color: #666565;
                    font-weight: 300;
                    font-size: 15px;
                }
            }
            &.odd {
                border-bottom: solid;
                border-color: #0D4C8A;
                padding: 0;
                .company-name {
                    color: #0D4C8A;
                    font-weight: 600;
                    font-size: 15px;
                }
                .send-date {
                    color: #666565;
                    font-weight: 300;
                    font-size: 15px;
                }
            }
        }
    }
    .box-company-data {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px 10px  0;
        background: #42782714;
    }

    fieldset {
        border: 1px solid #dcdcdc;
        border-radius: 8px;
        height: auto;
    }

    legend {
        width: auto;
        padding-right: 5px;
        font-size: 16px;
        font-weight: 500;
    }
    .input-with-suffix {
      background: #fff;
      border: 1px solid #ced4da;
      border-radius: .25rem;
      align-items: center;
      padding-right: 10px;
      .form-control {
        border: none;
        text-align: right;
      }
      .legend {
        white-space: nowrap;
      }
    }
</style>