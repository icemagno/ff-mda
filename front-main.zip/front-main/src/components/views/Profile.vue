<template>
  <div class="container">
    <h3>
      <strong>{{currentUser.perfil.nome}}</strong>
    </h3>
    <p>
      <strong>Login:</strong>
      {{currentUser.username}}
    </p>
    <strong>prefil:</strong>
    <ul>
      <li v-for="(role,index) in currentUser.roles" :key="index">{{role}}</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Profile',
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    }
  },
  mounted() {
    if (!this.currentUser) {
      this.$router.push('/login');
    }
  }
};
</script>