<template>
  <div class="container pl-5 pb-5">
    <div class="title d-flex align-items-start pt-4">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }" class="mr-2">
        <svg fill="#17ad37" height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 384.97 384.97" xml:space="preserve" stroke="#17ad37"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g id="Chevron_Left_Circle"> <path d="M192.485,0C86.185,0,0,86.185,0,192.485C0,298.797,86.173,384.97,192.485,384.97S384.97,298.797,384.97,192.485 C384.97,86.185,298.797,0,192.485,0z M192.485,361.282c-92.874,0-168.424-75.923-168.424-168.797S99.611,24.061,192.485,24.061 s168.424,75.55,168.424,168.424S285.359,361.282,192.485,361.282z"></path> <path d="M235.878,99.876c-4.704-4.74-12.319-4.74-17.011,0l-83.009,84.2c-4.572,4.62-4.584,12.56,0,17.191l82.997,84.2 c4.704,4.74,12.319,4.74,17.011,0c4.704-4.752,4.704-12.439,0-17.191l-74.528-75.61l74.54-75.61 C240.57,112.315,240.57,104.628,235.878,99.876z"></path> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> <g> </g> </g> </g></svg>
      </router-link>
      <h3 v-if="currentUser.roles == 'CONSUMIDOR'">Minhas Compras</h3>
      <h3 v-if="currentUser.roles == 'FORNECEDOR'">Minhas Vendas</h3>
      <h3 v-if="currentUser.roles == 'ADMIN'">Vendas</h3>
    </div>
    <div class="breadcrumb">
      <router-link v-if="currentUser.roles == 'CONSUMIDOR'" :to="{ name: 'consumidor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <router-link v-else :to="{ name: 'fornecedor' }">
        <span class="mr-1">Painel > </span>
      </router-link>
      <span v-if="currentUser.roles == 'ADMIN'" class="active"> Minhas Vendas</span>
      <span v-if="currentUser.roles == 'FORNECEDOR'" class="active"> Minhas Vendas</span>
      <span v-if="currentUser.roles == 'CONSUMIDOR'" class="active"> Minhas Compras</span>
    </div>
    <vue-good-table
          styleClass="vgt-table condensed custom-table"
          :columns="columns"
          :rows="purchases"
          :pagination-options="{
            enabled: true,
            nextLabel: '',
            prevLabel: '',
            rowsPerPageLabel: 'Registros por página',
            ofLabel: 'de',
            pageLabel: 'página', // for 'pages' mode
            allLabel: 'Todos',
            mode: 'pages'
          }"
          :search-options="{ 
            enabled: true,
            placeholder: 'Filtrar',
          }"
          class="table-action"
          >
          <template #emptystate>
            <p class="mt-2" style="text-align:center">Nenhum Registro Encontrado</p>
          </template>
        <template #table-row="props">
            <span v-if="props.column.field == 'action'" class="d-flex">
                <span class="mr-2">
                    <a @click="viewPurchase(props.row.id)">
                    <i class="bi bi-eye"></i>
                    </a>
                </span>
                <!--
                <span class="mr-2">
                    <i class="bi bi-pencil-square"></i>
                </span>
                -->
                </span>
        </template>
    </vue-good-table>
  </div>
</template>

<script>
import axios from 'axios';
import PurchaseService from '../../services/purchase.service';
import { component as VueNumber } from '@coders-tm/vue-number-format';
import { VueGoodTable } from 'vue-good-table-next';

export default {
  name: 'Purchase',
  components: {
    VueNumber,
    VueGoodTable
  },
  data() {
    return {
        columns: [
            {
                label: 'Consumidor',
                field: 'consumidor',
            },
            {
                label: 'Início fornecimento',
                field: 'dataInicioEntrega',
            },
            {
                label: 'Fim fornecimento',
                field: 'dataFimEntrega',
            },
            {
                label: 'Quantidade',
                field: 'quantidade',
            },
            {
                label: 'Preço',
                field: 'valor',
            },
            {
                label: '',
                field: 'action',
            }
        ],
        purchases: [],
        page: 0,
        size: 24,
    }
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    formatAsCurrency() {
      return (valor) => {
        // Check if valor is not empty or null, you can add more validation if needed
        if (valor) {
          // Use Number.toLocaleString() to format as currency
            let valueInCentavos = valor;
            let valueInReais = valueInCentavos / 100
            let formattedValue = valueInReais.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
            return formattedValue;
          //return Number(valor).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        return '';
      };
    },
  },
  mounted() {
    this.getPurchases();
  },
  methods: {
    getPurchases() {
        PurchaseService.getAll().then(
            response => {
                console.log("compras", response.data)
                this.purchases = response.data;
                this.purchases.forEach((item) => {
                    if(this.currentUser.razaoSocial == item.empresa.razaoSocial) {
                      item.consumidor = item.empresaFornecedora.nomeFatasia
                    } else {
                      item.consumidor = item.empresa.nomeFatasia
                    }
                    if(item.oferta.ofertaTipo.id == 3) {
                      item.quantidade = item.quantidadeCertificado
                    }
                    if(item.oferta.ofertaTipo.id == 3) {
                      item.valor = item.valorCertificado
                    }
                    item.dataFimEntrega = this.formatDate(item.dataFimEntrega)
                    item.dataInicioEntrega = this.formatDate(item.dataInicioEntrega)
                    item.valor = this.formatAsCurrency(item.valor)
                });
            },
            error => {
                console.log("Erro", error)
                // this.content =
                //   (error.response && error.response.data && error.response.data.message) ||
                //   error.message ||
                //   error.toString();
            }
        );
    },
    viewPurchase(purchaseId) {
        this.$store.commit('purchase/setPurchaseId', purchaseId);
        this.$router.push({ name: "view-purchase"});
    },
    formatDate(inputDate) {
      const date = new Date(inputDate);
      
      // Extract date components
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based
      const year = date.getFullYear();

      // Construct the formatted date string
      const formattedDate = `${day}/${month}/${year}`;

      return formattedDate;
    }
  },
};
</script>

<style lang="scss" scoped>
    @import '../../assets/styles/variables';
    
</style>