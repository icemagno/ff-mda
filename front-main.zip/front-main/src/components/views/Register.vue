<template>
<div class="register-container">
  <div class="logo-container">
    <a href="/" class="navbar-brand">
        <img
            src="@/assets/images/logo.jpg"
        >
    </a>
  </div>
  <div class="container pl-5">
    <p class="chamada-register mb-5"><span style="
    color: #72c042;
">Cadastre-se</span> e faça parte do maior ecossistema de comércio de biometano do mundo.</p>
    <Form class="register-form" @submit="handleRegister" :validation-schema="schema">
        <div class="form-row">
          <div class="col-md-6">
            <label>Seu nome completo</label>
            <Field class="form-control" name="fullname" type="text" />
            <ErrorMessage name="fullname" class="error-feedback" />
          </div>
          <div class="col-md-6">
            <label>E-mail</label>
            <Field class="form-control" name="email" type="text" />
            <ErrorMessage name="email" class="error-feedback" />
          </div>
        </div>
        <h5 class="mt-5">Dados comerciais</h5>
        <div class="form-row">
          <div class="col-sm-12 col-md-auto mr-4">
            <div class="form-check form-check-inline">
              <Field class="form-check-input" name="companyType" type="radio" value="2" v-model="companyType"  />
              <label class="form-check-label">
                Fornecedor de Biometano
              </label>
            </div>
            <div class="form-check form-check-inline">
              <Field class="form-check-input" name="companyType" type="radio" value="1" v-model="companyType" />
              <label class="form-check-label">
                Consumidor de Biometano
              </label>
            </div>
          </div>
        </div>
        <div class="form-row">
          <div class="col-md-6">
            <label>Nome fantasia</label>
            <Field class="form-control" name="brandname" type="text" />
            <ErrorMessage name="brandname" class="error-feedback" />
          </div>
          <div class="col-md-6">
            <label>Razão Social</label>
            <Field class="form-control" name="businessname" type="text" />
            <ErrorMessage name="businessname" class="error-feedback" />
          </div>
        </div>
        <div class="form-row">
          <div class="col-md-4">
            <label>CNPJ</label>
            <Field v-maska data-maska="##.###.###/####-##" class="form-control" name="cnpj" type="text" />
            <ErrorMessage name="cnpj" class="error-feedback" />
          </div>
          <div class="col-md-4">
            <label>Inscrição Municipal</label>
            <Field class="form-control" name="inscmunicipal" type="text" />
            <ErrorMessage name="inscmunicipal" class="error-feedback" />
          </div>
          <div class="col-md-4">
            <label>Inscrição Estadual</label>
            <Field class="form-control" name="inscestadual" type="text" />
            <ErrorMessage name="inscestadual" class="error-feedback" />
          </div>
        </div>
        <div class="form-row">
          <div class="col-md-4">
            <label>Telefone</label>
            <Field v-maska data-maska="(##)#####-####" class="form-control" name="phone" type="text" />
            <ErrorMessage name="phone" class="error-feedback" />
          </div>
          <div class="col-md-8">
            <label>E-mail</label>
            <Field class="form-control" name="businessemail" type="text" />
            <ErrorMessage name="businessemail" class="error-feedback" />
          </div>
        </div>
        <div class="form-row mt-4">
          <div class="col-md-12">
            <fieldset>
              <legend>Área de atuação</legend>
              <div class="mb-4">
                <label for="state">Estado</label>
                <Field name="area-de-atuacao-state" as="select" class="form-control" v-model="user.state" @change="getMunicipios(user.state)">
                  <option value="" disabled>Selecione um estado</option>
                  <option v-for="state in states" :key="state" :value="state.value">{{ state.label }}</option>
                </Field>
              </div>
              <pick-list :left-items="leftItems" :right-items="rightItems" />
            </fieldset>
          </div>
        </div>
        <h5 class="mt-5">Endereço Comercial</h5>
        <div class="form-row">
          <div class="col-md-2">
            <label for="zipcode">CEP</label>
            <Field @keyup="searchCep" v-maska data-maska="#####-###" name="zipcode" type="text" class="form-control" v-model="user.zipcode" />
            <ErrorMessage name="zipcode" class="error-feedback" />
            <span v-if="cepNotFound" class="cep-error">CEP não encontrado</span>
          </div>
          <div class="col-md-5">
            <label>Endereço</label>
            <Field class="form-control" name="address" type="text" v-model="user.address" />
            <ErrorMessage name="address" class="error-feedback" />
          </div>
          <div class="col-md-2">
            <label>N</label>
            <Field class="form-control" name="number" type="text" />
            <ErrorMessage name="number" class="error-feedback" />
          </div>
          <div class="col-md-3">
            <label>Complemento</label>
            <Field class="form-control" name="complement" type="text" />
            <ErrorMessage name="complement" class="error-feedback" />
          </div>
        </div>
        <div class="form-row">
          <div class="col-md-4">
            <label>Bairro</label>
            <Field class="form-control" name="neighborhood" type="text" v-model="user.neighborhood" />
            <ErrorMessage name="neighborhood" class="error-feedback" />
          </div>
          <div class="col-md-4">
            <label>Cidade</label>
            <Field class="form-control" name="city" type="text" v-model="user.city" />
            <ErrorMessage name="city" class="error-feedback" />
          </div>
          <div class="col-md-4">
            <label for="state">Estado</label>
            <Field name="state" as="select" class="form-control" v-model="user.state">
              <option value="" disabled>Selecione um estado</option>
              <option v-for="state in states" :key="state" :value="state.value">{{ state.label }}</option>
            </Field>
            <ErrorMessage name="state" class="error-feedback" />
          </div>
          
        </div>
        <div
          v-if="message"
          class="alert mt-3"
          :class="successful ? 'alert-success' : 'alert-danger'"
        >
          {{ message }}
        </div>
        <div class="d-flex justify-content-center mt-5 pb-5">
            <button class="btn btn-primary mr-3" :disabled="loading">
                <span v-show="loading" class="spinner-border spinner-border-sm"></span>
                Enviar
            </button>
            <router-link :to="{ name: 'home' }" class="btn btn-secondary">
                Voltar
            </router-link>
        </div>
    </Form>
  </div>
</div>
</template>

<script>
import { Form, Field, ErrorMessage } from "vee-validate";
import AuthService from '../../services/auth.service';
import { VueListPicker } from "vue-list-picker";
import HeaderMain from '../common/HeaderMain.vue';
import PickList from '../common/PickList.vue';
import { vMaska } from "maska";
import * as yup from "yup";
import axios from 'axios';

export default {
  name: "create-news",
  components: {
    Form,
    HeaderMain,
    Field,
    ErrorMessage,
    VueListPicker,
    PickList
  },
  directives: { maska: vMaska },
  data() {
    const schema = yup.object().shape({
      fullname: yup
        .string()
        .required("Este campo é obrigatório."),
      email: yup
        .string()
        .required("Este campo é obrigatório."),
      state: yup
      .string()
      .required("Este campo é obrigatório."),
      brandname: yup
      .string()
      .required("Este campo é obrigatório."),
      businessname: yup
      .string()
      .required("Este campo é obrigatório."),
    });

    const example1 = {
      key: 1,
      content: "Item 1",
    };
    const example2 = {
      key: 2,
      content: "Item 2",
    };
    const example3 = {
      key: 3,
      content: "Item 3",
    };
    const example4 = {
      key: 4,
      content: "Item 4",
    };
    const example5 = {
      key: 5,
      content: "Item 5",
    };
    const example6 = {
      key: 6,
      content: "Item 6",
    };
    const example7 = {
      key: 7,
      content: "Item 7",
    };
    const example8 = {
      key: 8,
      content: "Item 8",
    };

    //const itemsPickList = null;
    const itemsPickList = []
    // const itemsPickList = [
    //   {
    //     id: 7,
    //     nome: "Item 7",
    //   },
    //   {
    //     id: 8,
    //     nome: "Item 8",
    //   }
    // ]

    //const leftItems = [example1, example2, example3, example4, example5, example6, example7, example8];
    const leftItems = itemsPickList;
    const rightItems = [];
    
    
    return {
        successful: false,
        loading: false,
        message: "",
        schema,
        user: {
          zipcode: '',
          address: '',
          neighborhood: '',
          state: '',
          city: ''
        },
        cepNotFound: false,
        companyType: "2",
        states: [
          { value: "AC", label: "Acre" },
          { value: "AL", label: "Alagoas" },
          { value: "AP", label: "Amapá" },
          { value:"AM", label: "Amazonas"},
          { value:"BA", label: "Bahia"},
          { value:"CE", label: "Ceará"},
          { value:"DF", label: "Distrito Federal"},
          { value:"ES", label: "Espírito Santo"},
          { value:"GO", label: "Goiás"},
          { value:"MA", label: "Maranhão"},
          { value:"MT", label: "Mato Grosso"},
          { value:"MS", label: "Mato Grosso do Sul"},
          { value:"MG", label: "Minas Gerais"},
          { value:"PA", label: "Pará"},
          { value:"PB", label: "Paraíba"},
          { value:"PR", label: "Paraná"},
          { value:"PE", label: "Pernambuco"},
          { value:"PI", label: "Piauí"},
          { value:"RJ", label: "Rio de Janeiro"},
          { value:"RN", label: "Rio Grande do Norte"},
          { value:"RS", label: "Rio Grande do Sul"},
          { value:"RO", label: "Rondônia"},
          { value:"RR", label: "Roraima"},
          { value:"SC", label: "Santa Catarina"},
          { value:"SP", label: "São Paulo"},
          { value:"SE", label: "Sergipe"},
          { value:"TO", label: "Tocantins"}
        ],
        leftItems,
        rightItems,
        itemsPickList
    };
    
  },
  computed: {
    
  },
  mounted() {
    //this.getMunicipios();
  },
  methods: {
    searchCep () {
        if(this.user.zipcode.length > 8) {
          this.cepNotFound = false
          this.user.zipcode = this.user.zipcode.replace("-","")
          
          axios.get(`https://viacep.com.br/ws/${ this.user.zipcode }/json/`)
          .then(response => { 
            if(!response.data.erro) {
              this.user.address = response.data.logradouro
              this.user.neighborhood = response.data.bairro
              this.user.city = response.data.localidade
              this.user.state = response.data.uf
              this.cepNotFound = false
            }
            if(response.data.erro) {
              this.cepNotFound = true
            }
          })
          .catch( error => console.log(error) )
        }
    },
    getMunicipios (uf) {
        AuthService.getMunicipios(uf).then(
          response => {
            this.itemsPickList.length = 0;
            for (const item of response.data) {
              this.itemsPickList.push(item);
            }
            //this.itemsPickList = response.data
          },
          error => {
            console.log("Erro", error)
            // this.content =
            //   (error.response && error.response.data && error.response.data.message) ||
            //   error.message ||
            //   error.toString();
          }
        );
        
    },
    handleRegister(user) {
      console.log("selcionados", user)
      
        this.message = "";
        this.loading = true;
        user.listaMunicipiosDutos = this.rightItems.map(item => item.codigo);
        user.listaMunicipiosRodoviaria = this.rightItems.map(item => item.codigo);
        const sanitizeCnpj = user.cnpj.replaceAll(".", "").replaceAll("/", "").replaceAll("-", "");
        console.log("sanitizeCnpj", sanitizeCnpj);
        console.log("dados do Form", user);
        user.cnpj = sanitizeCnpj;
        this.$store.dispatch("auth/register", user).then(
            (data) => {
                console.log("salvou a noticia");
                this.message = "Cadastro Realizado com Sucesso.";
                this.successful = true;
                this.loading = false;
            },
            (error) => {
                console.log("erro ao salvar a noticia", error);
                this.message =
                    // (error.response &&
                    // error.response.data &&
                    // error.response.data.message) ||
                    // error.message ||
                    error.response.data.message;
                this.successful = false;
                this.loading = false;
            }
        );
    },
  },
};
</script>

<style scoped lang="scss">
.register-container {
  background: linear-gradient(180deg, rgba(247,247,247,1) 0%, rgb(247,247,247,1) 35%, rgba(216 242 202) 35%, rgba(216 242 202) 100%);
  padding-top: 25px;
}
.register-form {
  max-width: 800px;
  margin: 0 auto;
  background: #fff;
  padding: 10px 45px;
  border-radius: 10px;
}
.logo-container {
  text-align: center;
  margin-bottom: 31px;
}
.chamada-register {
  text-align: center;
  font-weight: 600;
  font-size: 25px;
  color: #3e7524;
  max-width: 555px;
  margin: 0 auto;
}
label {
  display: block;
  margin-top: 10px;
}
.form-section-title {
  font-size: 1.1rem;
  font-weight: 400;
  text-transform: uppercase;
}
small {
  font-size: 0.7rem;
}
fieldset {
  padding: 0px 30px 20px 30px;
  border-radius: 8px;
  border: 1px solid #ccc;
  legend {
    display: inline-block;
    width: auto;
    padding: 0 10px;
    font-weight: 600;
    font-size: 0.9rem;
    color: #666565;
  }
}

</style>
