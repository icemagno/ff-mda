<template>
  <div class="vue-list-picker">
    <div class="list-picker-container list-picker-left">
      <div class="list-picker-title" :class="getTitleClasses">
        {{ textSubstr(titleLeft, titleSubstr) }}
      </div>
      <div class="list-picker-panel" ref="moverleft" :style="getStyles">
        <div class="list-picker-item"
          v-for="item in unselectedItems"
          :key="item[contentKey]"
          :class="[getContentClasses, {'list-picker-selected': item.isSelected}]"
          @click="selectUnselectItem(item, unselectedItems)"
          @mousemove="selectItem(item, selectedItems)"
          @mousedown="startDrag"
          >
          {{ textSubstr(item[contentAttr], contentSubstr) }}
        </div>
      </div>
    </div>
    <div class="list-picker-actions">
      <button @click.prevent="moveAllRight" class="bi bi-chevron-double-right" :class="buttonClass">
        <slot name="moveAllRight"/>
      </button>
      <button @click.prevent="moveRight" class="mb-25 bi bi-chevron-right" :class="buttonClass">
        <slot name="moveRight"/>
      </button>
      <button @click.prevent="moveLeft" class="bi bi-chevron-left" :class="buttonClass">
        <slot name="moveLeft"/>
      </button>
      <button @click.prevent="moveAllLeft" class="mb-25 bi bi-chevron-double-left" :class="buttonClass">
        <slot name="moveAllLeft"/>
      </button>
      <!--
      <button @click.prevent="unselectAll" :class="buttonClass">
      -->
        <!--<img v-if="!$slots.unselectAll" src="../assets/x.svg" alt="X icon">-->
      <!--
        X
        <slot name="unselectAll"/>
      </button>
      -->
    </div>
    <div class="list-picker-container list-picker-right">
      <div class="list-picker-title" :class="getTitleClasses">
        {{ textSubstr(titleRight, titleSubstr) }}
      </div>
      <div class="list-picker-panel" ref="moverright" :style="getStyles">
        <div class="list-picker-item"
          v-for="item in selectedItems"
          :key="item[contentKey]"
          :class="[getContentClasses, {'list-picker-selected': item.isSelected}]"
          @click="selectUnselectItem(item, selectedItems)"
          @mousemove="selectItem(item, selectedItems)"
          @mousedown="startDrag"
          >
          {{ textSubstr(item[contentAttr], contentSubstr) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PickList',
  props: {
    leftItems: {
      type: Array,
      required: true
    },
    rightItems: {
      type: Array,
      required: true
    },
    movedItemLocation: {
      type: String,
      default: 'top'
    },
    titleLeft: {
      type: String,
      default: 'Cidades/Municípios'
    },
    titleRight: {
      type: String,
      default: 'Selecionados'
    },
    titleCentered: {
      type: Boolean,
      default: false
    },
    titleClass: {
      type: String,
      default: ''
    },
    titleSubstr: {
      type: Number,
      default: 20
    },
    buttonClass: {
      type: String,
      default: 'btn btn-only-icon-primary'
    },
    buttonClassRight: {
      type: String,
      default: 'bi bi-chevron-right'
    },
    buttonClassAllRight: {
      type: String,
      default: 'bi bi-chevron-double-right'
    },
    buttonClassLeft: {
      type: String,
      default: 'bi bi-chevron-left'
    },
    buttonClassAllLeft: {
      type: String,
      default: 'bi bi-chevron-double-left'
    },
    contentKey: {
      type: String,
      default: 'id'
    },
    contentAttr: {
      type: String,
      default: 'nome'
    },
    contentCentered: {
      type: Boolean,
      default: false
    },
    contentClass: {
      type: String,
      default: ''
    },
    contentSubstr: {
      type: Number,
      default: 23
    },
    minHeight: {
      type: String,
      default: ''
    },
    height: {
      type: String,
      default: ''
    },
    minWidth: {
      type: String,
      default: '220px'
    },
    width: {
      type: String,
      default: ''
    }
  },
  data: () => ({
    loading: false,
    dragging: false,
    lastMovedItem: null
  }),
  computed: {
    unselectedItems: {
      get () {
        return this.leftItems
      },
      set (val) {
        this.$emit('leftItems:update', val)
      }
    },
    selectedItems: {
      get () {
        return this.rightItems
      },
      set (val) {
        this.$emit('rightItems:update', val)
      }
    },
    getTitleClasses () {
      const { titleClass, titleCentered } = this

      return titleClass || { 'text-center': titleCentered }
    },
    getContentClasses () {
      const { contentClass, contentCentered } = this

      return contentClass || { 'text-center': contentCentered }
    },
    getStyles () {
      const { height, minHeight, minWidth, width } = this

      return {
        height,
        minHeight,
        minWidth,
        width
      }
    }
  },
  created () {
    this.unselectedItems = this.unselectedItems && this.unselectedItems.length
      ? this.unselectedItems.map(it => ({ ...it, isSelected: false }))
      : []
    this.selectedItems = this.selectedItems && this.selectedItems.length
      ? this.selectedItems.map(it => ({ ...it, isSelected: false }))
      : []
  },
  mounted () {
    document.addEventListener('mouseup', this.stopDrag)
  },
  beforeDestroy () {
    document.removeEventListener('mouseup', this.stopDrag)
  },
  methods: {
    textSubstr (value, qtd = 250, mask = '...') {
      return value && value.length > qtd ? `${value.substring(0, qtd)}${mask}` : value
    },
    startDrag () {
      this.dragging = true
    },
    stopDrag () {
      this.dragging = false
    },
    selectUnselectItem (item, items) {
      this.setItem(item, items, !item.isSelected)
    },
    setItem (item, items, val) {
      let itemBase = item

      if (items && items.length && !itemBase) {
        itemBase = items[0]
      }

      if (!itemBase) return

      itemBase.isSelected = val
      this.$forceUpdate()
    },
    selectItem (item, items) {
      if (this.dragging) {
        const VALUE_IS_SET_TO_TRUE = true
        this.setItem(item, items, VALUE_IS_SET_TO_TRUE)
      }
    },
    moveRight () {
      this.moveOne(this.unselectedItems, this.selectedItems, 'moverleft', 'move-right')
    },
    moveLeft () {
      this.moveOne(this.selectedItems, this.unselectedItems, 'moverright', 'move-left')
    },
    unselect (items) {
      if (!items.length) return

      items.forEach(it => {
        it.isSelected = false
      })
      this.$forceUpdate()
    },
    unselectAll () {
      this.unselect(this.unselectedItems)
      this.unselect(this.selectedItems)
      this.$emit('unselect-all')
    },
    moveOne (firstArray, secondArray, refsName, event) {
      const items = firstArray.filter(itm => itm.isSelected)
      if (!items || !items.length) return

      items.forEach(item => {
        firstArray.forEach((it, idx) => {
          if (it[this.contentKey] === item[this.contentKey]) {
            firstArray.splice(idx, 1)
            this.$emit(event, it)

            if (this.movedItemLocation === 'top') {
              secondArray.unshift(it)
              this.$refs[refsName].scrollTop = 0
            } else {
              secondArray.push(it)
            }
          }
        })
      })

      this.unselectAll()
    },
    moveAllRight () {
      this.moveAll(this.unselectedItems, this.selectedItems)
      this.$emit('move-all-right', this.selectedItems)
    },
    moveAllLeft () {
      this.moveAll(this.selectedItems, this.unselectedItems)
      this.$emit('move-all-left', this.unselectedItems)
    },
    moveAll (firstArray, secondArray) {
      for (let i = firstArray.length - 1; i >= 0; i--) {
        const item = firstArray[i]
        firstArray.splice(i, 1)
        secondArray.push(item)
      }

      this.unselectAll()
    }
  }
}
</script>

<style scoped>
.vue-list-picker {
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  display: flex;
  flex-flow: row nowrap;
  cursor: default;
}
.vue-list-picker .list-picker-container {
  flex: 1 1 auto;
  overflow: auto;
  display: flex;
  flex-direction: column
}
.vue-list-picker .list-picker-panel {
  min-height: 250px;
  max-height: 250px;
  overflow-y: auto;
  border: 1px solid #ccc;
  border-radius: 8px;
}
.vue-list-picker .list-picker-item::selection {
  background: unset;
}
.vue-list-picker .list-picker-actions {
  flex: 0 0 auto;
  align-self: center;
  padding: 0 15px;
}
.vue-list-picker .list-picker-actions > button {
  min-width: 50px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.vue-list-picker .list-picker-item,
.vue-list-picker .list-picker-selected{
  padding: 8px 10px;
  font-weight: 300;
  font-size: 1rem;
}
.vue-list-picker .list-picker-title {
  font-weight: 600;
    font-size: 0.9rem;
    color: #666565;
}
.vue-list-picker .list-picker-selected {
  background: #d7e2d4;
  font-weight: 300;
}
.vue-list-picker .mb-25 {
  margin-bottom: 25px;
}
.vue-list-picker .text-center {
  text-align: center;
}
</style>