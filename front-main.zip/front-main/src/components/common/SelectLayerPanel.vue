<template>
  <div class="toggle-layer">
      <button type="button" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
          <img class="btn-map-layer" src="@/assets/images/architecture.png">
      </button>
      <div class="dropdown-menu">
          <div>
            <input type="checkbox" id="ck_dutos" @click="toggleDutos()" />
            Dutos
          </div>
          <div>
            <input type="checkbox" id="ck_coleta" @click="togglePontos()" />
            Pontos de Coleta
          </div>
          
      </div>
  </div>
</template>

<script>
import MapaService from '../../services/mapa.service';

export default {
  name: "SelectLayerPanel",
  components: {
    
  },
  data() {
    return {
        showDutos: false,
        showPontos: false
    };    
  },
  mounted() {  
  },
  computed: {
  },
  created() {
  },
  methods: {
    toggleDutos(){
      this.showDutos = ! this.showDutos;
      this.emitter.emit('onClickEmpresa', null);
      MapaService.toggleDutos(this.showDutos );
    },
    togglePontos(){
      this.showPontos = ! this.showPontos;
      this.emitter.emit('onClickEmpresa', null);
      MapaService.togglePontos(this.showPontos );
    }

  },
};
</script>

<style lang="scss" scoped>

  .toggle-layer{
    position: fixed;
    right: 10px;
    top: 100px;
    background-color: #ffffffa6;
    z-index: 999;
    border-radius: 10px;
    .dropdown-menu {
      min-width: 170px;
      padding: 10px;
    }
  }
  .btn-map-layer {
    width: 25px;
  }

</style>