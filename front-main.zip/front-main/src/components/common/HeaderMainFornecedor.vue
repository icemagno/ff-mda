<template>
    <nav class="navbar navbar-expand" :style="currentUser ? 'padding-left: 75px;' : 'padding-left: 0.5rem;'">
        <a href="/" class="navbar-brand">
            <img
                src="@/assets/images/logo.jpg"
            >
        </a>
        <div class="navbar-nav ml-auto">
            <div class="btn-group nav-dropdown">
                <button type="button" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-person-circle"></i> {{ currentUser.username }}
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <router-link :to="{ name: 'profile' }" class="dropdown-item">
                        <i class="bi bi-person-badge"></i> Meus dados
                    </router-link>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" @click.prevent="logOut">
                        <i class="bi bi-box-arrow-left"></i> Sair
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <VueAwesomeSideBar
      v-if="currentUser"
      v-model:miniMenu="miniMenu"
      v-model:collapsed="collapsed"
      :menu="testMenu"
      vueRouterEnabel
    ></VueAwesomeSideBar>
</template>

<script>
import { ref } from 'vue'

export default {
  name: "HeaderMainFornecedor",
  setup() {

    const collapsed = ref(false)
    const miniMenu = ref(true)

    const testMenu = [
        {
            name: 'Painel',
            href: '/fornecedor',
            icon: { text: 'painel' , class: 'bx bxs-dashboard' },
        },
        {
            name: 'Fornecedores e Consumidores',
            href: '/mapa',
            icon: { text: 'home' , class: 'bi bi-globe-americas' },
        },
        {
            name: 'Ofertas',
            icon: { text: 'home' , class: 'bi bi-megaphone' },
            children: [
                {
                    name: 'Todas as Ofertas de Venda',
                    href: '/ofertas'
                },
                {
                    name: 'Todas as Ofertas de Compra',
                    href: '/ofertas-compra'
                },
                {
                    name: 'Cria Oferta de Venda',
                    children: [
                        {
                            href: '/ofertas/criar',
                            name: 'Biometano'
                        },
                        {
                            href: '/ofertas/criar/biometano-com-certificado',
                            name: 'Biometano com Certificado'
                        },
                        {
                            href: '/ofertas/criar/certificado',
                            name: 'Somente certificado'
                        }
                    ]
                },
            ]
        },
        {
            name: 'Minhas Negociações',
            href: '/negociacoes',
            icon: { text: 'home' , class: 'bi bi-arrow-down-up rotate-90' },
        },
        {
            name: 'Minhas Compras e Vendas',
            href: '/compras',
            icon: { text: 'Vendas' , class: 'bi bi-file-earmark-check' },
        },
        {
            name: 'Notícias',
            icon: { text: 'home' , class: 'bi bi-newspaper' },
            children: [
            {
                href: '/noticias',
                name: 'Todas as Notícias',
            },
            {
                href: '/noticias/criar',
                name: 'Criar Notícia'
            }
            ],
        },
        // {
        //     header: 'Settings'
        // },
        // {
        //     name: 'Dashboard',
        //     icon: { class: 'material-icons-outlined', text: 'dashboard' },
        //     children: [
        //     {
        //         href: '/c',
        //         name: 'level 2.1',
        //     },
        //     ]
        // },
        // {
        //     name: 'close menu',
        //     icon: { text: 'settings', class: 'material-icons-outlined' },
        // },
    ]

    return {
      collapsed,
      miniMenu,
      testMenu
    }
  },
  components: {
    
  },
  data() {
    
    return {
      
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  created() {
    
  },
  methods: {
    logOut() {
      this.$store.dispatch('auth/logout');
      this.$router.push('/login');
    },
  },
};
</script>