<template>
  <div v-if="showModal" class="modal">
    <div class="modal-content">
      <h2>{{ activeNews.titulo }}</h2>
      <small>{{ activeNews.data }}</small>
      <p class="mt-4">{{ activeNews.texto }}</p>
      <button class="close-modal" @click="closeModal"><i class="bi bi-x-circle"></i></button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    showModal: {
      type: Boolean,
      default: false
    },
    activeNews: {
      type: Object,
      default: () => ({})
    }
  },
  methods: {
    closeModal() {
      this.$emit('close');
    }
  }
};
</script>

<style scoped lang="scss">
/* Your modal styles here */
#app {
    .modal {
        display: block;
        background: #0006
    }
    .modal-content {
        max-width: 600px;
        margin: 30px auto;
        padding: 30px;
        border: none;
    }
    .close-modal {
        position: absolute;
        top: 0;
        right: 0;
        background: none;
        border: 0;
        font-size: 20px;
        color: #00A78E;
        font-weight: 600;
    }
}


</style>
