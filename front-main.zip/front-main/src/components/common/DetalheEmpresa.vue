<template>
    <div v-if="duto" class="empresa-detail">
      <img id="closeEmpresaBtn" @click="closeDuto()" src="@/assets/images/fechar.png">
      <table class="empresaTable">
        <td class="empresaData">{{duto.nome_duto}}</td>
      </table>
    </div> 
    <div v-if="ponto" class="empresa-detail">
      <img id="closeEmpresaBtn" @click="closePonto()" src="@/assets/images/fechar.png">
      <table class="empresaTable">
        <td class="empresaData">{{ponto.nm_local}}</td>
      </table>
    </div> 
    
    <div v-if="empresa" class="empresa-detail">
         <img id="closeEmpresaBtn" @click="closeEmpresa()" src="@/assets/images/fechar.png">
         <table class="empresaTable">
            <tr>
              <td rowspan="2"><img id="empresaIcon" src="@/assets/images/empresa-azul.png"></td><td>Fornecedor / Produtor</td>
            </tr>
            <tr>
              <td class="empresaData">{{empresa.nome_fantasia}}</td>
            </tr>
            <tr>
              <td colspan="2">Produção Disponível</td>
            </tr>
            <tr>
              <td colspan="2" class="empresaData">N/D</td>
            </tr>
         </table>
         <table class="empresaTable">
            <tr>
              <td style="width:100%">Cidade</td>
              <td>Estado</td>
            </tr>
            <tr>
              <td class="empresaData">{{empresa.cidade}}</td>
              <td class="empresaData">{{empresa.estado}}</td>
            </tr>
         </table>
      
         <table class="selectAreaAtuacao">
            <tr>
              <td><input type="checkbox" id="ck_dutos" v-model="showAreaDutos" @click="toggleAreaDutos()" /></td>
              <td>Área de Atuação</td>
            </tr>
            <!--
            <tr>
              <td><input type="checkbox" id="ck_dutos" v-model="showAreaRodovias" @click="toggleAreaRodovias()" /></td>
              <td>Área de atuação por rodovias</td>
            </tr>
            -->
         </table>


    </div>
</template>

<script>
import MapaService from '../../services/mapa.service';
export default {
  name: "DetalheEmpresa",
  components: {
    
  },
  data() {
    return {
        duto: null,
        ponto: null,
        empresa: null,
        showAreaDutos: false,
        showAreaRodovias: false
    };
  },
  mounted() {
    this.emitter.on('onClickEmpresa', ( objeto ) => {
      this.closeEmpresa();
      this.closeDuto();
      this.closePonto();
      this.showAreaDutos = false;
      MapaService.toggleAreaDutos( this.showAreaDutos, this.empresa );
      this.showAreaRodovias = false;
      MapaService.toggleAreaRodovias( this.showAreaRodovias, this.empresa );
      try {
        if( objeto.id_local ) this.ponto = objeto;
        if( objeto.id_empresa_tipo ) this.empresa = objeto;
        if( objeto.id_duto ) this.duto = objeto;
      } catch (error) {
        
      }
    });
  },
  computed: {
    
  },
  created() {
    
  },
  methods: {
    toggleAreaDutos(){
      this.showAreaDutos = ! this.showAreaDutos;
      MapaService.toggleAreaDutos( this.showAreaDutos, this.empresa );
    },
    toggleAreaRodovias(){
      this.showAreaRodovias = ! this.showAreaRodovias;
      MapaService.toggleAreaRodovias( this.showAreaRodovias, this.empresa );
    },
    closeEmpresa(){
      this.showAreaRodovias = false;
      this.showAreaDutos = false;
      this.empresa = null;
    },
    closeDuto(){
      this.duto = null;
    },
    closePonto(){
      this.ponto = null;
    }        
  },
};
</script>

<style scoped>

  .selectAreaAtuacao{
    width: 100%
  }

  #closeEmpresaBtn{
    position:absolute;
    width: 30px;
    right: 10px;
    cursor: pointer;
  }

  #empresaIcon{
    width: 50px;
  }

  .empresaData{
    font-weight: bold;
    padding-bottom: 5px;
  }

  .empresaTable td {
    font-family: 'Roboto', 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  }

  .empresa-detail{
    padding: 15px;
    width: 400px;
    position: absolute;
    right: 100px;
    top: 150px;
    background-color: #F7F7F7;
    z-index: 999;
    border-radius: 25px;
  }

</style>