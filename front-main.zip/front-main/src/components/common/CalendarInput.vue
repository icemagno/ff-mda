<template>
  <Datepicker
    v-model="state.value"
    :enable-time-picker="false"
    :placeholder="props.placeholder"
    @input="$emit('input', state.value)"
    @update:model-value="handleDate"
    select-text="Selecionar"
    cancel-text="Fechar"
    locale="pt-BR"
    text-input
  />
</template>

<script setup>
import Datepicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css';

import { reactive, defineEmits } from 'vue';

const emit = defineEmits(['input']);

const state = reactive({ value: '' });
const props = defineProps(
  {
    placeholder: {
      type: String,
      required: false,
      default: '',
    },
  },
);

function handleDate(value) {
  state.value = value;
  emit('input', value);
}

</script>
<style lang="scss">
.dp__input {
  height: 40px;
  border-radius: 8px;
  border: 1px solid #ccc;
  font-size: .9em;
  padding: 13px 20px 13px 40px;
  font-family: 'Roboto', sans-serif;
  color: #ccc!important;
}

.dp__menu {
  font-size: 12px;
}

.dp__cell_inner {
  height: 29px;
  width: 29px;
}

.dp__readonly {
  color: #ccc!important;
}

.dp__icon {
    width: 25px;
    height: 25px;
}
</style>
