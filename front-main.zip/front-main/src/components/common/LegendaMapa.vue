<template>
    <div class="legenda-mapa">
      <div class="d-flex align-items-end">
        <img class="legendaIcon mr-1" src="@/assets/images/icone-mapa-consumidor.svg">
        <span>Consumidor</span>
      </div>
      <div class="d-flex align-items-end">
        <font-awesome-icon class="legendaIcon fornecedor mr-1" :icon="['fas', 'charging-station']" />
        <span>Fornecedor</span>
      </div>
      <div class="d-flex align-items-end">
        <img class="legendaIcon fornecedor_consumidor mr-1" src="@/assets/images/icone-mapa-fornecedor_consumidor.svg">
        <span>Fornecedor/Consumidor</span>
      </div>
      <div class="d-flex align-items-end">
        <font-awesome-icon class="legendaIcon oferta_aberta mr-1" :icon="['fas', 'bullhorn']" />
        <span>Empresa Com Oferta Aberta</span>
      </div>
    </div>
</template>

<script>

export default {
  name: "LegendaMapa",
  components: {
  },
  data() {
    return {
      aValue : null
    }
  },
  mounted() {
  },
  computed: {
  },
  created() {   
  },
  methods: {
  },
};
</script>

<style lang="scss" scoped>

  .legendaIcon {
    width: 25px;
    font-size: 25px;
    &.fornecedor {
      color: #35d170;
    }
    &.fornecedor_consumidor {
      width: 45px;
    }
    &.oferta_aberta {
      color: #8c5df9;
      font-size: 22px;
    }
  }
  .legenda-mapa-full {
      .legenda-mapa{
        margin-left: 64px;
        margin-right: 0;
        bottom: 0;
        position: fixed;
      }
  }
  .mapa-home {
      .legenda-mapa{
        bottom: 0;
        width: 100%;
        left: 0;
        margin: 0;
        padding: 15px 41px;
        background-color: rgb(255 255 255 / 83%);
      }
  }
  .legenda-mapa{
    padding: 15px;
    width: calc(100% - 65px);
    margin-left: 25px;
    margin-right: 20px;
    position: absolute;
    left: 0;
    bottom: 30px;
    background-color: #ffffff80;
    z-index: 999;
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    font-weight: 900;
  }
  .dash-map {
    .legenda-mapa{
      width: 100%;
      margin-left: 0;
      background-color: #fff;
      font-size: 12px;
      font-weight: 400;
      position: absolute;
      bottom: 15px;
    }
  }

</style>