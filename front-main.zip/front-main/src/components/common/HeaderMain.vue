<template>
    <nav class="navbar navbar-expand" :style="currentUser ? 'padding-left: 75px;' : 'padding-left: 0.5rem;'">
        <a href="/" class="navbar-brand">
            <img
                src="@/assets/images/logo.jpg"
            >
        </a>
        
        <div class="navbar-nav ml-auto">
            <li class="nav-item mx-3">
                <router-link class="btn btn-primary" :to="{ name: 'register' }">
                    <font-awesome-icon icon="user-plus" /> Cadastre-se
                </router-link>
            </li>
            <li class="nav-item">
                <router-link to="/login" class="btn btn-secondary">
                <font-awesome-icon icon="sign-in-alt" /> Entrar
                </router-link>
            </li>
        </div>
    </nav>
</template>

<script>
import { ref } from 'vue'

export default {
  name: "HeaderMain",
  setup() {

    const collapsed = ref(false)
    const miniMenu = ref(true)

    const testMenu = [
        {
            name: 'Home',
            href: '/fornecedor',
            icon: { text: 'home' , class: 'bi bi-house' },
        },
        {
            name: 'Fornecedores e Consumidores',
            href: '/mapa',
            icon: { text: 'home' , class: 'bi bi-globe-americas' },
        },
        {
            name: 'Ofertas',
            icon: { text: 'home' , class: 'bi bi-megaphone' },
            children: [
                {
                    name: 'Todas Ofertas de Venda',
                    href: '/ofertas'
                },
                {
                    name: 'Cria Oferta de Venda',
                    children: [
                        {
                            href: '/ofertas/criar',
                            name: 'Biometano'
                        },
                        {
                            href: '/ofertas/criar/biometano-com-certificado',
                            name: 'Biometano com Certificado'
                        },
                        {
                            href: '/ofertas/criar',
                            name: 'Somente certificado'
                        }
                    ]
                },
            ]
        },
        {
            name: 'Negocições',
            href: '/negociacoes',
            icon: { text: 'home' , class: 'bi bi-arrow-down-up rotate-90' },
        },
        {
            name: 'Notícias',
            icon: { text: 'home' , class: 'bi bi-newspaper' },
            children: [
            {
                href: '/noticias',
                name: 'Todas as notícias',
            },
            {
                href: '/noticias/criar',
                name: 'Criar Notícia'
            }
            ],
        },
        // {
        //     header: 'Settings'
        // },
        // {
        //     name: 'Dashboard',
        //     icon: { class: 'material-icons-outlined', text: 'dashboard' },
        //     children: [
        //     {
        //         href: '/c',
        //         name: 'level 2.1',
        //     },
        //     ]
        // },
        // {
        //     name: 'close menu',
        //     icon: { text: 'settings', class: 'material-icons-outlined' },
        // },
    ]

    return {
      collapsed,
      miniMenu,
      testMenu
    }
  },
  components: {
    
  },
  data() {
    
    return {
      
    };
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
  },
  created() {
    
  },
  methods: {
    logOut() {
      this.$store.dispatch('auth/logout');
      this.$router.push('/login');
    },
  },
};
</script>