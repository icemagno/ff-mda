import axios from 'axios';
import authHeader from './auth-header';
import { environment } from '@/store/environment';

const API_URL = environment.API_URL + 'drwars/api/v1/';

class PurchaseService {
    getAll() {
        return axios.get(API_URL + 'compras/?page=0&limit=50&direction=desc', { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    viewPurchase(purchaseId) {
        return axios.get(API_URL + 'compras/' + `${purchaseId}`, { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    getContrato(purchaseId) {
        return axios.get(API_URL + 'contratos/pdf/' + `${purchaseId}`, { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    saveContrato(data) {
        console.log("salva contrato", data)
        return axios.put(API_URL + 'contratos/' + data.IdDoContrato,
        { 
            contratoItems:[
                {
                    descricao:"PRESSAO_FORNECIMENTO",
                    valor: data.pressao
                },
                {
                    descricao:"VAZAO_FORNECIMENTO",
                    valor: data.vazao
                },
                {
                    descricao:"PODER_CALORIFICO_REFERENCIA",
                    valor:data.poderref
                },
                {
                    descricao:"PODER_CALORIFICO_SUPERIOR",
                    valor:data.podersup
                },
                {
                    descricao:"PONTO_DE_ENTREGA",
                    valor:data.ponto
                },
                {
                    descricao:"QUALIDADE_DO_GAS",
                    valor:data.qualidade
                }
            ]
        }, { headers: authHeader()} );
    }
}

export default new PurchaseService();
