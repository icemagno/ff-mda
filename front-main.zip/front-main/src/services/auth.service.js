import axios from 'axios';
import { environment } from '@/store/environment';

const API_URL = environment.API_URL + 'drwars/api/';

class AuthService {
  login(user) {
    return axios
      .post(API_URL + 'auth/signin', {
        username: user.username,
        password: user.password
      })
      .then(response => {
        if (response.data.accessToken) {
          localStorage.setItem('user', JSON.stringify(response.data));
        }

        return response.data;
      });
  }

  logout() {
    localStorage.removeItem('user');
  }

  register(user) {
    
    if(user.companyType == 1) {
      user.companyTypeDescricao = "Compra"
      user.idperfil = 4
    }
    if(user.companyType == 2) {
      user.companyTypeDescricao = "Venda";
      user.idperfil = 3
    }
    const sanitizeCep = user.zipcode.replaceAll("-", "");
    console.log("tentativa de cadastro", user)
    
    return axios.post(API_URL + 'v1/usuario/empresa', {
      fullName: user.fullname,
      email: user.email,
      login: user.email,
      idperfil: user.idperfil, // 2 = Admin/fornecedor da empresa, 3 = Fornecedor, 4 = Consumidor.
      empresa:{
        cnpj: user.cnpj,
        razaoSocial: user.businessname,
        nomeFatasia: user.brandname,
        inscricaoEstadual: user.inscestadual,
        inscricaoMunicipal: user.inscmunicipal,
        nichoMercado: "Nicho mercado",
        servicosProdutos: "Servicos",
        porteEmpresa: "Porte",
        endereco:{
          logradouro: user.address,
          numero: user.number,
          complemento: user.complement,
          bairro: user.neighborhood,
          cep: sanitizeCep,
          pais: "Brasil",
          estado: user.state,
          cidade: user.city,
          telefone: user.phone,
          email: user.businessemail,
        },
        empresaSituacao:{
          id: 1,
          descricao: "A"
        },
        empresaTipo:{
          id: user.companyType, // 1, 2 ou 3
          //descricao: companyTypeDescricao //Compra, Venda ou Compra / Venda"
        },
        listaMunicipiosDutos: user.listaMunicipiosDutos,
        listaMunicipiosRodoviaria: user.listaMunicipiosRodoviaria
      }
    });
  }

  getMunicipios(uf) {
    //return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `0` + '&size=' + `50` + '&direction=desc' + '&id_tipo_oferta=' + `1,2,3` + '&tipo=' + `V` + '&id-situacao=' + `1`, { headers: authHeader() } );
    return axios.get(API_URL + 'v1/municipios/estado/' + uf);
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }
}

export default new AuthService();