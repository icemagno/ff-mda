import axios from 'axios';
import authHeader from './auth-header';
import { environment } from '@/store/environment';

const API_URL = environment.API_URL + 'drwars/api/v1/';

class LocaisEntregaService {
    getById(id) {
        return axios.get(API_URL + 'locais/' + `${id}`, { headers: authHeader() } );
    }
}

export default new LocaisEntregaService();
