import axios from 'axios';
import { environment } from '@/store/environment';

const EMPRESAS_URL = environment.API_URL + 'drwars/api/v1/mapa/empresas';
const DUTOS_URL = environment.API_URL + 'drwars/api/v1/mapa/dutos';
const PONTOS_URL = environment.API_URL + 'drwars/api/v1/mapa/coleta';
const AREAS_EMPRESAS_URL = environment.API_URL + 'drwars/api/v1/mapa/areas';

class MapaService {
  vectorSource = null;
  dutosSource = null;
  pontosSource = null;
  areasSource = null;

  layer = null;
  dutosLayer = null;
  pontosLayer = null;
  areasLayer = null;
  map = null;

  ambasImg = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTE0IiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTE0IDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4KPHJlY3Qgd2lkdGg9IjExMy4zMzMiIGhlaWdodD0iNjAiIGZpbGw9InVybCgjcGF0dGVybjApIi8+CjxkZWZzPgo8cGF0dGVybiBpZD0icGF0dGVybjAiIHBhdHRlcm5Db250ZW50VW5pdHM9Im9iamVjdEJvdW5kaW5nQm94IiB3aWR0aD0iMSIgaGVpZ2h0PSIxIj4KPHVzZSB4bGluazpocmVmPSIjaW1hZ2UwXzFfMiIgdHJhbnNmb3JtPSJzY2FsZSgwLjAxNDcwNTkgMC4wMjc3Nzc4KSIvPgo8L3BhdHRlcm4+CjxpbWFnZSBpZD0iaW1hZ2UwXzFfMiIgd2lkdGg9IjY4IiBoZWlnaHQ9IjM2IiB4bGluazpocmVmPSJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUVRQUFBQWtDQVlBQUFBdzU1em9BQUFCaFdsRFExQkpRME1nY0hKdlptbHNaUUFBS0pGOWtUMUl3MUFVaFU5VHBTS1ZJbllRY2NoUW5TeUlGaEVuclVJUktvUmFvVlVIazVmK1FaT0dKTVhGVVhBdE9QaXpXSFZ3Y2RiVndWVVFCSDlBbkIyY0ZGMmt4UHVhUW9zWUx6emV4M24zSE42N0R4RHFaYVpaWGVPQXB0dG1LaEVYTTlsVk1mQUtIL29Sd2d4aU1yT01PVWxLd3JPKzdxbWI2aTdLczd6Ny9xdytOV2N4d0NjU3p6TER0SWszaUtjMmJZUHpQbkdZRldXVitKeDR6S1FMRWo5eVhYSDVqWE9oeVFMUERKdnAxRHh4bUZnc2RMRFN3YXhvYXNReDRvaXE2WlF2WkZ4V09XOXgxc3BWMXJvbmYyRXdwNjhzYzUzV01CSll4QklraUZCUVJRbGwySWpTcnBOaUlVWG5jUS8vVU5NdmtVc2hWd21NSEF1b1FJUGM5SVAvd2UvWld2bkpDVGNwR0FlNlh4em5Zd1FJN0FLTm11TjhIenRPNHdUd1B3TlhldHRmcVFQVG42VFgybHJrQ0FodEF4ZlhiVTNaQXk1M2dNRW5RemJscHVTbkplVHp3UHNaZlZNV0dMZ0ZldGZjdWJYT2Nmb0FwR2xXeVJ2ZzRCQVlMVkQydXNlN2V6cm45bTlQYTM0LzJTeHkwQ0lXVjRzQUFBQUdZa3RIUkFEK0FBQUFBQTVIVlVNQUFBQUpjRWhaY3dBQURkY0FBQTNYQVVJb20zZ0FBQUFIZEVsTlJRZm9BUkVSRGg2YWJ2T3ZBQUFCejBsRVFWUm8zdTJZelUzRE1CVEhuKzJ3QVBLSlE3aHphbnZoM0FGQXBLSHNBT29La1NwbENNUUtsSVNxREFCaWdLb3pWT0lXc1FBMTVoUXBtQ1p4NHlUWVR2NVNwSHc0ZWM1UDc4c0c2TldyU0VpM0NTVVI0VlhmcFQ1RFZnRlJnVkVYRkd5Ynk2dEN4UUFBN3RDREpDSmNQRTZIWG1zLzhyRThPVy9MMXZSeFN2S3VrVHZ3WUIyc2NxbU93Z3UwM1N5TkNCZVpzTW5hb1Q1RDZmVXRtemlMbXdYRFJUQUFBTmJCQzRjTzZKN0VPeU56Q1BVWnFxT2E1TWt4RFFZQUFIQkFFS3VIcEhndmlRakh4c0VBZ0NRbTMwM1pVUWFTclVwbjR6dnBzZTdBcXdTamFUa3FJTVI3NzdNSFRsLy9ObnY3eHE2REZhZCtlV1BZSm94S1FBNHBqeXFsOVBvNE9Ib2J6M2N5a09vczJZNXVJRkk5ZllaZkVKRlNiNmtUaG5RT2FSdEdFN2JvaE9IYWdPaFdaU3FCUjhCbGJCalZoNlE5U0ZuWkZkdHo4VnlFU1NjTXA4Q002bFNUaVBCRGU1QWtJbnpPNTFqV2U3QXA0YUtTbTJaeHlLemFENmtqVWN0K3c3b05JdFVGb0pWQUdtdk1maTJveE13cytjd2RYQm0xcDlKN1NKZUJ5SlJnMUdhcmZVaEl0dm5kN1BqT2g0eFlqWERYZnJqc21SWWgwOFFjc3VzVE1ZOFVRY0tqOEJMWjZCbDVhNTZ5aGcxdk44L2F1ZkovU290Sk5SSXltZ0x2MWNzeS9RQWFvdm53ZVRJd05nQUFBQUJKUlU1RXJrSmdnZz09Ii8+CjwvZGVmcz4KPC9zdmc+Cg==';
  compraImg = 'data:image/svg+xml;base64,Cgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgZmlsbD0iIzFkMzE0ZSIgaGVpZ2h0PSI4MCIgd2lkdGg9Ijg0IiB2aWV3Qm94PSIwIDAgNTc2IDUxMiI+PCEtLSFGb250IEF3ZXNvbWUgRnJlZSA2LjUuMSBieSBAZm9udGF3ZXNvbWUgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbSBMaWNlbnNlIC0gaHR0cHM6Ly9mb250YXdlc29tZS5jb20vbGljZW5zZS9mcmVlIENvcHlyaWdodCAyMDI0IEZvbnRpY29ucywgSW5jLi0tPjxwYXRoIGQ9Ik02NCAzMkM0Ni4zIDMyIDMyIDQ2LjMgMzIgNjRWMzA0djQ4IDgwYzAgMjYuNSAyMS41IDQ4IDQ4IDQ4SDQ5NmMyNi41IDAgNDgtMjEuNSA0OC00OFYzMDQgMTUyLjJjMC0xOC4yLTE5LjQtMjkuNy0zNS40LTIxLjFMMzUyIDIxNS40VjE1Mi4yYzAtMTguMi0xOS40LTI5LjctMzUuNC0yMS4xTDE2MCAyMTUuNFY2NGMwLTE3LjctMTQuMy0zMi0zMi0zMkg2NHoiLz48L3N2Zz4=';
  vendaImg = 'data:image/svg+xml;base64,CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiBmaWxsPSIjNDhkMTYxIiBoZWlnaHQ9IjgwIiB3aWR0aD0iODQiIHZpZXdCb3g9IjAgMCA1NzYgNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNS4xIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjQgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTk2IDBDNjAuNyAwIDMyIDI4LjcgMzIgNjRWNDQ4Yy0xNy43IDAtMzIgMTQuMy0zMiAzMnMxNC4zIDMyIDMyIDMySDMyMGMxNy43IDAgMzItMTQuMyAzMi0zMnMtMTQuMy0zMi0zMi0zMlYzMDRoMTZjMjIuMSAwIDQwIDE3LjkgNDAgNDB2MzJjMCAzOS44IDMyLjIgNzIgNzIgNzJzNzItMzIuMiA3Mi03MlYyNTIuM2MzMi41LTEwLjIgNTYtNDAuNSA1Ni03Ni4zVjE0NGMwLTguOC03LjItMTYtMTYtMTZINTQ0VjgwYzAtOC44LTcuMi0xNi0xNi0xNnMtMTYgNy4yLTE2IDE2djQ4SDQ4MFY4MGMwLTguOC03LjItMTYtMTYtMTZzLTE2IDcuMi0xNiAxNnY0OEg0MzJjLTguOCAwLTE2IDcuMi0xNiAxNnYzMmMwIDM1LjggMjMuNSA2Ni4xIDU2IDc2LjNWMzc2YzAgMTMuMy0xMC43IDI0LTI0IDI0cy0yNC0xMC43LTI0LTI0VjM0NGMwLTQ4LjYtMzkuNC04OC04OC04OEgzMjBWNjRjMC0zNS4zLTI4LjctNjQtNjQtNjRIOTZ6TTIxNi45IDgyLjdjNiA0IDguNSAxMS41IDYuMyAxOC4zbC0yNSA3NC45SDI1NmM2LjcgMCAxMi43IDQuMiAxNSAxMC40cy41IDEzLjMtNC42IDE3LjdsLTExMiA5NmMtNS41IDQuNy0xMy40IDUuMS0xOS4zIDEuMXMtOC41LTExLjUtNi4zLTE4LjNsMjUtNzQuOUg5NmMtNi43IDAtMTIuNy00LjItMTUtMTAuNHMtLjUtMTMuMyA0LjYtMTcuN2wxMTItOTZjNS41LTQuNyAxMy40LTUuMSAxOS4zLTEuMXoiLz48L3N2Zz4=';
  ambasAtiva = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABRCAYAAABFTSEIAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAEJlJREFUeNrsnHl0VdW9xz+/fe6QkPmSXKaQMAUCYZ4pUrBQQJQWa58+tdhqS1cHKoq0+tQ6lVaera8qdSloW7TWgtpaQFAUxQFElCCCBCFMYQgBMpGb6eaes/f749wEcGAwCCHNXmuvRdYlO3t/zm//hu/e54oxhpb25ZtqQdACsAVgC8AWgE23zZo1a1STnqAxpsn2mTNnXpySkrT14Yf/GGiqc2zSAHv3ynnRY4np16/PoqY6R09jrPfyyy9P3Lhx4y9EJDMUCr3fo0ePP19//fUmFInQP1RGbG4ZJWVl7I7JoI0KkxTvpZVls6u4ljbBAAdLKzkSNnTw1RGyPdT54vCrMB29pSz0h24oOlCQExfjZ8uWLWN++cufT75qj2dpbCCJvHKDZUeo83ixKytJb5tAaXk1+w5XgcDIDB/bDtfQOdaPHQ7TOcVhQV0f3sorI8kvlEc83HNJCh3yXuat/Qe5flPu+fGBmzZt+k1BQcHsPXv2TCsrK3tCa32zbdvUOA4+226Ua1mz+uUZaamVWZO/7Sc1VQefe+H5e5tdECkqKrrM6/WilEJrzdGqqvE7CwtJ3bWLwYWF2NaXG/7R6l33FheXpo+fCDf+rCvDhsVysOhI5iNxxdOaFcDs7OxnAXw+H8ryVHdunfr41XW1TAtX41MGr2WwMCg5/TGPjvBlb8xd+ZP0TiYQN/ZagtflcVNyezIzJPD6awtnNyuAI0aMuLddu3bP10YijGsdOPBCoFVKt4/ybiwsKL5xb0HZjbnF1vdDxjssbJu0GKWJsQzWKWAuWfr87NqwDl7x7Xi2JH5Mxq5aPAequTMDIrXGM+OTNQ81JYCNCiJPP/20DeSL1yKm1mQtXG//ZWHcUI54klFGE7LiSPR0QBldmh1bvb532F4yIDG8wid6h9+CT7Pc0alo8ifvfPK1/hcZKoddhvYsBCxGrjxE6bU9uTYzL/CXj1ZN/eYlFz+a9UEk/4K3wFAohG3bfp/RHJEUHmx7NTvjOlHtS6AyJgnLYxHCx1GJCayubj1+XmHan+7Jb7NhaWnay5tLuBZMil/pBpArX1vxc6+y2428dCTb4xdiifuJQfOtZ7cyOCsRjxD465+fnNcstrBSCqKLVAixOozP2FhoLKMRXB9oYYhRGr8FR4hPWBdOnTh3T+CZvx0K5m4OJdwNpv0bydtn7ivYOWTUKDiUkY6I4IgADggYIwSSs/hpN8O+fftyXm8bmtzMSjk5TZ+h8YvGYwl7I/Gd36xqc8+ThzI2lG+xb87sEBMYPGUChd73Ea2o1yrFuONPnJ/LwO7ZpAZ1cMniF+5qZgA1coa4vaLxKc0+O67NLnVZeqf2M8kvTsZYe9DiRCen0JZgcDAoMvYW84sMKA8d6bIo8s6DFzzAemiN0bW9ovFZ8ElFZ9b8fQyxT/yA1IMdEGPcB6MNSizAMGh1MRel96R9mgm8u+qd70WuyPa1qDHR5hONEYvcrSPZ9Mf/If6lKVTGJESfjm7IJ2sqq7g1B6odHZw//4n5LQBPsGhDjHKo0j7ee+NSvp89i7x2vTFG3AIeYcyyvXQwmYzOhI0bP7zkjfaRYS0AP9XqI3eepz3fbfcLFnS/nJr4FAQBJYxfWsCPchJQ8QSfXfT4n1sAniRqW0qYHT+RH3WZzvZOA6gPL8mBHAYN1hw8WN7ulaSS77UAPMm2jlWa9b4MJqf8mFt7TWd/sAvDn1zHrWm9SEsi8NJL5yetuaDORHxovBYs9fVmcsdZPN7lavq/Us707opQRVXrV1p99FgLwNNIm3xKUyceHo2/mCkZt2GSfsqAHsHA6nfXXmld2TPJkhaApzFxg180VSqGeQX9qfTezvDMHwbeWPDq6lCt092LI62Ug19pfOqzKpDXctOm86rGNBWQMZahllgKYkbgwel9x57qzQGqN/eP1G1KrSvN1X57Z3mdLlIiGtBKkIIy7auoScqGIzuAdf+xAI8H6RMHAxwh3neIhEGbKxjko/31/r2O+39axZhiMBGPUnd/YBgb12PlaM+en/xHW+Dn+UgP7tb0KbeIieBBAA0S0SIByy6+PK38znEpoXmHt/2Hb+HTAWqMIWKEBI8OD4879HTvWPu+xETf/ogRGns3rVkDtI2ggQRL2xm+6n/0jat8aFhSaMOBkJ86LWclhDYrgBpBI9ha8ODQWhXrzon+p76ZYT1SW1W78VC5IazVGQpvzRigQbCN4CCI1rSSCL2dA4yM24onpYTbVq5XRcHkHt/N+tXGUKWgv4I5eJo2IBeSQbC1wavAMcd8m9fYDJTD9A0X8LWafHqU7CClsgSfHWHZVd0Y1S3Myq2F2SvU5itzyHqO5giwHlDECI5R7hFLJILfKygx+HSYoK6gs7ea2so6OqsKOlfup49dSLDyMGm1pXjDdbhCl0bEDQyXLtpBzA96sip/a2DxPxfMzfn6b5sPQHepYLTBwiHeH6JzahEdUjbhTy5Fd4pjZ00lca1refj2UiRUQYITRvRnN6GjjhPABAyueq2Ng2N7uHMg3P6+41kRXnXvIEbefcECdFDUacGDJs5TR1LH3aR23k3rXhsoTiklklDNDo9zwu/UAUmlJ080lAYRAeNEUxZwcLBEGPfMZiI/6E2w4OPAO2tWTJ/y+2/N4eXKmgsKoI3CcTRp3lL69P+Q2t47qGhbhNP2AGElFOpGZmLRI0+DwRiFAEoEbRyUgq4fFHBfPx/TXq8LPPLoH5bc0+W/vnlBANTGzcPatCqm75jXqeify8HUckRcKxEBbUyjEwoxCiMahWCMbgg+SgSjhewtIfaOHkGfvWsp2LZ74Prx1rCMj7587fuVqzEGoU4LMZah3/AP6XjTH9g37nWOppa7n0cNzpj6896zkP1FL4oeg1r/swYUQ59Zx2+yM7FtAn975qn/a3JylhGwxaLWeNBa0zUxj94/eoO6q+ZRmVp63tPr5AqNL6YVQwcLR4oLsz/osOeGJgPQAGIEv3boo/LC3dVchl+fR1mP59BfSep6pvjcNu75bfx6cA5eJYHFy/5xf5MBKNGak9aRzW/unFud3n87hcE4FIIYOe8A6xeoIgZ7TxX3DjIUl4jn7+WvPtRktrDfY5F7aF/H9K7hlMSJl1HofxMTvUnQJKoZcS8/jVtcQJfu/ejY1g58lPv21G1jMpKaThCRSPL4SW3YnLocZZVjR3OxpiBniVFupSKG4K4D3DcolsoKAvPnzV103gGmpATaA7RNg9oBY7CoxRjwaLCbgAXaCCIaxKANDFtVTJsOA7muL+zdsWvA+nEXjTqvACO2HggQzOpIfqs8XLdnMGKahA/0IMdSJjEoESY8uoZJvXOos3XwuUX/mHPeAF593TU3HD1anAlQmlxNnX9zFJpgmYa7l00kDh/LD8VAx62HuDkHCosOZF93zVXTzznAJ//yhLXm7X/fFkg2MQBGlaCMoDAYAa08TSCJcZdYvxFEJCqmKgbmljBpQF9i4yTw2ptLZ51zgMtfWjYzVFqVldnRH3260VkqC8sYjLHPUqVxdioVt7x0AwlotIGjFWHmDDCUltXFjhl70dxzBvD3Dz6Q/s7rq27oO1yIdMpsGEmLIYJGK+XWpk1iCx+rlqR+G4t732b8om2kZ/QjvY0T3PLRmmseeuT+LucE4PLFz892vBXZI4YFqY7Jb8i3fEZQhmhRL9Ebpk2j1VuhkeMhwtDlW/ndyADVNQQWPPb4gq8c4K23zLz43fc3XDJwOMjgccf8nDEY7Q4ootBukUdTavo4kGIUYJF2yCEhoRuTs6Dw4L6cGTNmTPhKAS5bvuTWtHYEv3Fpd/J9u44hUmAURDDRSRpX6DzvlcixJSqx0EhU9tcY5WAwTJz/PlNzsqisMYElS87sdbIzAjjthqk37MzfOWTMMM2HXVOojll7wuN1lBCjfWhcfa4piAn1Z3FGAONgHa9DaneWYsATVtzdTzhScrjLlf996V1nHeDTf33c9+bKf92RnWUF+k4YSzhm3bFis34wx2BLBDH1yas0PR94nIh7/EHn+H/mc1FOH1ITCaxb++pPzjrAF/+15LbisuouY0YbtnRMACNRP9IcmsIoTeCD3dzeG8oOa2vsN77+0FkDeP+c32S/9ubLMwZepCieNIFS31KMGBCnWeATMYhW9NhSSdv0gWRkEty8+Z2pcx64u+9ZAfjaK4tvS44jMGpoF0KJrwJRcHLhW6CjwDEGE30Ppc22Qn49sBU1ISvw1FOPLWg0wJtvvWXce2s3TB7UF0JDhmAsBxAUrnx/wW9eLSfcXh2yuoj4hJ5c1cuhaH9x5s9+/sOrGwVwyZIX7mrf3gS6XTGW/JhcjBYUFsbYKCUX/vZF0NGUVRv3NG/S/A+4JqsnNgSWL18x/UsDvHbqlF/u272/x8ivwfZuW8Cf78pU2oCF+xcv+KYhWp0IpuF0L+xR3N1bcajoQPaUKRPv/VIA33rrlRv799DBnpMmIb7DoA0ibsQyGkSax+04N8U5EcXEZ7cyPKsXwfYS2PDhmqsff2xu0hkBHD9xwuyainCr0aM8bE+1EGOwUDhuDh/V1pxj1Zq4r2B9pp8yAspJ+7mpVlxLtIXj/qYmPq+Q+/tYlB2tzHr2macePm2As397T867q1ZOGzRCAvsnjeZI7NLo2a/BE335+bOL+4KvRuLk/ZRfrXQuNnGUgqdecI3e8Oq7voTE1L5kdVRs2547+fY7brn4tAAuefHvDyYEdHDYiG6EEle52zaq5LqHMxbG1JdHpuExijGf6VER6ST9VJDVKXrja2VLKwyCiOUm1UZQYiFG0XXdNu4cnExVjRVYsvjF208J8OabfjVuy8e7BgwcBFVDhqIc7VqCxo26RrAcG6zTsw4j5hSdk3ZXQ/nifqrfP1WX+rHEuC4JjRGNjv47++Ma/LWt+XUvzYG9uwf+eNrPrjwpwBf/vfCuTpk6OOCKMey1PsYIeIwgluA4oC1BKwGjGr7L4Pik4NNdTOP66QSARnWREzRCc/xSom3SwnwGdeuB12sFVq967o4vBHjt966cvv/wvpxeQ2BrhwrqYjcjoqhTBqM9eISGG1Bo7V5ulGN3bj/PwhproV95ADGmwR0p923kT118ctfrVNfw7cu8HCouSf/OdyY1qDUNecj8J+f5li9bOqtrRlrgG1/PobxVN/bUdqFahzDU4rHisB2HWOUgNjhWLYpW+O0CYB9+uzMptT0/x8c4p0hkrZN+/vaETeegFhaMo+tFQ8SA4140RGlDbGWY5L7dGJc1hNfe/mcg9733r/jTQw//afpNM0qlPtKNGjt67tq3356eGvTSq2cbfLEliFOH4CAKlCMoYzDKdbxKNOJAXr7Fnn1Cejubvr0+v9Y8WbMaWQ3qRmY6OpqB1W/heu9quZcMXWVdwOg4amqS+OSTw5QesRk6aPgTq99b+2MxxnD//f/b5YEHfrfM61PZmDDaRFxnio6mLV/sNP2xKcQnBqgKlVBbXc6Jhs9JD5ZOZ4eq48ZTn1r4qcZv7INx/aOb1jiOQfBgHB+Cj5SU1iumTp16S4MFzpnzuy4xsb4aJxKJVRb4fL4a27Z9Isc0K2XODIKRk1uIauQly1ONf0aigvmsRYsY6/gH5NjiYCzHGMsxWqxbZs04KC3fZN5YKbaltQBsAdgCsAVgS2sBeH7a/w8Aq9dxiuwhrbwAAAAASUVORK5CYII=';
  compraAtiva = 'data:image/svg+xml;base64,CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiBmaWxsPSIjOGM1ZGY5IiBoZWlnaHQ9IjgwIiB3aWR0aD0iODQiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNS4xIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjQgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTQ4MCAzMmMwLTEyLjktNy44LTI0LjYtMTkuOC0yOS42cy0yNS43LTIuMi0zNC45IDYuOUwzODEuNyA1M2MtNDggNDgtMTEzLjEgNzUtMTgxIDc1SDE5MiAxNjAgNjRjLTM1LjMgMC02NCAyOC43LTY0IDY0djk2YzAgMzUuMyAyOC43IDY0IDY0IDY0bDAgMTI4YzAgMTcuNyAxNC4zIDMyIDMyIDMyaDY0YzE3LjcgMCAzMi0xNC4zIDMyLTMyVjM1Mmw4LjcgMGM2Ny45IDAgMTMzIDI3IDE4MSA3NWw0My42IDQzLjZjOS4yIDkuMiAyMi45IDExLjkgMzQuOSA2LjlzMTkuOC0xNi42IDE5LjgtMjkuNlYzMDAuNGMxOC42LTguOCAzMi0zMi41IDMyLTYwLjRzLTEzLjQtNTEuNi0zMi02MC40VjMyem0tNjQgNzYuN1YyNDAgMzcxLjNDMzU3LjIgMzE3LjggMjgwLjUgMjg4IDIwMC43IDI4OEgxOTJWMTkyaDguN2M3OS44IDAgMTU2LjUtMjkuOCAyMTUuMy04My4zeiIvPjwvc3ZnPgo=';
  vendaAtiva = 'data:image/svg+xml;base64,CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiBmaWxsPSIjOGM1ZGY5IiBoZWlnaHQ9IjgwIiB3aWR0aD0iODQiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNS4xIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjQgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTQ4MCAzMmMwLTEyLjktNy44LTI0LjYtMTkuOC0yOS42cy0yNS43LTIuMi0zNC45IDYuOUwzODEuNyA1M2MtNDggNDgtMTEzLjEgNzUtMTgxIDc1SDE5MiAxNjAgNjRjLTM1LjMgMC02NCAyOC43LTY0IDY0djk2YzAgMzUuMyAyOC43IDY0IDY0IDY0bDAgMTI4YzAgMTcuNyAxNC4zIDMyIDMyIDMyaDY0YzE3LjcgMCAzMi0xNC4zIDMyLTMyVjM1Mmw4LjcgMGM2Ny45IDAgMTMzIDI3IDE4MSA3NWw0My42IDQzLjZjOS4yIDkuMiAyMi45IDExLjkgMzQuOSA2LjlzMTkuOC0xNi42IDE5LjgtMjkuNlYzMDAuNGMxOC42LTguOCAzMi0zMi41IDMyLTYwLjRzLTEzLjQtNTEuNi0zMi02MC40VjMyem0tNjQgNzYuN1YyNDAgMzcxLjNDMzU3LjIgMzE3LjggMjgwLjUgMjg4IDIwMC43IDI4OEgxOTJWMTkyaDguN2M3OS44IDAgMTU2LjUtMjkuOCAyMTUuMy04My4zeiIvPjwvc3ZnPgo=';


  imagens = [ ]

  canShow = false;

  showDetail(){
    return this.canShow;
  }

  getMapContent(){
    return osm_content;
  }

  getEmpresas() {
    return axios.get( EMPRESAS_URL );
  }

  toggleAreaDutos( visible, empresa ){
    this.areasLayer.getSource().clear();
    if( !empresa ) return;
    if( !visible ) return;
    axios.get( AREAS_EMPRESAS_URL + '/dutos/' + empresa.id_empresa ).then(
      response => {
        if( response.data.features ) this.addDataArea( response.data, this.areasSource );  
      }
    )    
  }

  toggleAreaRodovias( visible, empresa ){
    this.areasLayer.getSource().clear();
    if( !empresa ) return;
    if( !visible ) return;
    axios.get( AREAS_EMPRESAS_URL + '/rodovias/' + empresa.id_empresa ).then(
      response => {
        if( response.data.features ) this.addDataArea( response.data, this.areasSource );  
      }
    )        
  }

  toggleDutos( visible ){
    this.dutosLayer.setVisible( visible );
  }

  togglePontos( visible ){
    this.pontosLayer.setVisible( visible );
  }

  doPrepareMapa( data, dutos, pontos, onclick ){   

    this.imagens = [
      this.compraImg,
      this.vendaImg,
      this.ambasImg,
      this.compraAtiva,
      this.vendaAtiva,
      this.ambasAtiva
    ]

    this.map = new ol.Map({
      layers: [
        new ol.layer.Tile({
          source: new ol.source.OSM({
            url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            maxZoom: 19
          })
        })
      ],
      target: 'map',
      view: new ol.View({
        center: ol.proj.fromLonLat([-50,-15]),
        maxZoom: 19,
        zoom: 4
      })
    }); 
    this.addLayer();

    this.addDataPoint( data, this.vectorSource );
    if( pontos ) this.addDataPoint( pontos.data, this.pontosSource );
    if( dutos ) this.addDataLine( dutos.data, this.dutosSource );

		this.map.on('click', (evt) => {
			const feature = this.map.forEachFeatureAtPixel(evt.pixel, function (feature) {
			  return feature;
			});	
			if (!feature) return;
			let props = feature.getProperties();
      if( onclick ) onclick( props );
		});


    this.map.on("pointermove", (evt) => {
      const feature = this.map.forEachFeatureAtPixel( evt.pixel, function(feature, layer) {
          return feature;
      });
      if (feature) {
        this.map.getTargetElement().style.cursor = 'pointer';
      } else {
        this.map.getTargetElement().style.cursor = '';
      }
    }); 

    window.addEventListener('resize', (event)=> {
      setTimeout( () => {  this.map.updateSize(); }, 200);
    }, true);  


  }


  prepareMapa( isFull, data, onclick ){
    let dutos = null;
    let pontos = null;   

    if( isFull ){
      axios.get( DUTOS_URL ).then(
        response => {
          dutos = response;  
        }
      )
      axios.get( PONTOS_URL ).then(
        response => {
          pontos = response;  
        }
      )
    }

    setTimeout(  ()=>{
      this.doPrepareMapa( data, dutos, pontos, onclick );
      this.pontosLayer.setVisible( false );
      this.dutosLayer.setVisible( false );
    }, 700  );

  }

  addDataPoint( fc, target ){
    for( let x = 0; x < fc.features.length; x++  ) {
      fc.features[x].id = x;
      let aFeature = fc.features[x];
      let aGeom = aFeature.geometry;
      if( aGeom == null ) continue;
      let coordinates = aGeom.coordinates;
      let properties = fc.features[x].properties;
      properties.lat = coordinates[0];
      properties.lon = coordinates[1];

      var pointFeature = new ol.Feature({
        id : x,
        geometry: new ol.geom.Point(ol.proj.fromLonLat( [ coordinates[0], coordinates[1] ] ) ),
      });
      pointFeature.setProperties( properties );
      try {
        pointFeature.setStyle( this.getStyleImg( properties ) );
      } catch (error) {
        pointFeature.setStyle( 
          new ol.style.Style({
            image: new ol.style.Circle({
              radius: 7,
              fill: new ol.style.Fill({color: 'black'}),
              stroke: new ol.style.Stroke({
                color: [255,0,0], width: 2
              })
            })
          })
        )
            
      } 
      target.addFeature( pointFeature )
    }
  }

  addDataLine( fc, target ){
    for( let x = 0; x < fc.features.length; x++  ) {
      fc.features[x].id = x;
      let aFeature = fc.features[x];
      let aGeom = aFeature.geometry;
      if( aGeom == null ) continue;
      let coordinates = aGeom.coordinates;
      let properties = fc.features[x].properties;
      
      let newCoords = [];
      coordinates.forEach( coord => {
        let tt = ol.proj.fromLonLat( [ coord[0], coord[1] ] );
        newCoords.push( tt );
      });
 
      var pointFeature = new ol.Feature({
        id : x,
        geometry: new ol.geom.LineString(newCoords),
      });
      pointFeature.setProperties( properties );
      pointFeature.setStyle( 
        new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: 'purple',
                width: 3
            }),
            fill: new ol.style.Fill({
                color: 'rgba(255, 0, 119, 1)'
            })
        })
      )
      target.addFeature( pointFeature )
      

    }
  }

  addDataArea( fc, target ){


    for( let x = 0; x < fc.features.length; x++  ) {
      fc.features[x].id = x;
      let aFeature = fc.features[x];
      let aGeom = aFeature.geometry;
      if( aGeom == null ) continue;
      let coordinates = aGeom.coordinates;
      let properties = fc.features[x].properties;
      let gg = null;

      if( aFeature.geometry.type == 'Polygon' ) {
        gg = new ol.geom.Polygon(  coordinates  );
      }
      if( aFeature.geometry.type == 'MultiPolygon' ) {
        gg = new ol.geom.MultiPolygon(  coordinates  );
      }

      var areaFeature = new ol.Feature({
        id : x,
        geometry: gg,
      });
      areaFeature.setProperties( properties );
      areaFeature.setStyle( 
        new ol.style.Style({
          stroke: new ol.style.Stroke({
            color: 'blue',
            width: 3,
          }),
          fill: new ol.style.Fill({
            color: 'rgba(0, 0, 255, 0.1)',
          })
        })
      )
      target.addFeature( areaFeature );
      
    }
  }







  addLayer( ){
    this.vectorSource = new ol.source.Vector({
      features: [  ]
    });
    this.dutosSource = new ol.source.Vector({
      features: [  ]
    });
    this.pontosSource = new ol.source.Vector({
      features: [  ]
    });
    this.areasSource = new ol.source.Vector({
      features: [  ]
    });

    this.layer = new ol.layer.Vector({
      source: this.vectorSource
    });
    this.dutosLayer = new ol.layer.Vector({
      source: this.dutosSource
    });
    this.pontosLayer = new ol.layer.Vector({
      source: this.pontosSource
    });
    this.areasLayer = new ol.layer.Vector({
      source: this.areasSource
    });

    this.map.addLayer(this.layer);
    this.map.addLayer(this.dutosLayer);
    this.map.addLayer(this.pontosLayer);
    this.map.addLayer(this.areasLayer);
  }

  getStroke(){
		return new ol.style.Stroke({
			color: 'black',
			width: 2
	  });    
  }

  getColor( situacao ){
    let result = 'gray'
    switch (situacao) {
      case 'OS_INICIADA':
        result = 'green'
        break;
      default:
        result = 'gray'
        break;
    }
    return result;
  } 
  
  getShape( situacao ){
    let result = 3
    switch (situacao) {
      case 'OT_BIOMETANO':
        result = 3
        break;
      case 'OT_BIOMETANO_CERTIFICADO':
        result = 100
        break;
      case 'OT_CERTIFICADO':
        result = 4
        break;            
      default:
        result = 3
        break;
    }
    return result;
  } 

  getImage( properties ){
    let ofertaSituacao = properties.ds_oferta_situacao;
    let empresaTipo = properties.id_empresa_tipo - 1;
    if( ofertaSituacao ==  'OS_INICIADA' ) empresaTipo = empresaTipo + 3;
    return this.imagens[ empresaTipo ];
  }


  /*
    Verde e/ou vermelha seria pelo empresa_tipo. A bandeirinha seria uma flag (com trocadilho) 
    indicando uma oferta ativa, pela oferta_situacao
  */
  getStyleImg( properties ){
    return new ol.style.Style({
      image: new ol.style.Icon({
        src: this.getImage( properties ),
        scale: 0.24
      }),
    });
  }


  // getStyle( properties ){
	// 	return new ol.style.Style({
  //     text: new ol.style.Text({
  //       text: properties.compra_venda,
  //       fill: new ol.style.Fill({
  //         color: '#FFFFFF'
  //       }),        
  //     }),
	// 		image: new ol.style.RegularShape({
	// 		  fill: new ol.style.Fill({
	// 			  color: this.getColor( properties.ds_oferta_situacao )
	// 		  }),
	// 		  stroke: this.getStroke(),
	// 		  points: this.getShape( properties.ds_oferta_tipo ),
	// 		  radius: 12,
	// 		  angle: 0
	// 		})
	// 	});
  // } 

}

export default new MapaService();