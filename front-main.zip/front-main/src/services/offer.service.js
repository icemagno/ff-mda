import axios from 'axios';
import authHeader from './auth-header';
import { environment } from '@/store/environment';

const API_URL = environment.API_URL + 'drwars/api/v1/';

class OfferService {

  getAll(page, size, tipoOferta, idSituacao) {
    //return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `0` + '&size=' + `50` + '&direction=desc' + '&id_tipo_oferta=' + `1,2,3` + '&tipo=' + `V` + '&id-situacao=' + `1`, { headers: authHeader() } );
    return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `${page}` + '&size=' + `${size}` + '&direction=desc' + '&id_tipo_oferta=' + `1,2,3` + '&tipo=' + `${tipoOferta}` + '&id-situacao=' + `${idSituacao}`, { headers: authHeader() } );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }
  getAllOnlyBiomethane(page, size, tipoOferta, idSituacao) {
    return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `${page}` + '&size=' + `${size}` + '&direction=desc' + '&id_tipo_oferta=' + `1` + '&tipo=' + `${tipoOferta}` + '&id-situacao=' + `${idSituacao}`, { headers: authHeader() } );
  }
  getAllBiomethaneCert(page, size, tipoOferta, idSituacao) {
    return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `${page}` + '&size=' + `${size}` + '&direction=desc' + '&id_tipo_oferta=' + `2` + '&tipo=' + `${tipoOferta}` + '&id-situacao=' + `${idSituacao}`, { headers: authHeader() } );
  }
  getAllOnlyCert(page, size, tipoOferta, idSituacao) {
    //return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `0` + '&size=' + `50` + '&direction=desc' + '&id_tipo_oferta=' + `1,2,3` + '&tipo=' + `V` + '&id-situacao=' + `1`, { headers: authHeader() } );
    return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `${page}` + '&size=' + `${size}` + '&direction=desc' + '&id_tipo_oferta=' + `3` + '&tipo=' + `${tipoOferta}` + '&id-situacao=' + `${idSituacao}`, { headers: authHeader() } );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  getAllLocaisEntrega() {
    //return axios.get(API_URL + 'ofertas/buscarPorTipo' + '?page=' + `0` + '&size=' + `50` + '&direction=desc' + '&id_tipo_oferta=' + `1,2,3` + '&tipo=' + `V` + '&id-situacao=' + `1`, { headers: authHeader() } );
    return axios.get(API_URL + 'locais?pag=0&size=300&direction=asc', { headers: authHeader() } );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  acceptProposal(offerId) {
    return axios.get(API_URL + 'compras' + '?id-oferta=' + `${offerId}`, { headers: authHeader() } );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  cancelNegotiation(offerId) {
    return axios.get(API_URL + 'ofertas/cancelar/' + `${offerId}`, { headers: authHeader() } );
  }

  editItem(itemId) {
    return axios.get(API_URL + 'ofertas/' + `${itemId}`, { headers: authHeader() } );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }
  
  //OFERTA DE VENDA DE BIOMETANO
  createOffer(data) {
    console.log("data create offer", data)
    
    let maskedPrecoBiometano = data.precoBiometano;
    let removeMaskPrecoBiometano = maskedPrecoBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoBiometanoToNumber = Number(removeMaskPrecoBiometano);
    let maskedPrecoFrete = data.precoFrete;
    let removeMaskPrecoFrete = maskedPrecoFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoFreteToNumber = Number(removeMaskPrecoFrete);
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: data.totalBiometano, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "V", //data.oferta.id,
        ofertaTipo:{
          id: 1 //data.id
        },
        empresaPrivada: {
          id: data.empresaPrivadaId
        }
      },
      listaNegociacaoProposta: [
        {
          idItem: "3", //Sazonalidade
          valor: data.tipoFornecimento
        },
        {
          idItem: "5", //Local de entrega
          valor: data.localEntregaId
        },
        {
          idItem: "8", //Flexibilidade
          valor: data.modalidade
        },
        {
          idItem: "13", //Valor - preço do biometano
          valor: removedMaskPrecoBiometanoToNumber
        },
        {
          idItem: "14", // tipo frete
          valor: data.tipoFrete
        },
        {
          idItem: "15", //Logística
          valor: data.logistica
        },
        {
          idItem: "18", // data de inicio do fornecimento
          valor: data.inicioFornecimento
        },
        {
          idItem: "19", // preço do frete
          valor: removedMaskPrecoFreteToNumber
        },
        {
          idItem: "21", // data de termino do fornecimento
          valor: data.fimFornecimento
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: [
        {
          mes: "1",
          valorMes: data.entregasSazonais[0].qty
        },
        {
          mes: "2",
          valorMes: data.entregasSazonais[1].qty
        },
        {
          mes: "3",
          valorMes: data.entregasSazonais[2].qty
        },
        {
          mes: "4",
          valorMes: data.entregasSazonais[3].qty
        },
        {
          mes: "5",
          valorMes: data.entregasSazonais[4].qty
        },
        {
          mes: "6",
          valorMes: data.entregasSazonais[5].qty
        },
        {
          mes: "7",
          valorMes: data.entregasSazonais[6].qty
        },
        {
          mes: "8",
          valorMes: data.entregasSazonais[7].qty
        },
        {
          mes: "9",
          valorMes: data.entregasSazonais[8].qty
        },
        {
          mes: "10",
          valorMes: data.entregasSazonais[9].qty
        },
        {
          mes: "11",
          valorMes: data.entregasSazonais[10].qty
        },
        {
          mes: "12",
          valorMes: data.entregasSazonais[11].qty
        }
      ]
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  createOfferPublica(data) {
    console.log("data create offer", data)
    
    let maskedPrecoBiometano = data.precoBiometano;
    let removeMaskPrecoBiometano = maskedPrecoBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoBiometanoToNumber = Number(removeMaskPrecoBiometano);
    let maskedPrecoFrete = data.precoFrete;
    let removeMaskPrecoFrete = maskedPrecoFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoFreteToNumber = Number(removeMaskPrecoFrete);
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: data.totalBiometano, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "V", //data.oferta.id,
        ofertaTipo:{
          id: 1 //data.id
        },
        empresaPrivada: null
      },
      listaNegociacaoProposta: [
        {
          idItem: "3", //Sazonalidade
          valor: data.tipoFornecimento
        },
        {
          idItem: "5", //Local de entrega
          valor: data.localEntregaId
        },
        {
          idItem: "8", //Flexibilidade
          valor: data.modalidade
        },
        {
          idItem: "13", //Valor - preço do biometano
          valor: removedMaskPrecoBiometanoToNumber
        },
        {
          idItem: "14", // tipo frete
          valor: data.tipoFrete
        },
        {
          idItem: "15", //Logística
          valor: data.logistica
        },
        {
          idItem: "18", // data de inicio do fornecimento
          valor: data.inicioFornecimento
        },
        {
          idItem: "19", // preço do frete
          valor: removedMaskPrecoFreteToNumber
        },
        {
          idItem: "21", // data de termino do fornecimento
          valor: data.fimFornecimento
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: [
        {
          mes: "1",
          valorMes: data.entregasSazonais[0].qty
        },
        {
          mes: "2",
          valorMes: data.entregasSazonais[1].qty
        },
        {
          mes: "3",
          valorMes: data.entregasSazonais[2].qty
        },
        {
          mes: "4",
          valorMes: data.entregasSazonais[3].qty
        },
        {
          mes: "5",
          valorMes: data.entregasSazonais[4].qty
        },
        {
          mes: "6",
          valorMes: data.entregasSazonais[5].qty
        },
        {
          mes: "7",
          valorMes: data.entregasSazonais[6].qty
        },
        {
          mes: "8",
          valorMes: data.entregasSazonais[7].qty
        },
        {
          mes: "9",
          valorMes: data.entregasSazonais[8].qty
        },
        {
          mes: "10",
          valorMes: data.entregasSazonais[9].qty
        },
        {
          mes: "11",
          valorMes: data.entregasSazonais[10].qty
        },
        {
          mes: "12",
          valorMes: data.entregasSazonais[11].qty
        }
      ]
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  // OFERTA DE VENDA DE BIOMETANO COM CERTIFICADO
  createOfferWithCert(data) {
    console.log("data create offer com certificado", data)
    let maskedPrecoBiometano = data.precoBiometano;
    let removeMaskPrecoBiometano = maskedPrecoBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoBiometanoToNumber = Number(removeMaskPrecoBiometano);
    let maskedPrecoCertificado = data.precoCertificado;
    let removeMaskPrecoCertificado = maskedPrecoCertificado.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoCertificadoToNumber = Number(removeMaskPrecoCertificado);
    let maskedPrecoFrete = data.precoFrete;
    let removeMaskPrecoFrete = maskedPrecoFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoFreteToNumber = Number(removeMaskPrecoFrete);
  
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: data.totalBiometano, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "V", //data.oferta.id,
        ofertaTipo:{
          id: 2 //data.id
        },
        certificado:{
          id: 2 //data.id
        },
        empresaPrivada: {
          id: data.empresaPrivadaId
        }
      },
      listaNegociacaoProposta: [
        {
          idItem: "3", //Sazonalidade
          valor: data.tipoFornecimento
        },
        {
          idItem: "5", //Local de entrega
          valor: data.localEntregaId
        },
        {
          idItem: "8", //Flexibilidade
          valor: data.modalidade
        },
        {
          idItem: "13", //Valor - preço do biometano
          valor: removedMaskPrecoBiometanoToNumber
        },
        {
          idItem: "14", // tipo frete
          valor: data.tipoFrete
        },
        {
          idItem: "15", //Logistica
          valor: data.logistica
        },
        {
          idItem: "17", //Valor certificado
          valor: removedMaskPrecoCertificadoToNumber
        },
        {
          idItem: "18", // data de inicio do fornecimento
          valor: data.inicioFornecimento
        },
        {
          idItem: "19", // preço do frete
          valor: removedMaskPrecoFreteToNumber
        },
        {
          idItem: "21", // data de termino do fornecimento
          valor: data.fimFornecimento
        },
        {
          idItem: "22", // Quantidade de certificados
          valor: data.qntCertificado
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: [
        {
          mes: "1",
          valorMes: data.entregasSazonais[0].qty
        },
        {
          mes: "2",
          valorMes: data.entregasSazonais[1].qty
        },
        {
          mes: "3",
          valorMes: data.entregasSazonais[2].qty
        },
        {
          mes: "4",
          valorMes: data.entregasSazonais[3].qty
        },
        {
          mes: "5",
          valorMes: data.entregasSazonais[4].qty
        },
        {
          mes: "6",
          valorMes: data.entregasSazonais[5].qty
        },
        {
          mes: "7",
          valorMes: data.entregasSazonais[6].qty
        },
        {
          mes: "8",
          valorMes: data.entregasSazonais[7].qty
        },
        {
          mes: "9",
          valorMes: data.entregasSazonais[8].qty
        },
        {
          mes: "10",
          valorMes: data.entregasSazonais[9].qty
        },
        {
          mes: "11",
          valorMes: data.entregasSazonais[10].qty
        },
        {
          mes: "12",
          valorMes: data.entregasSazonais[11].qty
        }
      ]
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  // OFERTA DE VENDA SOMENTE CERTIFICADO
  createOfferCert(data) {
    console.log("data create offer cert", data)
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: 0, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "V", //data.oferta.id,
        ofertaTipo:{
          id: 3 //data.id
        },
        certificado:{
          id: 2 //data.id
        },
        empresaPrivada: {
          id: data.empresaPrivadaId
        }
      },
      listaNegociacaoProposta: [
        {
          idItem: "17", //Preço por certificado
          valor: data.precoCertificado
        },
        {
          idItem: "22", //Quantidade de certificados
          valor: data.qntCertificado
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: null
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  createOfferBuy(data) {
    console.log("data create offer de compra somente biometano", data)
    let maskedPrecoBiometano = data.precoBiometano;
    let removeMaskPrecoBiometano = maskedPrecoBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoBiometanoToNumber = Number(removeMaskPrecoBiometano);
    let maskedPrecoFrete = data.precoFrete;
    let removeMaskPrecoFrete = maskedPrecoFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoFreteToNumber = Number(removeMaskPrecoFrete);
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: data.totalBiometano, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "C", //data.oferta.id,
        ofertaTipo:{
          id: 1 //data.id
        },
        empresaPrivada: {
          id: data.empresaPrivadaId
        }
      },
      listaNegociacaoProposta: [
        {
          idItem: "3", //Sazonalidade
          valor: data.tipoFornecimento
        },
        {
          idItem: "5", //Local de entrega
          valor: data.localEntregaId
        },
        {
          idItem: "8", //Flexibilidade
          valor: data.modalidade
        },
        {
          idItem: "13", //Valor - preço do biometano
          valor: removedMaskPrecoBiometanoToNumber
        },
        {
          idItem: "14", // tipo frete
          valor: data.tipoFrete
        },
        {
          idItem: "15", //Logistica
          valor: data.logistica
        },
        {
          idItem: "18", // data de inicio do fornecimento
          valor: data.inicioFornecimento
        },
        {
          idItem: "19", // preço do frete
          valor: removedMaskPrecoFreteToNumber
        },
        {
          idItem: "21", // data de termino do fornecimento
          valor: data.fimFornecimento
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: [
        {
          mes: "1",
          valorMes: data.entregasSazonais[0].qty
        },
        {
          mes: "2",
          valorMes: data.entregasSazonais[1].qty
        },
        {
          mes: "3",
          valorMes: data.entregasSazonais[2].qty
        },
        {
          mes: "4",
          valorMes: data.entregasSazonais[3].qty
        },
        {
          mes: "5",
          valorMes: data.entregasSazonais[4].qty
        },
        {
          mes: "6",
          valorMes: data.entregasSazonais[5].qty
        },
        {
          mes: "7",
          valorMes: data.entregasSazonais[6].qty
        },
        {
          mes: "8",
          valorMes: data.entregasSazonais[7].qty
        },
        {
          mes: "9",
          valorMes: data.entregasSazonais[8].qty
        },
        {
          mes: "10",
          valorMes: data.entregasSazonais[9].qty
        },
        {
          mes: "11",
          valorMes: data.entregasSazonais[10].qty
        },
        {
          mes: "12",
          valorMes: data.entregasSazonais[11].qty
        }
      ]
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  createOfferBuyPublica(data) {
    console.log("data create offer compra somente biometano", data)
    
    let maskedPrecoBiometano = data.precoBiometano;
    let removeMaskPrecoBiometano = maskedPrecoBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoBiometanoToNumber = Number(removeMaskPrecoBiometano);
    let maskedPrecoFrete = data.precoFrete;
    let removeMaskPrecoFrete = maskedPrecoFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoFreteToNumber = Number(removeMaskPrecoFrete);
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: data.totalBiometano, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "C", //data.oferta.id,
        ofertaTipo:{
          id: 1 //data.id
        },
        empresaPrivada: null
      },
      listaNegociacaoProposta: [
        {
          idItem: "3", //Sazonalidade
          valor: data.tipoFornecimento
        },
        {
          idItem: "5", //Local de entrega
          valor: data.localEntregaId
        },
        {
          idItem: "8", //Flexibilidade
          valor: data.modalidade
        },
        {
          idItem: "13", //Valor - preço do biometano
          valor: removedMaskPrecoBiometanoToNumber
        },
        {
          idItem: "14", // tipo frete
          valor: data.tipoFrete
        },
        {
          idItem: "15", //Logística
          valor: data.logistica
        },
        {
          idItem: "18", // data de inicio do fornecimento
          valor: data.inicioFornecimento
        },
        {
          idItem: "19", // preço do frete
          valor: removedMaskPrecoFreteToNumber
        },
        {
          idItem: "21", // data de termino do fornecimento
          valor: data.fimFornecimento
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: [
        {
          mes: "1",
          valorMes: data.entregasSazonais[0].qty
        },
        {
          mes: "2",
          valorMes: data.entregasSazonais[1].qty
        },
        {
          mes: "3",
          valorMes: data.entregasSazonais[2].qty
        },
        {
          mes: "4",
          valorMes: data.entregasSazonais[3].qty
        },
        {
          mes: "5",
          valorMes: data.entregasSazonais[4].qty
        },
        {
          mes: "6",
          valorMes: data.entregasSazonais[5].qty
        },
        {
          mes: "7",
          valorMes: data.entregasSazonais[6].qty
        },
        {
          mes: "8",
          valorMes: data.entregasSazonais[7].qty
        },
        {
          mes: "9",
          valorMes: data.entregasSazonais[8].qty
        },
        {
          mes: "10",
          valorMes: data.entregasSazonais[9].qty
        },
        {
          mes: "11",
          valorMes: data.entregasSazonais[10].qty
        },
        {
          mes: "12",
          valorMes: data.entregasSazonais[11].qty
        }
      ]
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  createBuyOfferWithCert(data) {
    console.log("data create offer compra com certificado", data)
    let maskedPrecoBiometano = data.precoBiometano;
    let removeMaskPrecoBiometano = maskedPrecoBiometano.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoBiometanoToNumber = Number(removeMaskPrecoBiometano);
    let maskedPrecoFrete = data.precoFrete;
    let removeMaskPrecoFrete = maskedPrecoFrete.replaceAll(".","").replaceAll(",","").replace("R$","");
    let removedMaskPrecoFreteToNumber = Number(removeMaskPrecoFrete);
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: data.totalBiometano, //data.oferta.id,
        exibeNomeEmpresa: data.exibeNomeEmpresa,
        tipo: "C", //data.oferta.id,
        ofertaTipo:{
          id: 2 //data.id
        },
        certificado:{
          id: 2 //data.id
        },
        empresaPrivada: data.empresaPrivadaId
      },
      listaNegociacaoProposta: [
        {
          idItem: "3", //Sazonalidade
          valor: data.tipoFornecimento
        },
        {
          idItem: "5", //Local de entrega
          valor: data.localEntregaId
        },
        {
          idItem: "8", //Flexibilidade
          valor: data.modalidade
        },
        {
          idItem: "13", //Valor - preço do biometano
          valor: removedMaskPrecoBiometanoToNumber
        },
        {
          idItem: "14", // tipo frete
          valor: data.tipoFrete
        },
        {
          idItem: "15", //Logistica
          valor: data.logistica
        },
        {
          idItem: "17", //Valor certificado
          valor: 10
        },
        {
          idItem: "18", // data de inicio do fornecimento
          valor: data.inicioFornecimento
        },
        {
          idItem: "19", // preço do frete
          valor: removedMaskPrecoFreteToNumber
        },
        {
          idItem: "21", // data de termino do fornecimento
          valor: data.fimFornecimento
        },
        {
          idItem: "22", // Quantidade de certificados
          valor: data.qntCertificado
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: [
        {
          mes: "1",
          valorMes: data.entregasSazonais[0].qty
        },
        {
          mes: "2",
          valorMes: data.entregasSazonais[1].qty
        },
        {
          mes: "3",
          valorMes: data.entregasSazonais[2].qty
        },
        {
          mes: "4",
          valorMes: data.entregasSazonais[3].qty
        },
        {
          mes: "5",
          valorMes: data.entregasSazonais[4].qty
        },
        {
          mes: "6",
          valorMes: data.entregasSazonais[5].qty
        },
        {
          mes: "7",
          valorMes: data.entregasSazonais[6].qty
        },
        {
          mes: "8",
          valorMes: data.entregasSazonais[7].qty
        },
        {
          mes: "9",
          valorMes: data.entregasSazonais[8].qty
        },
        {
          mes: "10",
          valorMes: data.entregasSazonais[9].qty
        },
        {
          mes: "11",
          valorMes: data.entregasSazonais[10].qty
        },
        {
          mes: "12",
          valorMes: data.entregasSazonais[11].qty
        }
      ]
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  // OFERTA DE COMPRA SOMENTE CERTIFICADO
  createOfferBuyCert(data) {
    console.log("data create buy offer cert", data)
    
    return axios.post(API_URL + 'ofertas',
    {
      observacaoRodada:"Ta dificil",
      oferta:{
        quantidade: 0, //data.oferta.id,
        tipo: "C", //data.oferta.id,
        ofertaTipo:{
          id: 3 //data.id
        },
        certificado:{
          id: 2 //data.id
        },
        // empresaPrivada: {
        //   id: data.empresaPrivadaId
        // }
      },
      listaNegociacaoProposta: [
        {
          idItem: "17", //Preço por certificado
          valor: data.precoCertificado
        },
        {
          idItem: "22", //Quantidade de certificados
          valor: data.qntCertificado
        }
      ],
      //data.listaNegociacaoProposta,
      entregasSazonais: null
      //data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

  sendProposal(data) {
    console.log("data send proposal", data)
    return axios.post(API_URL + 'negociacoes',
    {
      oferta:{
        id: data.oferta.id,
        ofertaTipo:{
          id:data.oferta.ofertaTipo.id
        },
        tipo: data.oferta.tipo,
        certificado:{
          id: 2 //ID do certificado
        },
      },
      observacaoRodada:"Sem observação",
      listaNegociacaoProposta: data.listaNegociacaoProposta,
      entregasSazonais: data.entregasSazonais
    }, { headers: authHeader()} );
    //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
  }

}

export default new OfferService();