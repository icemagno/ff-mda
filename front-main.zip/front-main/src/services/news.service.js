import axios from 'axios';
import authHeader from './auth-header';
import { environment } from '@/store/environment';

const API_URL = environment.API_URL + 'drwars/api/v1/';

class NewsService {
    getAll(page, size) {
        return axios.get(API_URL + 'noticias/', { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    getLastestNews() {
        return axios.get(API_URL + 'noticias/?page=0&limit=2&direction=desc', { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    viewNews(newsId) {
        return axios.get(API_URL + 'noticias/' + `${newsId}`, { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    register(data) {
        console.log("news register service", data);
        return axios.post(API_URL + 'noticias', {
            titulo: data.title,
            texto: data.text
        },
        { headers: authHeader() })
        .then(response => {
            console.log("news register service error", response);
            return response.data;
        });
    }
}

export default new NewsService();
