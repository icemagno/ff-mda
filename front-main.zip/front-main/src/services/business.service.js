import axios from 'axios';
import authHeader from './auth-header';
import { environment } from '@/store/environment';

const API_URL = environment.API_URL + 'drwars/api/v1/';

class BusinessService {
    getAll(tipo) {
        return axios.get(API_URL + 'empresas/?size=200&tipo=' + `${tipo}`, { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    getAllWithoutLoggedCompany(tipo) {
        return axios.get(API_URL + 'empresas/withoutLoggedCompany?size=200&tipo=' + `${tipo}`, { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
    viewBusiness(newsId) {
        return axios.get(API_URL + 'empresas/' + `${newsId}`, { headers: authHeader() } );
        //return axios.get(API_URL + 'v1/ofertas/buscarPorTipo', { headers: authHeader() });
    }
}

export default new BusinessService();
