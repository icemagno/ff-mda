
<template>
  <template v-if="currentUser">
    <HeaderMainFornecedor v-if="currentUser.roles == 'ADMIN' || currentUser.roles == 'FORNECEDOR'"/>
    <HeaderMainConsumidor v-if="currentUser.roles == 'CONSUMIDOR'"/>
  </template>
  <div class="container container-full">
    <router-view />
  </div>
</template>

<script>
import HeaderMain from './components/common/HeaderMain.vue'
import HeaderMainFornecedor from './components/common/HeaderMainFornecedor.vue'
import HeaderMainConsumidor from './components/common/HeaderMainConsumidor.vue'
import { useRouter } from 'vue-router'

export default {
  name: 'App',
  components: {
    HeaderMain,
    HeaderMainFornecedor,
    HeaderMainConsumidor
  },
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    },
    showAdminBoard() {
      if (this.currentUser && this.currentUser['roles']) {
        return this.currentUser['roles'].includes('ROLE_ADMIN');
      }

      return false;
    },
    showFornecedorBoard() {
      if (this.currentUser && this.currentUser['roles']) {
        return this.currentUser['roles'].includes('ROLE_MODERATOR');
      }

      return false;
    }
  },
  methods: {
    logOut() {
      this.$store.dispatch('auth/logout');
      this.$router.push('/login');
    }
  }
}
</script>

<style lang="scss">
@import "./assets/styles/main.scss";
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
</style>
