import { createApp } from 'vue'
import App from './App.vue'
import router from "./router"
import store from "./store"
import { FontAwesomeIcon } from './plugins/font-awesome'
import vueAwesomeSidebar from 'vue-awesome-sidebar'
import VueGoodTablePlugin from 'vue-good-table-next';

import "bootstrap"
import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap-icons/font/bootstrap-icons.css";
import 'vue-awesome-sidebar/dist/vue-awesome-sidebar.css'
import 'vue-good-table-next/dist/vue-good-table-next.css'
/* import the fontawesome core */
import { library } from '@fortawesome/fontawesome-svg-core'
/* import specific icons */
import { faChargingStation } from '@fortawesome/free-solid-svg-icons'
import { faBullhorn } from '@fortawesome/free-solid-svg-icons'
import { faFileCircleCheck } from '@fortawesome/free-solid-svg-icons'

import mitt from 'mitt';
const emitter = mitt();

library.add(faChargingStation, faFileCircleCheck, faBullhorn)

const app = createApp(App)
    .use(router)
    .use(store)
    .use(vueAwesomeSidebar)
    .use(VueGoodTablePlugin)
    .component("font-awesome-icon", FontAwesomeIcon)
        
app.config.globalProperties.emitter = emitter;
app.mount("#app");