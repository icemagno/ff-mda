import { createWebHistory, createRouter } from "vue-router";
import Home from "./components/views/Home.vue";
import Login from "./components/views/Login.vue";
import Register from "./components/views/Register.vue";
// lazy-loaded
const Profile = () => import("./components/views/Profile.vue")
const Mercado = () => import("./components/views/Mercado.vue")
const Biometanotrade = () => import("./components/views/Biometanotrade.vue")
const BoardAdmin = () => import("./components/views/BoardAdmin.vue")
const BoardFornecedor = () => import("./components/views/BoardFornecedor.vue")
const BoardConsumidor = () => import("./components/views/BoardConsumidor.vue")
const BoardUser = () => import("./components/views/BoardUser.vue")
const Mapa = () => import("./components/views/Mapa.vue")
const Offers = () => import("./components/views/Offer.vue")
const BuyOffers = () => import("./components/views/BuyOffer.vue")
const EditItem = () => import("./components/views/Offers/Edit.vue")
const CreateOffer = () => import("./components/views/Offers/Create.vue")
const CreateOfferMixed = () => import("./components/views/Offers/CreateMixed.vue")
const CreateOfferCert = () => import("./components/views/Offers/CreateCert.vue")
const createOfferBuy = () => import("./components/views/Offers/CreateBuy.vue")
const CreateOfferBuyMixed = () => import("./components/views/Offers/CreateBuyMixed.vue")
const CreateOfferBuyCert = () => import("./components/views/Offers/CreateBuyCert.vue")
const Transactions = () => import("./components/views/Transactions.vue")
const Purchases = () => import("./components/views/Purchases.vue")
const ViewPurchase = () => import("./components/views/Purchase/View.vue")
const CreateNews = () => import("./components/views/News/Create.vue")
const ListNews = () => import("./components/views/News/List.vue")
const ViewNews = () => import("./components/views/News/View.vue")

const routes = [
  {
    path: "/",
    name: "home",
    component: Home,
  },
  {
    path: "/home",
    component: Home,
  },
  {
    path: "/mercado",
    name: "mercado",
    component: Mercado,
  },
  {
    path: "/biometanotrade",
    name: "biometanotrade",
    component: Biometanotrade,
  },
  {
    path: "/login",
    component: Login,
  },
  {
    path: "/cadastre-se",
    name: "register",
    component: Register,
  },
  {
    path: "/profile",
    name: "profile",
    component: Profile,
  },
  {
    path: "/admin",
    name: "admin",
    component: BoardAdmin,
  },
  {
    path: "/fornecedor",
    name: "fornecedor",
    component: BoardFornecedor,
  },
  {
    path: "/consumidor",
    name: "consumidor",
    component: BoardConsumidor,
  },
  {
    path: "/user",
    name: "user",
    component: BoardUser,
  },
  {
    path: "/mapa",
    name: "mapa",
    component: Mapa,
  },
  {
    path: "/ofertas",
    name: "offers",
    component: Offers,
  },
  {
    path: "/ofertas-compra",
    name: "buyOffers",
    component: BuyOffers,
  },
  {
    path: '/ofertas/editar',
    name: 'edit-item',
    component: EditItem,
    props: (route) => ({ itemData: route.params.itemData }),
  },
  {
    path: '/ofertas/criar',
    name: 'create-offer',
    component: CreateOffer,
  },
  {
    path: '/ofertas/criar/certificado',
    name: 'create-offer-cert',
    component: CreateOfferCert,
  },
  {
    path: '/ofertas/criar/biometano-com-certificado',
    name: 'create-offer-mixed',
    component: CreateOfferMixed,
  },
  {
    path: '/ofertas/criar-compra',
    name: 'create-offer-buy',
    component: createOfferBuy,
  },
  {
    path: '/ofertas/criar-compra/biometano-com-certificado',
    name: 'create-offer-buy-mixed',
    component: CreateOfferBuyMixed,
  },
  {
    path: '/ofertas/criar-compra/somente-certificado',
    name: 'create-offer-buy-cert',
    component: CreateOfferBuyCert,
  },
  {
    path: "/negociacoes",
    name: "transactions",
    component: Transactions,
  },
  {
    path: "/compras",
    name: "purchases",
    component: Purchases,
  },
  {
    path: '/compras/visualizar',
    name: 'view-purchase',
    component: ViewPurchase,
    props: (route) => ({ itemData: route.params.itemData }),
  },
  {
    path: '/noticias',
    name: 'list-news',
    component: ListNews,
  },
  {
    path: '/noticias/criar',
    name: 'create-news',
    component: CreateNews,
  },
  {
    path: '/noticias/visualizar',
    name: 'view-news',
    component: ViewNews,
    props: (route) => ({ itemData: route.params.itemData }),
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
    const rootPage = ['/'];
    //const publicPages = ['/', '/login', '/register', '/home', '/mapa', '/ofertas/criar', '/noticias/criar', '/noticias'];
    const publicPages = ['/', '/login', '/cadastre-se', '/home', '/mapa', '/mercado', '/biometanotrade'];
    const authRequired = !publicPages.includes(to.path);
    const loggedIn = localStorage.getItem('user');

    // trying to access a restricted page + not logged in
    // redirect to login page
    
    if (authRequired && !loggedIn) {
        next('/login');
    } else {
      next( );
    }
    
    
});

export default router;