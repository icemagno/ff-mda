package br.com.j1scorpii.ffmda.util;

public interface IFireFlyComponent {
	String getComponentDataFolder();
}
