package br.com.j1scorpii.ffmda.util;

public enum ImageDownloaderStatus {
	IDLE,
	PULLING,
	WAITING,
	FINISHED
}
