package br.com.j1scorpii.ffmda.util;

public enum RemoteAgentStatus {
	CONNECTED,
	CONNECTING,
	DISCONNECTED,
	NEW_ADDED
}
