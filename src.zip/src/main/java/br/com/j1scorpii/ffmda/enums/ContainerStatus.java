package br.com.j1scorpii.ffmda.enums;

public enum ContainerStatus {
	NOT_FOUND, RUNNING, STOPPED, NO_IMAGE
}
