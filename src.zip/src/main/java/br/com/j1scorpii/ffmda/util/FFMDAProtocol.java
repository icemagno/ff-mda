package br.com.j1scorpii.ffmda.util;

public enum FFMDAProtocol {
	NODE_DATA,
	QUERY_DATA,
	AGENT_INFO
}
