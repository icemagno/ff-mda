-- Table: public.tb_permissoes

-- DROP TABLE IF EXISTS public.tb_permissoes;

CREATE TABLE IF NOT EXISTS public.tb_permissoes
(
    id_permissao smallserial NOT NULL,
    ds_permissao character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_permissoes PRIMARY KEY (id_permissao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_permissoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_permissoes
    IS 'Permissões a serem atribuídas a um perfil.';

COMMENT ON COLUMN public.tb_permissoes.id_permissao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_permissoes.ds_permissao
    IS 'Descrição da permissão.';
	
COMMENT ON CONSTRAINT pk_permissoes ON public.tb_permissoes
    IS 'Chave primária da tabela tb_permissoes.';
