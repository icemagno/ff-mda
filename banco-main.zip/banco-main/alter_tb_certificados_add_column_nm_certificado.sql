ALTER TABLE IF EXISTS public.tb_certificados
    ADD COLUMN nm_certificado character varying(50) NOT NULL;

COMMENT ON COLUMN public.tb_certificados.nm_certificado
    IS 'Nome do certificado.';