-- Table: public.tb_logistica_dutos

-- DROP TABLE IF EXISTS public.tb_logistica_dutos;

CREATE TABLE IF NOT EXISTS public.tb_logistica_dutos
(
    id_logistica_duto serial NOT NULL,
    nome_duto character varying(100) COLLATE pg_catalog."default" NOT NULL,
    diametro_duto numeric NOT NULL,
    id_logistica integer NOT NULL,
	id_empresa integer,
    the_geom geometry,
    CONSTRAINT pk_logistica_dutos PRIMARY KEY (id_logistica_duto),
    CONSTRAINT fk_logistica_dutos_logistica FOREIGN KEY (id_logistica)
        REFERENCES public.tb_logisticas (id_logistica) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_logistica_dutos_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_logistica_dutos
    OWNER to postgres;

COMMENT ON TABLE public.tb_logistica_dutos
    IS 'Logística de transporte por tudos.';

COMMENT ON COLUMN public.tb_logistica_dutos.id_logistica_duto
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_logistica_dutos.id_logistica
    IS 'Logística de transporte envolvendo o duto.';

COMMENT ON COLUMN public.tb_logistica_dutos.id_empresa
    IS 'Empresa a que pertence o duto.';

COMMENT ON COLUMN public.tb_logistica_dutos.the_geom
    IS 'Dado georreferenciado: localização do duto.';
	
COMMENT ON CONSTRAINT pk_logistica_dutos ON public.tb_logistica_dutos
    IS 'Chave primária da tabela tb_logistica_dutos.';

COMMENT ON CONSTRAINT fk_logistica_dutos_logistica ON public.tb_logistica_dutos
    IS 'Chave estrangeira da coluna id_logistica.';

COMMENT ON CONSTRAINT fk_logistica_dutos_empresa ON public.tb_logistica_dutos
    IS 'Chave estrangeira da coluna id_empresa.';