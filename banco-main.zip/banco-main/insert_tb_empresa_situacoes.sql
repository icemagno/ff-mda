insert into public.tb_empresa_situacoes(id_empresa_situacao,ds_empresa_situacao) values (1,'Importada Manualmente');
