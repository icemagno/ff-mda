-- Table: public.tb_perfil_situacoes

-- DROP TABLE IF EXISTS public.tb_perfil_situacoes;

CREATE TABLE IF NOT EXISTS public.tb_perfil_situacoes
(
    id_perfil_situacao smallserial NOT NULL,
    ds_perfil_situacao character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_perfil_situacoes PRIMARY KEY (id_perfil_situacao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_perfil_situacoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_perfil_situacoes
    IS 'Situações possíveis de um perfil.';

COMMENT ON COLUMN public.tb_perfil_situacoes.id_perfil_situacao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_perfil_situacoes.ds_perfil_situacao
    IS 'Descrição da situação de perfil.';
	
COMMENT ON CONSTRAINT pk_perfil_situacoes ON public.tb_perfil_situacoes
    IS 'Chave primária da tabela perfil_situacoes.';