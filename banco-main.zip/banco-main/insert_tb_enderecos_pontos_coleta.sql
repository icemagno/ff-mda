insert into tb_enderecos(cidade,estado,the_geom)
select 'Mirandópolis','SP',st_makepoint(-51.1019,-21.1347)
union
select 'Valparaíso','SP',st_makepoint(-50.8673,-21.2287)
union
select 'Penápolis','SP',st_makepoint(-50.078,-21.4209)
union
select 'São Carlos','SP',st_makepoint(-47.8911,-22.0154)
union
select 'Limeira','SP',st_makepoint(-47.4004,-22.5645)
union
select 'Bragança Paulista','SP',st_makepoint(-46.5425,-22.9523)
union
select 'Taubaté','SP',st_makepoint(-45.5483,-23.0309)
union
select 'Arapei','SP',st_makepoint(-44.4445,-22.6748)
union
select 'Paulínia','SP',st_makepoint(-47.1541,-22.7617)
union
select 'Araçoiaba da Serra','SP',st_makepoint(-47.6145,-23.5045)
union
select 'Capão Bonito','SP',st_makepoint(-48.3393,-24.004)
union
select 'Itapirapuã Paulista','SP',st_makepoint(-49.1699,-24.5765)