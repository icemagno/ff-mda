ALTER TABLE IF EXISTS public.tb_locais
    ADD COLUMN id_empresa integer;

COMMENT ON COLUMN public.tb_locais.id_empresa
    IS 'Empresa a que pertence o local. Se nulo, o local é público.';
ALTER TABLE IF EXISTS public.tb_locais
    ADD CONSTRAINT fk_locais_empresa FOREIGN KEY (id_empresa)
    REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_locais_empresa ON public.tb_locais
    IS 'Chave estrangeira da coluna id_empresa.';