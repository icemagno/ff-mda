ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN id_certificado integer;

COMMENT ON COLUMN public.tb_ofertas.id_certificado
    IS 'Certificados sendo oferecidos.';

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN quantidade_certificados integer;

COMMENT ON COLUMN public.tb_ofertas.quantidade_certificados
    IS 'Quantidade de certificados oferecidos.';
	
ALTER TABLE IF EXISTS public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_certificado FOREIGN KEY (id_certificado)
    REFERENCES public.tb_certificados (id_certificado) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_ofertas_certificado ON public.tb_ofertas
    IS 'Chave estrangeira da coluna id_certificado.';