insert into tb_dutos(nome_duto,the_geom)
select 'mirandopolis-valparaiso-penapolis-sao carlos-limeira-paulinia',st_makeline(ARRAY['POINT(-51.1019 -21.1347)',
'POINT(-50.8673 -21.2287)',
'POINT(-50.078 -21.4209)',
'POINT(-47.8911 -22.0154)',
'POINT(-47.4004 -22.5645)',
'POINT(-47.1541 -22.7617)'])
union
select 'paulinia-braganca-taubate-arapei',st_makeline(ARRAY['POINT(-47.1541 -22.7617)',
'POINT(-46.5425 -22.9523)',
'POINT(-45.5483 -23.0309)',
'POINT(-44.4445 -22.6748)'])
union
select 'paulinia-aracoiaba-capao bonito-itapirapua',st_makeline(ARRAY['POINT(-47.1541 -22.7617)',
'POINT(-47.6145 -23.5045)',
'POINT(-48.3393 -24.004)',
'POINT(-49.1699 -24.5765)'])