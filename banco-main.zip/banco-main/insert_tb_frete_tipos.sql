insert into public.tb_frete_tipos(id_frete_tipo,sg_frete_tipo,ds_frete_tipo) values (1,'CIF','Responsabilidade Vendedor');
insert into public.tb_frete_tipos(id_frete_tipo,sg_frete_tipo,ds_frete_tipo) values (2,'FOB','Responsabilidade Comprador');
