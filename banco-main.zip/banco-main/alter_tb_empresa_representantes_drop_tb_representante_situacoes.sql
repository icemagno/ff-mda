
ALTER TABLE IF EXISTS public.tb_empresa_representantes DROP CONSTRAINT IF EXISTS fk_empresa_representantes_situacao;

ALTER TABLE IF EXISTS public.tb_empresa_representantes DROP COLUMN IF EXISTS id_representante_situacao;

ALTER TABLE IF EXISTS public.tb_empresa_representantes
    ADD COLUMN ativo boolean;
	
DROP TABLE public.tb_representante_situacoes;
