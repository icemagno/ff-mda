ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN sazonalidade DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN id_compra_situacao DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN flexibilidade DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN id_frete_tipo DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN dt_inicio_entrega DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN dt_fim_entrega DROP NOT NULL;