COMMENT ON COLUMN public.tb_logisticas.tipo_transporte
    IS 'Transporte, distribuição, GNC, GNL, outros (campo livre).';

ALTER TABLE IF EXISTS public.tb_logisticas
    DROP COLUMN IF EXISTS estado;