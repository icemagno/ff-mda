DROP TABLE IF EXISTS public.tb_compra_intencoes;

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN id_oferta_tipo smallint NOT NULL;

COMMENT ON COLUMN public.tb_ofertas.id_oferta_tipo
    IS 'Tipo da oferta: compra ou venda.';

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_tipo FOREIGN KEY (id_oferta_tipo)
    REFERENCES public.tb_oferta_tipos (id_oferta_tipo) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_ofertas_tipo ON public.tb_ofertas
    IS 'Chave estrangeira da coluna id_oferta_tipo.';