ALTER TABLE IF EXISTS public.tb_entregas_sazonais DROP CONSTRAINT IF EXISTS fk_entregas_sazonais_negociacao_rodada;

ALTER TABLE IF EXISTS public.tb_entregas_sazonais
    ADD CONSTRAINT fk_entregas_sazonais_negociacao_rodada FOREIGN KEY (id_negociacao_rodada)
    REFERENCES public.tb_negociacao_rodadas (id_negociacao_rodada) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_entregas_sazonais_negociacao_rodada ON public.tb_entregas_sazonais
    IS 'Chave estrangeira da coluna id_negociacao_rodada.';