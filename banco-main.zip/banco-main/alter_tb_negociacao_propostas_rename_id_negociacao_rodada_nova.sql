ALTER TABLE IF EXISTS public.tb_negociacao_propostas
    RENAME id_negociacao_rodada_nova TO id_negociacao_rodada;