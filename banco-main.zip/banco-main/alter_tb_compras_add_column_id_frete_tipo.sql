ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN id_frete_tipo smallint NOT NULL;

COMMENT ON COLUMN public.tb_compras.id_frete_tipo
    IS 'Tipo de frete adotado na compra.';
	
ALTER TABLE IF EXISTS public.tb_compras
    ADD CONSTRAINT fk_compras_tipo_frete FOREIGN KEY (id_frete_tipo)
    REFERENCES public.tb_frete_tipos (id_frete_tipo) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_compras_tipo_frete ON public.tb_compras
    IS 'Chave estrangeira da coluna id_frete_tipo.';