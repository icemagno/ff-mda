COMMENT ON COLUMN public.tb_entregas_sazonais.mes_entrega
    IS 'Mês da entrega.';

ALTER TABLE IF EXISTS public.tb_entregas_sazonais
    ADD COLUMN ano_entrega smallint NOT NULL;

COMMENT ON COLUMN public.tb_entregas_sazonais.ano_entrega
    IS 'Ano da entrega.';