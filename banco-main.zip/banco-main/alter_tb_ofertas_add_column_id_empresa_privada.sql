ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN id_empresa_privada integer;

COMMENT ON COLUMN public.tb_ofertas.id_empresa_privada
    IS 'Empresa a quem se destina a oferta no caso de a oferta ser privada.';

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_empresa_privada FOREIGN KEY (id_empresa_privada)
    REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_ofertas_empresa_privada ON public.tb_ofertas
    IS 'Chave estrangeira da coluna id_empresa_privada.';