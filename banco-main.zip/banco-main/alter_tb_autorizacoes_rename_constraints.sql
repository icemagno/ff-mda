ALTER TABLE public.tb_autorizacoes
    RENAME CONSTRAINT pk_certificados TO pk_autorizacoes;
	
ALTER TABLE IF EXISTS public.tb_autorizacoes
    RENAME CONSTRAINT fk_certificados_empresa_certificada TO fk_autorizacoes_empresa_certificada;