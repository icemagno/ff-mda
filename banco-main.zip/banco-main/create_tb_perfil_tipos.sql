-- Table: public.tb_perfil_tipos

-- DROP TABLE IF EXISTS public.tb_perfil_tipos;

CREATE TABLE IF NOT EXISTS public.tb_perfil_tipos
(
    id_perfil_tipo smallserial NOT NULL,
    ds_perfil_tipo character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_perfil_tipos PRIMARY KEY (id_perfil_tipo)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_perfil_tipos
    OWNER to postgres;

COMMENT ON TABLE public.tb_perfil_tipos
    IS 'Tipos possíveis de um perfil.';

COMMENT ON COLUMN public.tb_perfil_tipos.id_perfil_tipo
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_perfil_tipos.ds_perfil_tipo
    IS 'Descrição do tipo de perfil.';
	
COMMENT ON CONSTRAINT pk_perfil_tipos ON public.tb_perfil_tipos
    IS 'Chave primária da tabela tb_perfil_tipos.';