-- Table: public.tb_municipios

-- DROP TABLE IF EXISTS public.tb_municipios;

CREATE TABLE IF NOT EXISTS public.tb_municipios
(
    id_municipio serial NOT NULL,
    the_geom geometry(MultiPolygon,4674),
    cd_municipio character varying(7) COLLATE pg_catalog."default",
    nm_municipio character varying(50) COLLATE pg_catalog."default",
    sigla_uf character varying(2) COLLATE pg_catalog."default",
    area_km2 numeric(12,3),
    CONSTRAINT pk_municipios PRIMARY KEY (id_municipio)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_municipios
    OWNER to postgres;

COMMENT ON TABLE public.tb_municipios
    IS 'Dados georreferenciados dos municípios brasileiros. Fonte: IBGE, 2022.';

COMMENT ON COLUMN public.tb_municipios.id_municipio
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_municipios.the_geom
    IS 'Dado georreferenciado: área do município.';

COMMENT ON COLUMN public.tb_municipios.cd_municipio
    IS 'Código (IBGE) do município.';

COMMENT ON COLUMN public.tb_municipios.nm_municipio
    IS 'Nome do município.';

COMMENT ON COLUMN public.tb_municipios.sigla_uf
    IS 'Sigla da Unidade da Federação a que pertence o município.';

COMMENT ON COLUMN public.tb_municipios.area_km2
    IS 'Extensão da área, em quilômetros quadrados, do município.';
	
COMMENT ON CONSTRAINT pk_municipios ON public.tb_municipios
    IS 'Chave primária da tabela tb_municipios.';