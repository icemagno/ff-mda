# banco
Banco de dados

```
docker run --name cometa-db --network=interna --hostname=cometa-db \
-e POSTGRES_USER=postgres \
-e POSTGRES_PASS=admin \
-e POSTGRES_DBNAME=cometa \
-p 36002:5432 \
-e ALLOW_IP_RANGE='0.0.0.0/0' \
-v /etc/localtime:/etc/localtime:ro \
-e POSTGRES_MULTIPLE_EXTENSIONS=postgis,hstore,postgis_topology \
-v /srv/cometa-db/:/var/lib/postgresql/ \
-d kartoza/postgis:14-3.3
```

Admin
```http://146.190.221.30:36321/```
