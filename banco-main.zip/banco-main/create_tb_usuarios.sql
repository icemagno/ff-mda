-- Table: public.tb_usuarios

-- DROP TABLE IF EXISTS public.tb_usuarios;

CREATE TABLE IF NOT EXISTS public.tb_usuarios
(
    id_usuario serial NOT NULL,
    username character varying(30) COLLATE pg_catalog.default NOT NULL,
    nome_completo character varying(100) COLLATE pg_catalog.default NOT NULL,
    password character varying(255) COLLATE pg_catalog.default NOT NULL,
    account_non_expired boolean DEFAULT true,
    account_non_locked boolean DEFAULT true,
    credentials_non_expired boolean DEFAULT true,
    enabled boolean DEFAULT true,
	id_perfil smallint,
    CONSTRAINT pk_usuarios PRIMARY KEY (id_usuario),
    CONSTRAINT uk_usuarios_username UNIQUE (username)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_usuarios
    OWNER to postgres;

COMMENT ON TABLE public.tb_usuarios
    IS 'Usuários do sistema.';

COMMENT ON COLUMN public.tb_usuarios.id_usuario
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_usuarios.username
    IS 'Login do usuário.';

COMMENT ON COLUMN public.tb_usuarios.nome_completo
    IS 'Nome completo do usuário.';

COMMENT ON COLUMN public.tb_usuarios.password
    IS 'Senha encriptada do usuário.';

COMMENT ON COLUMN public.tb_usuarios.account_non_expired
    IS 'Flag para conta expirada.';

COMMENT ON COLUMN public.tb_usuarios.account_non_locked
    IS 'Flag para conta bloqueada.';

COMMENT ON COLUMN public.tb_usuarios.credentials_non_expired
    IS 'Flag para credenciais expiradas.';

COMMENT ON COLUMN public.tb_usuarios.enabled
    IS 'Flag para usuário habilitado (ativo).';

COMMENT ON COLUMN public.tb_usuarios.id_perfil
    IS 'Perfil do usuário.';
	
COMMENT ON CONSTRAINT pk_usuarios ON public.tb_usuarios
    IS 'Chave primária da tabela tb_usuarios.';

COMMENT ON CONSTRAINT uk_usuarios_username ON public.tb_usuarios
    IS 'Unique constraint na coluna username';
