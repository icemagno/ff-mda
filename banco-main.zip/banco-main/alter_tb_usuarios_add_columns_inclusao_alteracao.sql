ALTER TABLE IF EXISTS public.tb_usuarios
    ADD COLUMN id_usuario_inclusao integer NOT NULL;

COMMENT ON COLUMN public.tb_usuarios.id_usuario_inclusao
    IS 'Usuário responsável pela inclusão do usuário.';

ALTER TABLE IF EXISTS public.tb_usuarios
    ADD COLUMN dt_inclusao timestamp without time zone NOT NULL;

COMMENT ON COLUMN public.tb_usuarios.dt_inclusao
    IS 'Data/hora da inclusão do usuário.';

ALTER TABLE IF EXISTS public.tb_usuarios
    ADD COLUMN id_usuario_alteracao integer;

COMMENT ON COLUMN public.tb_usuarios.id_usuario_alteracao
    IS 'Usuário responsável pela alteração do usuário.';

ALTER TABLE IF EXISTS public.tb_usuarios
    ADD COLUMN dt_alteracao timestamp without time zone;

COMMENT ON COLUMN public.tb_usuarios.dt_alteracao
    IS 'Data/hora da alteração do usuário.';
	
ALTER TABLE IF EXISTS public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_usuario_inclusao FOREIGN KEY (id_usuario_inclusao)
    REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_usuarios_usuario_inclusao ON public.tb_usuarios
    IS 'Chave estrangeira da coluna id_usuario_inclusao.';

ALTER TABLE IF EXISTS public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_usuario_alteracao FOREIGN KEY (id_usuario_alteracao)
    REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_usuarios_usuario_alteracao ON public.tb_usuarios
    IS 'Chave estrangeira da coluna id_usuario_alteracao.';