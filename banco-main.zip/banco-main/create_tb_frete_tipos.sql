-- Table: public.tb_frete_tipos

-- DROP TABLE IF EXISTS public.tb_frete_tipos;

CREATE TABLE IF NOT EXISTS public.tb_frete_tipos
(
    id_frete_tipo smallserial NOT NULL,
    sg_frete_tipo character varying(50) COLLATE pg_catalog."default" NOT NULL,
    ds_frete_tipo character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_frete_tipos PRIMARY KEY (id_frete_tipo)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_frete_tipos
    OWNER to postgres;

COMMENT ON TABLE public.tb_frete_tipos
    IS 'Tipos de frete: CIF/FOB.';

COMMENT ON COLUMN public.tb_frete_tipos.id_frete_tipo
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_frete_tipos.sg_frete_tipo
    IS 'Sigla do tipo de frete.';

COMMENT ON COLUMN public.tb_frete_tipos.ds_frete_tipo
    IS 'Descrição do tipo de frete.';
	
COMMENT ON CONSTRAINT pk_frete_tipos ON public.tb_frete_tipos
    IS 'Chave primária da tabela tb_frete_tipos.';