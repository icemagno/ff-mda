CREATE TABLE public.tb_entregas_sazonais
(
    id_entrega_sazonal serial NOT NULL,
    id_negociacao_rodada integer NOT NULL,
    mes_entrega smallint NOT NULL,
    valor_mes numeric NOT NULL,
    CONSTRAINT pk_entregas_sazonais PRIMARY KEY (id_entrega_sazonal),
    CONSTRAINT fk_entregas_sazonais_negociacao_rodada FOREIGN KEY (id_negociacao_rodada)
        REFERENCES public.tb_negociacao_rodadas (id_negociacao_rodada) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE IF EXISTS public.tb_entregas_sazonais
    OWNER to postgres;

COMMENT ON TABLE public.tb_entregas_sazonais
    IS 'Na entrega sazonal, os valores podem variar mês a mês.';

COMMENT ON COLUMN public.tb_entregas_sazonais.id_entrega_sazonal
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_entregas_sazonais.id_negociacao_rodada
    IS 'Rodada em que houve a negociação dos meses de entrega.';

COMMENT ON COLUMN public.tb_entregas_sazonais.valor_mes
    IS 'Valor negociado para aquele mês.';
	
COMMENT ON CONSTRAINT pk_entregas_sazonais ON public.tb_entregas_sazonais
    IS 'Chave primária da tabela tb_entregas_sazonais.';

COMMENT ON CONSTRAINT fk_entregas_sazonais_negociacao_rodada ON public.tb_entregas_sazonais
    IS 'Rodada em que os meses de entrega foram negociados.';