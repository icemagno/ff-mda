
ALTER TABLE IF EXISTS public.tb_locais
    ALTER COLUMN ds_local DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_locais
    ALTER COLUMN id_endereco DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_locais
    ADD COLUMN nm_local character varying(50) NOT NULL;

COMMENT ON COLUMN public.tb_locais.nm_local
    IS 'Nome do local.';
