ALTER TABLE public.tb_logisticas
    ALTER COLUMN tipo_transporte TYPE character varying(50);

COMMENT ON COLUMN public.tb_logisticas.tipo_transporte
    IS 'GNL, GNC, transporte, distribuição, outros (campo livre).';