ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN dt_inicio_entrega timestamp without time zone NOT NULL;

COMMENT ON COLUMN public.tb_compras.dt_inicio_entrega
    IS 'Data de início da entrega do produto.';

ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN dt_fim_entrega timestamp without time zone NOT NULL;

COMMENT ON COLUMN public.tb_compras.dt_fim_entrega
    IS 'Data de fim da entrega do produto.';