
ALTER TABLE IF EXISTS public.tb_perfis
    ALTER COLUMN ativo SET NOT NULL;
