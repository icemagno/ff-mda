-- Table: public.tb_negociacao_itens

-- DROP TABLE IF EXISTS public.tb_negociacao_itens;

CREATE TABLE IF NOT EXISTS public.tb_negociacao_itens
(
    id_negociacao_item smallserial NOT NULL,
    ds_negociacao_item character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_negociacao_itens PRIMARY KEY (id_negociacao_item)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_negociacao_itens
    OWNER to postgres;

COMMENT ON TABLE public.tb_negociacao_itens
    IS 'Ítens de negociação de uma compra.';

COMMENT ON COLUMN public.tb_negociacao_itens.id_negociacao_item
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_negociacao_itens.ds_negociacao_item
    IS 'Descrição do item de negociação.';
	
COMMENT ON CONSTRAINT pk_negociacao_itens ON public.tb_negociacao_itens
    IS 'Chave primária da tabela tb_negociacao_itens.';