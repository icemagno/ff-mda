-- Table: public.tb_certificados

-- DROP TABLE IF EXISTS public.tb_certificados;

CREATE TABLE IF NOT EXISTS public.tb_certificados
(
    id_certificado serial NOT NULL,
    id_empresa integer NOT NULL,
	quantidade smallint NOT NULL,
	equivalencia smallint NOT NULL,
    id_empresa_certificadora integer NOT NULL,
    CONSTRAINT pk_certificados PRIMARY KEY (id_certificado),
    CONSTRAINT fk_certificados_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_certificados_empresa_certificadora FOREIGN KEY (id_empresa_certificadora)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_certificados
    OWNER to postgres;

COMMENT ON TABLE public.tb_certificados
    IS 'Certificados de energia renovável.';

COMMENT ON COLUMN public.tb_certificados.id_certificado
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_certificados.id_empresa
    IS 'Empresa proprietária dos certificados.';

COMMENT ON COLUMN public.tb_certificados.quantidade
    IS 'Quantidade de certificados possuídos pela empresa.';

COMMENT ON COLUMN public.tb_certificados.equivalencia
    IS 'Quantidade de metros cúbicos de biometano a que equivale um certificado.';

COMMENT ON COLUMN public.tb_certificados.id_empresa_certificadora
    IS 'Empresa emissora dos certificados.';
	
COMMENT ON CONSTRAINT pk_certificados ON public.tb_certificados
    IS 'Chave primária da tabela tb_certificados.';

COMMENT ON CONSTRAINT fk_certificados_empresa ON public.tb_certificados
    IS 'Chave estrangeira da coluna id_empresa.';
	
COMMENT ON CONSTRAINT fk_certificados_empresa_certificadora ON public.tb_certificados
    IS 'Chave estrangeira do campo id_empresa_certificadora.';