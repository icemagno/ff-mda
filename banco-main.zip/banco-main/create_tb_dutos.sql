CREATE TABLE public.tb_dutos
(
    id_duto serial NOT NULL,
    nome_duto character varying(100) NOT NULL,
    diametro_duto numeric,
    the_geom geometry,
    CONSTRAINT pk_dutos PRIMARY KEY (id_duto)
);

ALTER TABLE IF EXISTS public.tb_dutos
    OWNER to postgres;

COMMENT ON TABLE public.tb_dutos
    IS 'Dutos de transporte.';

COMMENT ON COLUMN public.tb_dutos.id_duto
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_dutos.nome_duto
    IS 'Nome do duto.';

COMMENT ON COLUMN public.tb_dutos.diametro_duto
    IS 'Diâmetro (em m) do duto.';

COMMENT ON COLUMN public.tb_dutos.the_geom
    IS 'Dado georreferenciado: localização do duto.';
	
COMMENT ON CONSTRAINT pk_dutos ON public.tb_dutos
    IS 'Chave primária da tabela tb_dutos.';