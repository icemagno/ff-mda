ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    ADD COLUMN nr_rodada smallint NOT NULL;