	
ALTER TABLE IF EXISTS public.tb_empresa_representantes
    ALTER COLUMN ativo SET NOT NULL;
