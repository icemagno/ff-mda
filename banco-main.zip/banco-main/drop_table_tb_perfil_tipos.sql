DROP TABLE public.tb_perfil_tipos;
