-- Table: public.tb_logistica_coletas

-- DROP TABLE IF EXISTS public.tb_logistica_coletas;

CREATE TABLE IF NOT EXISTS public.tb_logistica_coletas
(
    id_logistica_coleta serial NOT NULL,
    entrada character varying(3) NOT NULL,
    id_endereco integer NOT NULL,
    id_logistica integer NOT NULL,
	id_empresa integer,
    CONSTRAINT pk_logistica_coletas PRIMARY KEY (id_logistica_coleta),
    CONSTRAINT fk_logistica_coletas_endereco FOREIGN KEY (id_endereco)
        REFERENCES public.tb_enderecos (id_endereco) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_logistica_coletas_logistica FOREIGN KEY (id_logistica)
        REFERENCES public.tb_logisticas (id_logistica) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_logistica_coletas_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_logistica_coletas
    OWNER to postgres;

COMMENT ON TABLE public.tb_logistica_coletas
    IS 'Pontos de coleta.';

COMMENT ON COLUMN public.tb_logistica_coletas.id_logistica_coleta
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_logistica_coletas.entrada
    IS 'E = entrada, S = saída, E/S = entrada/saída.';

COMMENT ON COLUMN public.tb_logistica_coletas.id_endereco
    IS 'Endereço do ponto de coleta.';

COMMENT ON COLUMN public.tb_logistica_coletas.id_logistica
    IS 'Logística de transporte envolvendo o ponto de coleta.';

COMMENT ON COLUMN public.tb_logistica_coletas.id_empresa
    IS 'Empresa a que pertence o ponto de coleta.';
	
COMMENT ON CONSTRAINT pk_logistica_coletas ON public.tb_logistica_coletas
    IS 'Chave primária da tabela tb_logistica_coletas.';

COMMENT ON CONSTRAINT fk_logistica_coletas_endereco ON public.tb_logistica_coletas
    IS 'Chave estrangeira da coluna id_endereco.';
	
COMMENT ON CONSTRAINT fk_logistica_coletas_logistica ON public.tb_logistica_coletas
    IS 'Chave estrangeira da coluna id_logistica.';

COMMENT ON CONSTRAINT fk_logistica_coletas_empresa ON public.tb_logistica_coletas
    IS 'Chave estrangeira da coluna id_empresa.';