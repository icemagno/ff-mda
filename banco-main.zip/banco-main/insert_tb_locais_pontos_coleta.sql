insert into tb_locais(id_endereco,nm_local)
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Limeira'),'PE Limeira'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Valparaíso'),'PE Valparaíso'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Capão Bonito'),'ECOMP Capão Bonito'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Bragança Paulista'),'PE Bragança Paulista'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'São Carlos'),'ECOMP São Carlos'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Penápolis'),'ECOMP Penápolis'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Itapirapuã Paulista'),'ECOMP Itapirapuã Paulista'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Arapei'),'ECOMP Vale do Paraíba'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Paulínia'),'ECOMP Paulínia'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Taubaté'),'ECOMP Taubaté'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Araçoiaba da Serra'),'PE Araçoiaba da Serra'
union
select (select id_endereco from tb_enderecos where logradouro is null and cidade = 'Mirandópolis'),'ECOMP Mirandópolis'
