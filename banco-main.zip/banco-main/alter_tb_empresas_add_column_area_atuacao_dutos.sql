ALTER TABLE IF EXISTS public.tb_empresas
    RENAME area_atuacao TO area_atuacao_rodoviaria;

ALTER TABLE IF EXISTS public.tb_empresas
    ALTER COLUMN area_atuacao_rodoviaria DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_empresas
    ADD COLUMN area_atuacao_dutos geometry;