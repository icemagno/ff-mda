ALTER TABLE IF EXISTS public.tb_ofertas DROP COLUMN IF EXISTS atendida;

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN id_oferta_situacao smallint NOT NULL;

COMMENT ON COLUMN public.tb_ofertas.id_oferta_situacao
    IS 'Situação em que se encontra a oferta.';

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_situacao FOREIGN KEY (id_oferta_situacao)
    REFERENCES public.tb_oferta_situacoes (id_oferta_situacao) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_ofertas_situacao ON public.tb_ofertas
    IS 'Chave estrangeira da coluna id_oferta_situacao.';