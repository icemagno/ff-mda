insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (65,'RUA RIO PRETO','1550','QUADRA02                  LOTE  10B','PARQUE INDUSTRIAL FABRICIO VETORASSO MENDES','78746736','Rondonópolis','Mato Grosso','Brasil','(66) 92225683',null,'0101000020E610000030CD3B4ED1514BC0A2C763F7E48130C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (66,'RUA ORESTES MATANA','451',null,'DISTRITO INDUSTRIAL','76904515','Ji-Paraná','Rondônia','Brasil','(69) 34115000',null,'0101000020E6100000D7F97E6ABCF44EC05778EFB050CB25C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (67,'RUA ANTONIO JOAO BIANCHINI','1800',null,'MATO GRANDE','92323890','Canoas','Rio Grande do Sul','Brasil','(51) 21089014',null,'0101000020E6100000586DC5FEB29B49C080DD944C15EC3DC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (68,'VIA DE PENETRACAO IV','517','LOTE  01/02','CIA SUL','43700000','Simões Filho','Bahia','Brasil','(71) 31144200',null,'0101000020E610000088537424973743C0496D60CC5DAB29C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (69,'TRAVESSA INDUSTRIAL 01','555',null,'SETOR INDUSTRIAL','73803130','Formosa','Goiás','Brasil','(61) 36429800',null,'0101000020E610000038E8D9ACFAAC47C0AD249BABAD182FC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (70,'RUA N','1.844','QUADRAIND. 7              LOTE  80 AO 85','DISTRITO INTEGRAL INDUSTRIAL E COMERCIAL DE CUIABA','78098400','Cuiabá','Mato Grosso','Brasil','(65) 36672006',null,'0101000020E6100000906588635DFC4BC0988ACF2B65592FC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (71,'RUA LIDUGUERO PINTO DA SILVA (LOT C VERDEJANTES)','01',null,'SAO SIMAO','78145662','Várzea Grande','Mato Grosso','Brasil','(65) 96863206',null,'0101000020E610000091F6065F98144CC06C9C30EF38652FC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (72,'RODOVIA GO 164','SN','KM    354','RIBEIRAO DA MATA','76590000','São Miguel do Araguaia','Goiás','Brasil','(62) 33641702',null,'0101000020E6100000E7E2361AC01349C045417714AE872AC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (73,'RUA DAS ORQUIDEAS','250 S','QUADRA55','JARDIM PLANALTO','78415000','Nova Marilândia','Mato Grosso','Brasil','(65) 33521336',null,'0101000020E6100000389B559FAB7D4CC03609134850BC2CC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (74,'RODOVIA BR 285, KM 179,  UNIDADE 2','SN',null,'DISTRITO','95230000','Muitos Capões','Rio Grande do Sul','Brasil','(54) 33551101',null,'0101000020E610000058545227A0B149C0193BECA7C64B3CC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (75,'ESTRADA FRUTEIRA','S/N','LOTE  212A                LOTE  212B','PARQUE INDUSTRIAL','86990000','Marialva','Paraná','Brasil','(44) 31121000',null,'0101000020E6100000B0627FD93DE949C08EE1EDF44A7937C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (76,'RODOVIA BR-285','S/N','KM    294','PETROPOLIS','99050700','Passo Fundo','Rio Grande do Sul','Brasil','(54) 21037100',null,'0101000020E6100000481E166A4D334AC0E293B6DA8A3D3CC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (77,'RODOVIA BR 163','S/N','KM    602','SETOR INDUSTRIAL E','78450000','Nova Mutum','Mato Grosso','Brasil','(65) 33086900',null,'0101000020E6100000E0D022DBF9064CC03481A969DE912BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (78,' Rua Cruz e Souza','325','Parte Norte do Lote 7-b Gleba 7-b Pavilhao 01','Jardim Rui Barbosa','78750490','Rondonópolis','Mato Grosso','Brasil','(66) 34210896',null,'0101000020E61000008038D6C56D544BC0987D9BEFA77630C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (79,'RUA RS 342','S/N','KM 122,3','INEXISTENTE','98700000','Ijuí','Rio Grande do Sul','Brasil','(51) 32114899',null,'0101000020E610000088ED7C3F352E4BC001DAAE9DEF873BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (80,'AVENIDA ELIEZER OLIVEIRA GUIMARAES','S/N','MODULO 10','DISTRITO AGROINDUSTRIAL','75890000','São Simão','Goiás','Brasil','(64) 34040916',null,'0101000020E610000047499D80264249C0A04696BB961033C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (81,'AVENIDA CRISTIANO JOSE DE SOUZA','S/N','QUADRA 01','SETOR JOSE MACHADO','75780000','Ipameri','Goiás','Brasil','(64) 34040200',null,'0101000020E610000060666666661648C079C994FF90BE31C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (82,'RUA AYRTON SENNA','628','DISTRITO INDUSTRIAL','NOVA PRATA','78890000','Sorriso','Mato Grosso','Brasil','(64) 34040916',null,'0101000020E610000059BA490C02DB4BC0DE326D3D0A1729C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (83,'RUA EGIDIO TOME','5700',null,'PARQUE INDUSTRIAL','79610090','Três Lagoas','Mato Grosso do Sul','Brasil','(67) 35628101',null,'0101000020E6100000871F63EE5AD249C06628AAFA5CCD34C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (84,' Rodovia Br-060','SN','Km 381','Setor Industrial','75905025','Rio Verde','Goiás','Brasil','(64) 30518523',null,'0101000020E6100000478D976E127349C0EA14AA8BDBC831C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (85,'AVENIDA PAULO ERLEI ALVES ABRANTES','2500','DISTRITO INDUSTRIAL DE TRES POCOS','TRES POCOS','27240560','Volta Redonda','Rio de Janeiro','Brasil','(24) 33501535',null,'0101000020E6100000E0FBA9F1D20546C0300E2DBB277F36C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (86,'ESTRADA OSWALDO DE MORAES CORREA','1000',null,'PARQUE INDUSTRIAL','87065590','Maringá','Paraná','Brasil','(44) 32213007',null,'0101000020E610000050F5B9DA8AFD49C0AFBF12FBCB6E37C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (87,'RODOVIA MT 225','S/N','KM 81,2','ZONA RURAL','78885000','Feliz Natal','Mato Grosso','Brasil','(66) 35852328',null,'0101000020E610000098CDAACFD5764BC01FBCF9F675C028C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (88,'RODOVIA BR 163 KM 328','S/N',null,'NAO POSSUI','79130000','Rio Brilhante','Mato Grosso do Sul','Brasil','(67) 34230729',null,'0101000020E6100000C8915CFE43424BC0049FDB718ABE35C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (89,'RUA Z','450',null,'DISTRITO INDUSTRIAL','78098530','Cuiabá','Mato Grosso','Brasil','(11) 38976569',null,'0101000020E6100000C866D5E76AFB4BC00BD9A0BDC1572FC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (90,'RODOVIA MT 449','SN','KM 5, ZONA URBANA','DISTRITO INDUSTRIAL SENADOR ATILIO FONTANA','78455000','Lucas do Rio Verde','Mato Grosso','Brasil','(65) 39257800',null,'0101000020E610000058643BDF4FF54BC014397C48BF1D2AC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (91,'RODOVIA ERS 132 - KM 7,5','360',null,'POVOADO BAIXO','99165000','Camargo','Rio Grande do Sul','Brasil','(51) 33423277',null,'0101000020E6100000488D976E12FB49C0454293900F7A3DC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (92,'VIELA VP 1E','S/N','QUADRA: 03 : MODULOS 3-4-5-6; : DAIA;','DISTRITO AGROINDUSTRIAL DE ANAPOLIS','75132040','Anápolis','Goiás','Brasil','(14) 34043200',null,'0101000020E61000003080B740827A48C088B25FA1D66430C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (93,'AVENIDA PRINCIPAL','S/N','QUADRA03 E 05','SETOR PARQUE INDUSTRIAL','77500000','Porto Nacional','Tocantins','Brasil','(14) 34043200',null,'0101000020E6100000D02B6519E27048C0C1A2802F4C8624C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (94,'ESTRADA VOLTA DA CHARQUEADA','S/N',null,'CHARQUEADA','96505830','Cachoeira do Sul','Rio Grande do Sul','Brasil','() ',null,'0101000020E6100000E8F44A5986184AC02EFA7BD93D993CC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (95,'RUA JOAO PAULO RODRIGUES','360',null,'NOSSA SENHORA DA GUIA','64807250','Floriano','Piauí','Brasil','(65) 99867655',null,'0101000020E6100000303CBD52968145C0771D1348503C1BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (96,'RUA 3','454','QUADRAAREA                LOTE  AR-A','DISTRITO AGROINDUSTRIAL','75801879','Jataí','Goiás','Brasil','(64) 34301345',null,'0101000020E6100000E8C9C342ADD949C0964D89DB68E031C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (97,'RODOVIA MT 140','S/N','SAIDA PARA                NOVA BRASILANDIA','DISTRITO INDUSTRIAL III','78840000','Campo Verde','Mato Grosso','Brasil','(11) 31444000',null,'0101000020E6100000E11DA7E848964BC083E84CDA1B1C2FC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (98,'RODOVIA BR 153, KM 179','S/N','BLOCO I','ZONA RURAL','16400033','Lins','São Paulo','Brasil','(11) 31444000',null,'0101000020E6100000682BF697DD7B48C06FEADCBE0E1C35C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (99,'RODOVIA GO 050, KM 41 - ESTRADA DA CHACARA','S/N',null,'ZONA RURAL','76190000','Palmeiras de Goiás','Goiás','Brasil','(17) 33213355',null,'0101000020E6100000400C022B87F648C0C208DF7A14CE30C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (100,' Rodovia br 122','S/N','Km 32','Zona Industrial','46980000','Iraquara','Bahia','Brasil','(51) 33295555',null,'0101000020E6100000D181734694CE44C00DE5C2DCB56428C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (101,'RODOVIA BR 364','S/N','KM    250','ZONA RURAL','76960970','Cacoal','Rondônia','Brasil','(51) 33295555',null,'0101000020E6100000A079C7293ABA4EC09A212BFF21DD26C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (102,'RODOVIA BR 470','3482','KM    109','VALVERDE','95330000','Veranópolis','Rio Grande do Sul','Brasil','(51) 30271700',null,'0101000020E6100000B0847CD0B3714AC0A4786B8104453EC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (103,'RODOVIA BR 153, KM 65, S/Nº, TRECHO PORANGATU/AZINOPOLIS','SN','KM    65','RURAL','76550000','Porangatu','Goiás','Brasil','(54) 21062600',null,'0101000020E6100000A803E78C28254AC0494EDCBE0EAC3BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (104,'RODOVIA BR-153','S/N','KM    53 FUNDOS','FRINAPE','99709780','Erechim','Rio Grande do Sul','Brasil','(54) 21062600',null,'0101000020E6100000C85D4BC807C549C023348F3A01ED3CC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (62,'AVENIDA SENADOR ATTILIO FONTANA','1001','SALA 02','DISTRITO INDUSTRIAL','78745800','Rondonópolis','Mato Grosso','Brasil','(066) 4112800',null,'0101000020E6100000809ECDAACF554BC0610590CB7F7830C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (63,'AVENIDA SANTA TEREZINHA','2.049',null,'MENINO DEUS','89600000','Joaçaba','Santa Catarina','Brasil','(11) 51853500',null,'0101000020E610000040B6F3FDD4C049C0DC213180B7303BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (64,'RODOVIA CE 123 KM 40','S/N','FAZENDA LAGOA VERMELHA','LAGOA DA SALSA KM 16','62823000','Jaguaruana','Ceará','Brasil','(85) 32168888',null,'0101000020E610000058B1BFEC9EE442C0A9599D89B0E113C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (105,'AVENIDA DOM PEDRO II','4040','AREA B1','VILLAGE PORTO REAL','27570000','Porto Real','Rio de Janeiro','Brasil','(54) 21062600',null,'0101000020E6100000E863CC5D4B2846C0B1799CABAD6836C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (106,'RODOVIA BA 522','S/N','KM    11 - PARTE                ZONA RURAL DO             MUNICIPIO DE              CANDEIAS','JABEQUERA DAS FLORES','43813300','Candeias','Bahia','Brasil','(71) 33483875',null,'0101000020E6100000F0285C8FC24543C044F4747AA54C29C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (107,'AVENIDA DAS INDUSTRIAS','S/N','QUADRA: 2 LOTE: 8, 9 E 10;','INDUSTRIAL','39410000','Montes Claros','Minas Gerais','Brasil','(21) 32243022',null,'0101000020E6100000F84C840D4FEF45C0CA8DE33FA4AF30C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (108,'AVENIDA EDUARDO PEDRO HAMMERSCHMIDT','3800','SETOR PARQUE INDUSTRIAL','SAMPAIO-LARA','83750000','Lapa','Paraná','Brasil','(41) 31633000',null,'0101000020E61000006066666666DE48C011F41BF46CC639C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (109,'RUA MARIANO JATAHY MARCONDES FERRAZ','115',null,'LOTEAMENTO TEREZA BUCHIANERI BIANCALANA','13170017','Sumaré','São Paulo','Brasil','(47) 30863465',null,'0101000020E61000000971AC8BDBF047C0204C3870CEB834C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (110,'AVENIDA DO CAFE','129',null,'NAO INFORMADO','14620000','Orlândia','São Paulo','Brasil','(16) 38205000',null,'0101000020E610000010D044D8F0E448C08D2861CC5DAB35C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (111,'RUA COMERCIANTE LAURO GUILHERME GUTHS','S/N',null,'AREA RURAL DE MAFRA','89309899','Mafra','Santa Catarina','Brasil','(11) 31445600',null,'0101000020E610000031B4C876BEE748C0373628F6971D3AC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (112,'RODOVIA BR 163, KM 660','SN','MAIS 66 KM ESQUERDA','ZONA RURAL','78450000','Nova Mutum','Mato Grosso','Brasil','(65) 33084255',null,'0101000020E610000078AEB6627F494CC0D5A0F6EDEBA02AC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (113,'RODOVIA BR 285, KM 461,5 - FUNDOS','S/N',null,'ZONA RURAL','98700000','Ijuí','Rio Grande do Sul','Brasil','(55) 33723700',null,'0101000020E61000007FEB51B81E254AC0A87E066822AC3BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (114,'RODOVIA PA 242, KM 1,4','S/N',null,'ZONA RUAL','68786000','Santo Antônio do Tauá','Pará','Brasil','(65) 99867655',null,'0101000020E6100000693D0AD7A31048C0427008B5A679F2BF');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (115,'RODOVIA MT 246','SN','KM 3 5','ZONA RURAL','78390000','Barra do Bugres','Mato Grosso','Brasil','() ',null,'0101000020E6100000D8240681959B4CC0C939E60434112EC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (116,'RUA RIO PRETO','1550','QUADRA02                  LOTE  10B','PARQUE INDUSTRIAL FABRICIO VETORASSO MENDES','78746736','Rondonópolis','Mato Grosso','Brasil','(66) 92225683',null,'0101000020E610000030CD3B4ED1514BC0A2C763F7E48130C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (117,'RUA ORESTES MATANA','451',null,'DISTRITO INDUSTRIAL','76904515','Ji-Paraná','Rondônia','Brasil','(69) 34115000',null,'0101000020E6100000D7F97E6ABCF44EC05778EFB050CB25C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (118,'TRAVESSA INDUSTRIAL 01','555',null,'SETOR INDUSTRIAL','73803130','Formosa','Goiás','Brasil','(61) 36429800',null,'0101000020E610000038E8D9ACFAAC47C0AD249BABAD182FC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (119,'ESTRADA FRUTEIRA','S/N','LOTE  212A                LOTE  212B','PARQUE INDUSTRIAL','86990000','Marialva','Paraná','Brasil','(44) 31121000',null,'0101000020E6100000B0627FD93DE949C08EE1EDF44A7937C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (120,'RODOVIA BR-285','S/N','KM    294','PETROPOLIS','99050700','Passo Fundo','Rio Grande do Sul','Brasil','(54) 21037100',null,'0101000020E6100000481E166A4D334AC0E293B6DA8A3D3CC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (121,'RODOVIA BR 153, KM 179','S/N','BLOCO I','ZONA RURAL','16400033','Lins','São Paulo','Brasil','(11) 31444000',null,'0101000020E6100000682BF697DD7B48C06FEADCBE0E1C35C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (122,'AVENIDA DOM PEDRO II','4040','AREA B1','VILLAGE PORTO REAL','27570000','Porto Real','Rio de Janeiro','Brasil','(54) 21062600',null,'0101000020E6100000E863CC5D4B2846C0B1799CABAD6836C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (123,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (124,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (125,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (126,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (127,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (137,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (138,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (152,'ESTRADA DO PAU FERRO','S/N','SITIO PAU FERRO','ALECRIM','28940090','São Pedro da Aldeia','Rio de Janeiro','Brasil','(21) 21287214',null,'0101000020E6100000085839B4C80645C0F07E6ABC74D336C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (153,'RUA 98','S/N','QUADRA','TOCO (JUREMA)','61663595','Caucaia','Ceará','Brasil','(21) 31775854',null,'0101000020E6100000F0FDD478E95643C0008FC2F5285C0EC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (154,'AVENIDA SAPOPEMBA','22.254','SETOR EQB','JARDIM ADUTORA','03989010','São Paulo','São Paulo','Brasil','(11) 99999904',null,'0101000020E6100000981A2FDD243647C0E0D022DBF99E37C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (155,'RODOVIA DO ACUCAR SP308','S/N','KM    117','FUNIL','13350000','Elias Fausto','São Paulo','Brasil','(19) 38713080',null,'0101000020E6100000F07E6ABC74B347C0A09BC420B01237C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (156,'VIA DE ACESSO NORTE KM 33','S/N',null,'CALCAREA','07721000','Caieiras','São Paulo','Brasil','(11) 31243500',null,'0101000020E6100000F8A9F1D24D6247C0400C022B875637C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (157,'RODOVIA PR 559','KM 05',null,'JURANDA','87760000','Tamboara','Paraná','Brasil','(43) 33021700',null,'0101000020E6100000E0D022DBF93E4AC090703D0AD74337C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (150,'ESTRADA MUNICIPAL NRD','267','EDIF  B','FAZENDA MOSQUITO','19220000','Narandiba','São Paulo','Brasil','(18) 33612888',null,'0101000020E610000030894160E5C049C040E17A14AE8736C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (151,'ESTRADA MUNICIPAL OLAVO VIEIRA VILELA','S/N','FAZENDA SAO JOAO          KM 4                SALA  1','DO CAPIVARI E VARADOURO','12270000','Jambeiro','São Paulo','Brasil','(19) 34041600',null,'0101000020E610000030B4C876BEDF46C0E0FDD478E94637C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (158,'RUA SANTA LUZIA','100','SALA  618','TRINDADE','88036540','Florianópolis','Santa Catarina','Brasil','(48) 91815020',null,'0101000020E6100000085839B4C87649C030355EBA49CC31C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (159,'RODOVIA SP-308, HERMINIO PETRIM','S/N','KM    177                 ANEXO SETOR B','SANTA TEREZINHA','13411900','Piracicaba','São Paulo','Brasil','(19) 34238000',null,'0101000020E6100000603BDF4F8DD747C0408D976E12A336C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (160,'RODOVIA BR 470','KM 301',null,'INTERIOR','89620000','Campos Novos','Santa Catarina','Brasil','(48) 91815020',null,'0101000020E6100000C8CCCCCCCC9C49C0E0FDD478E9663BC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (161,'RODOVIA MUNICIPAL TF 310 - CORREDOR DE ACESSO','2090',null,'RINCAO DOS PINHEIROS','95840000','Triunfo','Rio Grande do Sul','Brasil','(51) 32726600',null,'0101000020E6100000380AD7A3709D49C090C420B072083EC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (162,'RODOVIA GO 410, KM 51 À ESQUERDA','S/N','SALA  01','ZONA RURAL','75940000','Edéia','Goiás','Brasil','(64) 34336371',null,'0101000020E61000001885EB51B80E49C080C2F5285CAF31C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (163,'FAZENDA GUANABARA','S/N',null,'ZONA RURAL','78370000','Nova Olímpia','Mato Grosso','Brasil','(65) 33323451',null,'0101000020E610000060105839B4984CC0E0A7C64B37892DC0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (164,'AVENIDA NOSSA SENHORA APARECIDA','3858',null,'SANTA TEREZINHA','83829308','Fazenda Rio Grande','Paraná','Brasil','(19) 99382881',null,'0101000020E610000000AC1C5A64AB48C0703F355EBAA939C0');
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (165,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (166,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (167,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (168,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (169,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (170,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (172,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (180,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (192,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (198,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (199,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
insert into public.tb_enderecos(id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom)
	values (200,'Endereco Teste','1234','1234',' JPA','22444777','Rio de Janeiro','Rio de Janeiro','Brasil','2199999999','2199999999',null);
