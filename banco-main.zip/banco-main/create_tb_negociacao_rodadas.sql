-- Table: public.tb_negociacao_rodadas

-- DROP TABLE IF EXISTS public.tb_negociacao_rodadas;

CREATE TABLE IF NOT EXISTS public.tb_negociacao_rodadas
(
    id_negociacao_rodada serial NOT NULL,
    id_compra integer NOT NULL,
    id_negociacao_item smallint NOT NULL,
    valor_proposto character varying(50) COLLATE pg_catalog."default" NOT NULL,
    dh_rodada timestamp without time zone NOT NULL,
    id_empresa_proponente integer NOT NULL,
    id_negociacao_rodada_anterior integer NOT NULL,
    observacao character varying(500) COLLATE pg_catalog."default",
    CONSTRAINT pk_negociacao_rodadas PRIMARY KEY (id_negociacao_rodada),
    CONSTRAINT fk_negociacao_rodadas_compra FOREIGN KEY (id_compra)
        REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_negociacao_rodadas_empresa_proponente FOREIGN KEY (id_empresa_proponente)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_negociacao_rodadas_negociacao_anterior FOREIGN KEY (id_negociacao_rodada_anterior)
        REFERENCES public.tb_negociacao_rodadas (id_negociacao_rodada) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_negociacao_rodadas_negociacao_item FOREIGN KEY (id_negociacao_item)
        REFERENCES public.tb_negociacao_itens (id_negociacao_item) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    OWNER to postgres;

COMMENT ON TABLE public.tb_negociacao_rodadas
    IS 'Rodadas de negociação de uma compra.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_negociacao_rodada
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_compra
    IS 'Compra sendo negociada.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_negociacao_item
    IS 'Item sendo negociado.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.valor_proposto
    IS 'Valor proposto do item.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.dh_rodada
    IS 'Data/hora da rodada de negociação.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_empresa_proponente
    IS 'Empresa que fez a proposta do item.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_negociacao_rodada_anterior
    IS 'Proposta a que se está respondendo.';

COMMENT ON COLUMN public.tb_negociacao_rodadas.observacao
    IS 'Campo livre para observações acerca da negociação.';

COMMENT ON CONSTRAINT fk_negociacao_rodadas_compra ON public.tb_negociacao_rodadas
    IS 'Chave estrangeira da coluna id_compra.';
COMMENT ON CONSTRAINT fk_negociacao_rodadas_empresa_proponente ON public.tb_negociacao_rodadas
    IS 'Chave estrangeira da coluna id_empresa_proponente.';
COMMENT ON CONSTRAINT fk_negociacao_rodadas_negociacao_anterior ON public.tb_negociacao_rodadas
    IS 'Chave estrangeira da coluna id_negociacao_rodada_anterior.';
COMMENT ON CONSTRAINT fk_negociacao_rodadas_negociacao_item ON public.tb_negociacao_rodadas
    IS 'Chave estrangeira da coluna id_negociacao_item.';
