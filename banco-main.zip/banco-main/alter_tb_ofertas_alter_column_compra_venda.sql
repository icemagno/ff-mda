ALTER TABLE public.tb_ofertas
    ALTER COLUMN compra_venda TYPE character(1);
	
COMMENT ON COLUMN public.tb_ofertas.compra_venda
    IS 'Compra ou venda: compra = ''C'', venda = ''V''.';