insert into public.tb_oferta_situacoes(id_oferta_situacao,ds_oferta_situacao) values (1,'OS_INICIADA');
insert into public.tb_oferta_situacoes(id_oferta_situacao,ds_oferta_situacao) values (2,'OS_FINALIZADA');
insert into public.tb_oferta_situacoes(id_oferta_situacao,ds_oferta_situacao) values (3,'OS_EM_ANDAMENTO');
insert into public.tb_oferta_situacoes(id_oferta_situacao,ds_oferta_situacao) values (4,'OS_CANCELADA');
