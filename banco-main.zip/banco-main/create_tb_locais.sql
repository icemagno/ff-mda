-- Table: public.tb_locais

-- DROP TABLE IF EXISTS public.tb_locais;

CREATE TABLE IF NOT EXISTS public.tb_locais
(
    id_local smallserial NOT NULL,
    ds_local character varying(100) COLLATE pg_catalog."default" NOT NULL,
    id_endereco integer NOT NULL,
    CONSTRAINT pk_local PRIMARY KEY (id_local),
    CONSTRAINT fk_locais_endereco FOREIGN KEY (id_endereco)
        REFERENCES public.tb_enderecos (id_endereco) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_locais
    OWNER to postgres;

COMMENT ON TABLE public.tb_locais
    IS 'Locais de entrega ou retirada de compras.';

COMMENT ON COLUMN public.tb_locais.id_local
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_locais.ds_local
    IS 'Descrição do local.';
	
COMMENT ON CONSTRAINT pk_local ON public.tb_locais
    IS 'Chave primária da tabela tb_locais.';

COMMENT ON CONSTRAINT fk_locais_endereco ON public.tb_locais
    IS 'Chave estrangeira da coluna id_endereco.';