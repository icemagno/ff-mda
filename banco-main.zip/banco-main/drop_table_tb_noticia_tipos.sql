DROP TABLE public.tb_noticia_tipos;
