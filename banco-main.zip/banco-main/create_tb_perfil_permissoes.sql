-- Table: public.tb_perfil_permissoes

-- DROP TABLE IF EXISTS public.tb_perfil_permissoes;

CREATE TABLE IF NOT EXISTS public.tb_perfil_permissoes
(
    id_perfil_permissao serial NOT NULL,
    id_perfil smallint NOT NULL,
    id_permissao smallint NOT NULL,
    CONSTRAINT pk_perfil_permissoes PRIMARY KEY (id_perfil_permissao),
    CONSTRAINT uk_perfil_permissoes_perfil_permissao UNIQUE (id_perfil, id_permissao),
    CONSTRAINT fk_perfil_permissoes_perfil FOREIGN KEY (id_perfil)
        REFERENCES public.tb_perfis (id_perfil) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_perfil_permissoes_permissao FOREIGN KEY (id_permissao)
        REFERENCES public.tb_permissoes (id_permissao) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_perfil_permissoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_perfil_permissoes
    IS 'Permissões atribuídas a um perfil.';

COMMENT ON COLUMN public.tb_perfil_permissoes.id_perfil_permissao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_perfil_permissoes.id_perfil
    IS 'Perfil a que é atribuída uma permissão.';

COMMENT ON COLUMN public.tb_perfil_permissoes.id_permissao
    IS 'Permissão sendo atribuída a um perfil.';
COMMENT ON CONSTRAINT pk_perfil_permissoes ON public.tb_perfil_permissoes
    IS 'Chave primária da tabela tb_perfil_permissoes.';

COMMENT ON CONSTRAINT uk_perfil_permissoes_perfil_permissao ON public.tb_perfil_permissoes
    IS 'Unique constraint nas colunas id_perfil/id_permissao';

COMMENT ON CONSTRAINT fk_perfil_permissoes_perfil ON public.tb_perfil_permissoes
    IS 'Chave estrangeira da coluna id_perfil.';
	
COMMENT ON CONSTRAINT fk_perfil_permissoes_permissao ON public.tb_perfil_permissoes
    IS 'Chave estrangeira da coluna id_permissao.';