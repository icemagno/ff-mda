ALTER TABLE IF EXISTS public.tb_negociacao_itens DROP COLUMN IF EXISTS tipo_valor;

ALTER TABLE IF EXISTS public.tb_negociacao_itens DROP COLUMN IF EXISTS componente;