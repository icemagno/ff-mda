-- Table: public.tb_certificados

-- DROP TABLE IF EXISTS public.tb_certificados;

CREATE TABLE IF NOT EXISTS public.tb_certificados
(
    id_certificado serial NOT NULL,
    dt_certificado timestamp without time zone NOT NULL,
    dt_validade timestamp without time zone,
    id_empresa_certificada integer NOT NULL,
    id_empresa_certificadora integer NOT NULL,
    CONSTRAINT pk_certificados PRIMARY KEY (id_certificado),
    CONSTRAINT fk_certificados_empresa_certificada FOREIGN KEY (id_empresa_certificada)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_certificados_empresa_certificadora FOREIGN KEY (id_empresa_certificadora)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_certificados
    OWNER to postgres;

COMMENT ON TABLE public.tb_certificados
    IS 'Certificação de empresas.';

COMMENT ON COLUMN public.tb_certificados.id_certificado
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_certificados.dt_certificado
    IS 'Data do certificado.';

COMMENT ON COLUMN public.tb_certificados.dt_validade
    IS 'Data de validade do certificado.';

COMMENT ON COLUMN public.tb_certificados.id_empresa_certificada
    IS 'Empresa certificada.';

COMMENT ON COLUMN public.tb_certificados.id_empresa_certificadora
    IS 'Empresa certificadora.';
COMMENT ON CONSTRAINT pk_certificados ON public.tb_certificados
    IS 'Chave primária da tabela tb_certificados.';

COMMENT ON CONSTRAINT fk_certificados_empresa_certificada ON public.tb_certificados
    IS 'Chave estrangeira da coluna id_empresa_certificada.';
COMMENT ON CONSTRAINT fk_certificados_empresa_certificadora ON public.tb_certificados
    IS 'Chave estrangeira da coluna id_empresa_certificadora.';
