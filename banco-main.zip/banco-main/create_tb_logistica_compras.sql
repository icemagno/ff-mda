-- Table: public.tb_logistica_compras

-- DROP TABLE IF EXISTS public.tb_logistica_compras;

CREATE TABLE IF NOT EXISTS public.tb_logistica_compras
(
    id_logistica_compra serial NOT NULL,
    id_compra integer NOT NULL,
    id_logistica integer NOT NULL,
    valor_logistica numeric NOT NULL,
    CONSTRAINT pk_compra_logisticas PRIMARY KEY (id_logistica_compra),
    CONSTRAINT fk_logistica_compras_compra FOREIGN KEY (id_compra)
        REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_logistica_compras_logistica FOREIGN KEY (id_logistica)
        REFERENCES public.tb_logisticas (id_logistica) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_logistica_compras
    OWNER to postgres;

COMMENT ON TABLE public.tb_logistica_compras
    IS 'Logísticas de uma compra.';

COMMENT ON COLUMN public.tb_logistica_compras.id_logistica_compra
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_logistica_compras.id_compra
    IS 'Compra de biometano.';

COMMENT ON COLUMN public.tb_logistica_compras.id_logistica
    IS 'Logística da compra.';

COMMENT ON COLUMN public.tb_logistica_compras.valor_logistica
    IS 'Valor da logística da compra.';
COMMENT ON CONSTRAINT pk_compra_logisticas ON public.tb_logistica_compras
    IS 'Chave primária da tabela tb_compra_logisticas.';

COMMENT ON CONSTRAINT fk_logistica_compras_compra ON public.tb_logistica_compras
    IS 'Chave estrangeira da coluna id_compra.';
COMMENT ON CONSTRAINT fk_logistica_compras_logistica ON public.tb_logistica_compras
    IS 'Chave estrangeira da coluna id_logistica.';