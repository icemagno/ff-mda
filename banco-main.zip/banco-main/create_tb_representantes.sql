-- Table: public.tb_representantes

-- DROP TABLE IF EXISTS public.tb_representantes;

CREATE TABLE IF NOT EXISTS public.tb_representantes
(
    id_representante serial NOT NULL,
    cpf character varying(9) COLLATE pg_catalog."default",
    nome character varying(50) COLLATE pg_catalog."default",
    id_endereco integer,
    CONSTRAINT pk_representantes PRIMARY KEY (id_representante),
    CONSTRAINT fk_representantes_endereco FOREIGN KEY (id_endereco)
        REFERENCES public.tb_enderecos (id_endereco) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_representantes
    OWNER to postgres;

COMMENT ON TABLE public.tb_representantes
    IS 'Representantes.';

COMMENT ON COLUMN public.tb_representantes.id_representante
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_representantes.cpf
    IS 'Cadastro de Pessoa Física.';

COMMENT ON COLUMN public.tb_representantes.nome
    IS 'Nome.';

COMMENT ON COLUMN public.tb_representantes.id_endereco
    IS 'Endereço.';
	
COMMENT ON CONSTRAINT pk_representantes ON public.tb_representantes
    IS 'Chave primária da tabela tb_representantes.';
	
COMMENT ON CONSTRAINT fk_representantes_endereco ON public.tb_representantes
    IS 'Chave estrangeira da coluna id_endereco.';