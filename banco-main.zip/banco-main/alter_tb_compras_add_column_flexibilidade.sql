ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN flexibilidade boolean NOT NULL;

COMMENT ON COLUMN public.tb_compras.flexibilidade
    IS 'Flag para flexibilidade: true = flexível; false = firme.';