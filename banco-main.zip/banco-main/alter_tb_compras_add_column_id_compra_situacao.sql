ALTER TABLE IF EXISTS public.tb_compras DROP COLUMN IF EXISTS entrega_concluida;

ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN id_compra_situacao smallint NOT NULL;

COMMENT ON COLUMN public.tb_compras.id_compra_situacao
    IS 'Situação em que se encontra a compra.';

ALTER TABLE IF EXISTS public.tb_compras
    ADD CONSTRAINT fk_compras_situacao FOREIGN KEY (id_compra_situacao)
    REFERENCES public.tb_compra_situacoes (id_compra_situacao) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_compras_situacao ON public.tb_compras
    IS 'Chave estrangeira da coluna id_compra_situacao.';