ALTER TABLE IF EXISTS public.tb_negociacao_rodadas_nova
    RENAME TO tb_negociacao_rodadas;

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    RENAME id_negociacao_rodada_nova TO id_negociacao_rodada;