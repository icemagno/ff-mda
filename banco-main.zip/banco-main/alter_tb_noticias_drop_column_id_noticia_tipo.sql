ALTER TABLE public.tb_noticias
    DROP COLUMN id_noticia_tipo CASCADE;
