
ALTER TABLE IF EXISTS public.tb_negociacao_propostas DROP CONSTRAINT IF EXISTS fk_negociacao_propostas_empresa_proponente;

ALTER TABLE IF EXISTS public.tb_negociacao_propostas DROP CONSTRAINT IF EXISTS fk_negociacao_propostas_proposta_anterior;

ALTER TABLE IF EXISTS public.tb_negociacao_propostas DROP COLUMN IF EXISTS id_empresa_proponente;

ALTER TABLE IF EXISTS public.tb_negociacao_propostas DROP COLUMN IF EXISTS id_negociacao_proposta_anterior;
