COMMENT ON COLUMN public.tb_entregas_sazonais.valor_mes
    IS 'Valor (metros cúbicos) negociado para aquele mês.';