COMMENT ON TABLE public.tb_compras
  IS 'Compras de biometano/certificados.';
  
COMMENT ON COLUMN public.tb_compras.valor_compra
    IS 'Valor (em moeda corrente) da compra do material.';

COMMENT ON COLUMN public.tb_compras.id_compra_aditivada
    IS 'Compra correspondente a um aditivo de contrato.';