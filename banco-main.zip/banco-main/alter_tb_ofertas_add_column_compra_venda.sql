COMMENT ON COLUMN public.tb_ofertas.id_oferta_tipo
    IS 'Tipo da oferta: só biometano, biometano+certificado, só certificado.';

ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN compra_venda boolean;

COMMENT ON COLUMN public.tb_ofertas.compra_venda
    IS 'Compra ou venda: compra = true, venda = false.';
	
COMMENT ON TABLE public.tb_oferta_tipos
  IS 'Tipos possíveis de uma oferta: só biometano, biometano+certificados, só certificados.';