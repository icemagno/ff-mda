
CREATE DATABASE cometa
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Portuguese_Brazil.1252'
    LC_CTYPE = 'Portuguese_Brazil.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;
	
-- SCHEMA: public

-- DROP SCHEMA IF EXISTS public ;

CREATE SCHEMA IF NOT EXISTS public
    AUTHORIZATION postgres;

COMMENT ON SCHEMA public
    IS 'standard public schema';

GRANT ALL ON SCHEMA public TO PUBLIC;

GRANT ALL ON SCHEMA public TO postgres;

--
-- TOC entry 311 (class 1259 OID 22569)
-- Name: tb_autorizacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_autorizacoes (
    id_autorizacao integer NOT NULL,
    dt_autorizacao timestamp without time zone NOT NULL,
    dt_validade timestamp without time zone,
    id_empresa_autorizada integer NOT NULL
);


ALTER TABLE public.tb_autorizacoes OWNER TO postgres;

--
-- TOC entry 5348 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE tb_autorizacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_autorizacoes IS 'Autorização de empresas.';


--
-- TOC entry 5349 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN tb_autorizacoes.id_autorizacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_autorizacoes.id_autorizacao IS 'Identificador.';


--
-- TOC entry 5350 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN tb_autorizacoes.dt_autorizacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_autorizacoes.dt_autorizacao IS 'Data da autorização.';


--
-- TOC entry 5351 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN tb_autorizacoes.dt_validade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_autorizacoes.dt_validade IS 'Data de validade da autorização.';


--
-- TOC entry 5352 (class 0 OID 0)
-- Dependencies: 311
-- Name: COLUMN tb_autorizacoes.id_empresa_autorizada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_autorizacoes.id_empresa_autorizada IS 'Empresa autorizada.';


--
-- TOC entry 341 (class 1259 OID 69808)
-- Name: tb_certificados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_certificados (
    id_certificado integer NOT NULL,
    id_empresa integer NOT NULL,
    quantidade smallint NOT NULL,
    equivalencia smallint NOT NULL,
    id_empresa_certificadora integer NOT NULL,
    nm_certificado character varying(50) NOT NULL
);


ALTER TABLE public.tb_certificados OWNER TO postgres;

--
-- TOC entry 5353 (class 0 OID 0)
-- Dependencies: 341
-- Name: TABLE tb_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_certificados IS 'Certificados de energia renovável.';


--
-- TOC entry 5354 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN tb_certificados.id_certificado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_certificados.id_certificado IS 'Identificador.';


--
-- TOC entry 5355 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN tb_certificados.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_certificados.id_empresa IS 'Empresa proprietária dos certificados.';


--
-- TOC entry 5356 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN tb_certificados.quantidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_certificados.quantidade IS 'Quantidade de certificados possuídos pela empresa.';


--
-- TOC entry 5357 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN tb_certificados.equivalencia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_certificados.equivalencia IS 'Quantidade de metros cúbicos de biometano a que equivale um certificado.';


--
-- TOC entry 5358 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN tb_certificados.id_empresa_certificadora; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_certificados.id_empresa_certificadora IS 'Empresa emissora dos certificados.';


--
-- TOC entry 5359 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN tb_certificados.nm_certificado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_certificados.nm_certificado IS 'Nome do certificado.';


--
-- TOC entry 310 (class 1259 OID 22567)
-- Name: tb_certificados_id_certificado_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_certificados_id_certificado_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_certificados_id_certificado_seq OWNER TO postgres;

--
-- TOC entry 5360 (class 0 OID 0)
-- Dependencies: 310
-- Name: tb_certificados_id_certificado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_certificados_id_certificado_seq OWNED BY public.tb_autorizacoes.id_autorizacao;


--
-- TOC entry 340 (class 1259 OID 69806)
-- Name: tb_certificados_id_certificado_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_certificados_id_certificado_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_certificados_id_certificado_seq1 OWNER TO postgres;

--
-- TOC entry 5361 (class 0 OID 0)
-- Dependencies: 340
-- Name: tb_certificados_id_certificado_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_certificados_id_certificado_seq1 OWNED BY public.tb_certificados.id_certificado;


--
-- TOC entry 321 (class 1259 OID 36858)
-- Name: tb_compra_situacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_compra_situacoes (
    id_compra_situacao smallint NOT NULL,
    ds_compra_situacao character varying(100) NOT NULL
);


ALTER TABLE public.tb_compra_situacoes OWNER TO postgres;

--
-- TOC entry 5362 (class 0 OID 0)
-- Dependencies: 321
-- Name: TABLE tb_compra_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_compra_situacoes IS 'Situações possíveis de uma compra.';


--
-- TOC entry 5363 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN tb_compra_situacoes.id_compra_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compra_situacoes.id_compra_situacao IS 'Identificador.';


--
-- TOC entry 5364 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN tb_compra_situacoes.ds_compra_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compra_situacoes.ds_compra_situacao IS 'Descrição da situação da compra.';


--
-- TOC entry 320 (class 1259 OID 36856)
-- Name: tb_compra_situacoes_id_compra_situacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_compra_situacoes_id_compra_situacao_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_compra_situacoes_id_compra_situacao_seq OWNER TO postgres;

--
-- TOC entry 5365 (class 0 OID 0)
-- Dependencies: 320
-- Name: tb_compra_situacoes_id_compra_situacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_compra_situacoes_id_compra_situacao_seq OWNED BY public.tb_compra_situacoes.id_compra_situacao;


--
-- TOC entry 301 (class 1259 OID 22398)
-- Name: tb_compras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_compras (
    id_compra integer NOT NULL,
    id_empresa_compradora integer NOT NULL,
    sazonalidade boolean NOT NULL,
    id_local_entrega integer,
    id_local_retirada integer,
    quantidade_comprada numeric,
    valor_compra numeric,
    id_empresa_fornecedora integer,
    id_compra_situacao smallint NOT NULL,
    id_compra_aditivada integer,
    id_oferta integer,
    flexibilidade boolean NOT NULL,
    id_frete_tipo smallint NOT NULL,
    dt_inicio_entrega timestamp without time zone NOT NULL,
    dt_fim_entrega timestamp without time zone NOT NULL,
    quantidade_certificados integer,
    valor_certificados numeric
);


ALTER TABLE public.tb_compras OWNER TO postgres;

--
-- TOC entry 5366 (class 0 OID 0)
-- Dependencies: 301
-- Name: TABLE tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_compras IS 'Compras de biometano.';


--
-- TOC entry 5367 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_compra IS 'Identificador.';


--
-- TOC entry 5368 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_empresa_compradora; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_empresa_compradora IS 'Empresa que está fazendo a compra.';


--
-- TOC entry 5369 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.sazonalidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.sazonalidade IS 'Flag para sazonalidade: true = sazonal; false = contínua.';


--
-- TOC entry 5370 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_local_entrega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_local_entrega IS 'Local de entrega do material comprado.';


--
-- TOC entry 5371 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_local_retirada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_local_retirada IS 'Local de retirada do material comprado.';


--
-- TOC entry 5372 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.quantidade_comprada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.quantidade_comprada IS 'Quantidade de material comprado.';


--
-- TOC entry 5373 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.valor_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.valor_compra IS 'Valor (em moeda corrente) da compra.';


--
-- TOC entry 5374 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_empresa_fornecedora; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_empresa_fornecedora IS 'Empresa que está fornecendo o produto.';


--
-- TOC entry 5375 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_compra_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_compra_situacao IS 'Situação em que se encontra a compra.';


--
-- TOC entry 5376 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_compra_aditivada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_compra_aditivada IS 'Compra cujo contrato recebeu um aditivo.';


--
-- TOC entry 5377 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_oferta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_oferta IS 'Oferta a partir da qual a compra foi gerada.';


--
-- TOC entry 5378 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.flexibilidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.flexibilidade IS 'Flag para flexibilidade: true = flexível; false = firme.';


--
-- TOC entry 5379 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.id_frete_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.id_frete_tipo IS 'Tipo de frete adotado na compra.';


--
-- TOC entry 5380 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.dt_inicio_entrega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.dt_inicio_entrega IS 'Data de início da entrega do produto.';


--
-- TOC entry 5381 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.dt_fim_entrega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.dt_fim_entrega IS 'Data de fim da entrega do produto.';


--
-- TOC entry 5382 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.quantidade_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.quantidade_certificados IS 'Quantidade de certificados comprados.';


--
-- TOC entry 5383 (class 0 OID 0)
-- Dependencies: 301
-- Name: COLUMN tb_compras.valor_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_compras.valor_certificados IS 'Valor (em moeda corrente) dos certificados comprados.';


--
-- TOC entry 300 (class 1259 OID 22396)
-- Name: tb_compras_id_compra_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_compras_id_compra_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_compras_id_compra_seq OWNER TO postgres;

--
-- TOC entry 5384 (class 0 OID 0)
-- Dependencies: 300
-- Name: tb_compras_id_compra_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_compras_id_compra_seq OWNED BY public.tb_compras.id_compra;


--
-- TOC entry 353 (class 1259 OID 86283)
-- Name: tb_contrato_dados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_contrato_dados (
    id_contrato_dado integer NOT NULL,
    id_contrato integer NOT NULL,
    id_contrato_item smallint NOT NULL,
    valor_contrato_dado character varying(500) NOT NULL
);


ALTER TABLE public.tb_contrato_dados OWNER TO postgres;

--
-- TOC entry 5385 (class 0 OID 0)
-- Dependencies: 353
-- Name: TABLE tb_contrato_dados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_contrato_dados IS 'Dados variáveis de um contrato.';


--
-- TOC entry 5386 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN tb_contrato_dados.id_contrato_dado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contrato_dados.id_contrato_dado IS 'Identificador.';


--
-- TOC entry 5387 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN tb_contrato_dados.id_contrato; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contrato_dados.id_contrato IS 'Contrato cujos ítens estão sendo preenchidos.';


--
-- TOC entry 5388 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN tb_contrato_dados.id_contrato_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contrato_dados.id_contrato_item IS 'Item de contrato sendo preenchido.';


--
-- TOC entry 5389 (class 0 OID 0)
-- Dependencies: 353
-- Name: COLUMN tb_contrato_dados.valor_contrato_dado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contrato_dados.valor_contrato_dado IS 'Valor do item.';


--
-- TOC entry 352 (class 1259 OID 86281)
-- Name: tb_contrato_dados_id_contrato_dado_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_contrato_dados_id_contrato_dado_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_contrato_dados_id_contrato_dado_seq OWNER TO postgres;

--
-- TOC entry 5390 (class 0 OID 0)
-- Dependencies: 352
-- Name: tb_contrato_dados_id_contrato_dado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_contrato_dados_id_contrato_dado_seq OWNED BY public.tb_contrato_dados.id_contrato_dado;


--
-- TOC entry 351 (class 1259 OID 86275)
-- Name: tb_contrato_itens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_contrato_itens (
    id_contrato_item smallint NOT NULL,
    ds_contrato_item character varying(100) NOT NULL
);


ALTER TABLE public.tb_contrato_itens OWNER TO postgres;

--
-- TOC entry 5391 (class 0 OID 0)
-- Dependencies: 351
-- Name: TABLE tb_contrato_itens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_contrato_itens IS 'Ítens de contrato de uma compra.';


--
-- TOC entry 5392 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN tb_contrato_itens.id_contrato_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contrato_itens.id_contrato_item IS 'Identificador.';


--
-- TOC entry 5393 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN tb_contrato_itens.ds_contrato_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contrato_itens.ds_contrato_item IS 'Descrição do item de contrato.';


--
-- TOC entry 350 (class 1259 OID 86273)
-- Name: tb_contrato_itens_id_contrato_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_contrato_itens_id_contrato_item_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_contrato_itens_id_contrato_item_seq OWNER TO postgres;

--
-- TOC entry 5394 (class 0 OID 0)
-- Dependencies: 350
-- Name: tb_contrato_itens_id_contrato_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_contrato_itens_id_contrato_item_seq OWNED BY public.tb_contrato_itens.id_contrato_item;


--
-- TOC entry 349 (class 1259 OID 86259)
-- Name: tb_contratos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_contratos (
    id_contrato integer NOT NULL,
    id_compra integer NOT NULL,
    documento bytea
);


ALTER TABLE public.tb_contratos OWNER TO postgres;

--
-- TOC entry 5395 (class 0 OID 0)
-- Dependencies: 349
-- Name: TABLE tb_contratos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_contratos IS 'Contrato gerado a partir de uma compra.';


--
-- TOC entry 5396 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN tb_contratos.id_contrato; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contratos.id_contrato IS 'Identificador.';


--
-- TOC entry 5397 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN tb_contratos.id_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contratos.id_compra IS 'Compra a que corresponde o contrato.';


--
-- TOC entry 5398 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN tb_contratos.documento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_contratos.documento IS 'Arquivo contendo o contrato.';


--
-- TOC entry 348 (class 1259 OID 86257)
-- Name: tb_contratos_id_contrato_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_contratos_id_contrato_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_contratos_id_contrato_seq OWNER TO postgres;

--
-- TOC entry 5399 (class 0 OID 0)
-- Dependencies: 348
-- Name: tb_contratos_id_contrato_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_contratos_id_contrato_seq OWNED BY public.tb_contratos.id_contrato;


--
-- TOC entry 299 (class 1259 OID 22365)
-- Name: tb_empresa_representantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_empresa_representantes (
    id_empresa_representante integer NOT NULL,
    id_empresa integer NOT NULL,
    id_representante integer NOT NULL,
    id_usuario_inclusao integer NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    id_usuario_alteracao integer NOT NULL,
    dt_alteracao timestamp without time zone NOT NULL,
    ativo boolean NOT NULL
);


ALTER TABLE public.tb_empresa_representantes OWNER TO postgres;

--
-- TOC entry 5400 (class 0 OID 0)
-- Dependencies: 299
-- Name: TABLE tb_empresa_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_empresa_representantes IS 'Representantes das empresas.';


--
-- TOC entry 5401 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.id_empresa_representante; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.id_empresa_representante IS 'Identificador.';


--
-- TOC entry 5402 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.id_empresa IS 'Empresa representada.';


--
-- TOC entry 5403 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.id_representante; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.id_representante IS 'Representante da empresa.';


--
-- TOC entry 5404 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.id_usuario_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.id_usuario_inclusao IS 'Usuário responsável pela inclusão do representante.';


--
-- TOC entry 5405 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.dt_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.dt_inclusao IS 'Data/hora da inclusão do representante.';


--
-- TOC entry 5406 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.id_usuario_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.id_usuario_alteracao IS 'Usuário responsável pela alteração do representante.';


--
-- TOC entry 5407 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.dt_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.dt_alteracao IS 'Data/hora da alteração do representante.';


--
-- TOC entry 5408 (class 0 OID 0)
-- Dependencies: 299
-- Name: COLUMN tb_empresa_representantes.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_representantes.ativo IS 'Flag: ativo/inativo.';


--
-- TOC entry 298 (class 1259 OID 22363)
-- Name: tb_empresa_representantes_id_empresa_representante_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_empresa_representantes_id_empresa_representante_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_empresa_representantes_id_empresa_representante_seq OWNER TO postgres;

--
-- TOC entry 5409 (class 0 OID 0)
-- Dependencies: 298
-- Name: tb_empresa_representantes_id_empresa_representante_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_empresa_representantes_id_empresa_representante_seq OWNED BY public.tb_empresa_representantes.id_empresa_representante;


--
-- TOC entry 295 (class 1259 OID 22165)
-- Name: tb_empresa_situacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_empresa_situacoes (
    id_empresa_situacao smallint NOT NULL,
    ds_empresa_situacao character varying(100) NOT NULL
);


ALTER TABLE public.tb_empresa_situacoes OWNER TO postgres;

--
-- TOC entry 5410 (class 0 OID 0)
-- Dependencies: 295
-- Name: TABLE tb_empresa_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_empresa_situacoes IS 'Situações possíveis de uma empresa.';


--
-- TOC entry 5411 (class 0 OID 0)
-- Dependencies: 295
-- Name: COLUMN tb_empresa_situacoes.id_empresa_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_situacoes.id_empresa_situacao IS 'Identificador.';


--
-- TOC entry 5412 (class 0 OID 0)
-- Dependencies: 295
-- Name: COLUMN tb_empresa_situacoes.ds_empresa_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_situacoes.ds_empresa_situacao IS 'Descrição da situação da empresa.';


--
-- TOC entry 294 (class 1259 OID 22163)
-- Name: tb_empresa_situacoes_id_empresa_situacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_empresa_situacoes_id_empresa_situacao_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_empresa_situacoes_id_empresa_situacao_seq OWNER TO postgres;

--
-- TOC entry 5413 (class 0 OID 0)
-- Dependencies: 294
-- Name: tb_empresa_situacoes_id_empresa_situacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_empresa_situacoes_id_empresa_situacao_seq OWNED BY public.tb_empresa_situacoes.id_empresa_situacao;


--
-- TOC entry 335 (class 1259 OID 69683)
-- Name: tb_empresa_tipos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_empresa_tipos (
    id_empresa_tipo smallint NOT NULL,
    ds_empresa_tipo character varying(100) NOT NULL
);


ALTER TABLE public.tb_empresa_tipos OWNER TO postgres;

--
-- TOC entry 5414 (class 0 OID 0)
-- Dependencies: 335
-- Name: TABLE tb_empresa_tipos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_empresa_tipos IS 'Tipos possíveis de uma empresa.';


--
-- TOC entry 5415 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN tb_empresa_tipos.id_empresa_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_tipos.id_empresa_tipo IS 'Identificador.';


--
-- TOC entry 5416 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN tb_empresa_tipos.ds_empresa_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresa_tipos.ds_empresa_tipo IS 'Descrição do tipo de empresa.';


--
-- TOC entry 334 (class 1259 OID 69681)
-- Name: tb_empresa_tipos_id_empresa_tipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_empresa_tipos_id_empresa_tipo_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_empresa_tipos_id_empresa_tipo_seq OWNER TO postgres;

--
-- TOC entry 5417 (class 0 OID 0)
-- Dependencies: 334
-- Name: tb_empresa_tipos_id_empresa_tipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_empresa_tipos_id_empresa_tipo_seq OWNED BY public.tb_empresa_tipos.id_empresa_tipo;


--
-- TOC entry 293 (class 1259 OID 22149)
-- Name: tb_empresas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_empresas (
    id_empresa integer NOT NULL,
    cnpj character varying(14),
    razao_social character varying(100),
    nome_fantasia character varying(100),
    id_endereco integer,
    inscricao_estadual character varying(20),
    inscricao_municipal character varying(20),
    nicho_mercado character varying(100),
    servicos_produtos character varying(200),
    port_empr character varying(100),
    id_empresa_situacao smallint NOT NULL,
    id_usuario_inclusao integer,
    id_usuario_alteracao integer,
    dt_inclusao timestamp without time zone,
    dt_alteracao timestamp without time zone,
    area_atuacao_rodoviaria character varying(100),
    id_empresa_tipo smallint NOT NULL,
    area_atuacao_dutos character varying(100)
);


ALTER TABLE public.tb_empresas OWNER TO postgres;

--
-- TOC entry 5418 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_empresas IS 'Empresas.';


--
-- TOC entry 5419 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.id_empresa IS 'Identificador.';


--
-- TOC entry 5420 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.cnpj; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.cnpj IS 'Cadastro Nacional da Pessoa Jurídica.';


--
-- TOC entry 5421 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.razao_social; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.razao_social IS 'Razão social.';


--
-- TOC entry 5422 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.nome_fantasia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.nome_fantasia IS 'Nome-fantasia.';


--
-- TOC entry 5423 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.id_endereco; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.id_endereco IS 'Endereço.';


--
-- TOC entry 5424 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.inscricao_estadual; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.inscricao_estadual IS 'Inscrição estadual.';


--
-- TOC entry 5425 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.inscricao_municipal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.inscricao_municipal IS 'Inscrição municipal.';


--
-- TOC entry 5426 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.nicho_mercado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.nicho_mercado IS 'Nicho de mercado.';


--
-- TOC entry 5427 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.servicos_produtos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.servicos_produtos IS 'Descrição dos produtos/serviços oferecidos pela empresa? Flag do que a empresa oferece?';


--
-- TOC entry 5428 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.port_empr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.port_empr IS '???';


--
-- TOC entry 5429 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.id_empresa_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.id_empresa_situacao IS 'Situação da empresa.';


--
-- TOC entry 5430 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.id_usuario_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.id_usuario_inclusao IS 'Usuário responsável pela inclusão da empresa.';


--
-- TOC entry 5431 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.id_usuario_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.id_usuario_alteracao IS 'Usuário responsável pela alteração da empresa.';


--
-- TOC entry 5432 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.dt_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.dt_inclusao IS 'Data/hora da inclusão da empresa.';


--
-- TOC entry 5433 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.dt_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.dt_alteracao IS 'Data/hora da alteração da empresa.';


--
-- TOC entry 5434 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.area_atuacao_rodoviaria; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.area_atuacao_rodoviaria IS 'Dado georreferenciado: área (geográfica) de atuação da empresa.';


--
-- TOC entry 5435 (class 0 OID 0)
-- Dependencies: 293
-- Name: COLUMN tb_empresas.id_empresa_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_empresas.id_empresa_tipo IS 'Tipo de empresa.';


--
-- TOC entry 292 (class 1259 OID 22147)
-- Name: tb_empresas_id_empresa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_empresas_id_empresa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_empresas_id_empresa_seq OWNER TO postgres;

--
-- TOC entry 5436 (class 0 OID 0)
-- Dependencies: 292
-- Name: tb_empresas_id_empresa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_empresas_id_empresa_seq OWNED BY public.tb_empresas.id_empresa;


--
-- TOC entry 291 (class 1259 OID 22128)
-- Name: tb_enderecos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_enderecos (
    id_endereco integer NOT NULL,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cep character varying,
    cidade character varying,
    estado character varying,
    pais character varying,
    telefone character varying,
    email character varying,
    the_geom character varying(100)
);


ALTER TABLE public.tb_enderecos OWNER TO postgres;

--
-- TOC entry 5437 (class 0 OID 0)
-- Dependencies: 291
-- Name: TABLE tb_enderecos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_enderecos IS 'Endereços de empresas e representantes.';


--
-- TOC entry 5438 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.id_endereco; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.id_endereco IS 'Identificador.';


--
-- TOC entry 5439 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.logradouro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.logradouro IS 'Rua, Avenida, Praça, etc.';


--
-- TOC entry 5440 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.numero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.numero IS 'Número do logradouro.';


--
-- TOC entry 5441 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.complemento IS 'Apto, bloco, casa, quadra, etc.';


--
-- TOC entry 5442 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.bairro IS 'Bairro.';


--
-- TOC entry 5443 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.cep; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.cep IS 'Código de Endereçamento Postal (CEP).';


--
-- TOC entry 5444 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.estado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.estado IS 'Unidade da Federação (Pode ser a partir de uma tabela de domínio)';


--
-- TOC entry 5445 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.pais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.pais IS 'País.';


--
-- TOC entry 5446 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.telefone IS 'Telefone(s) com DDD, separados por algum caracter (talvez /)';


--
-- TOC entry 5447 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.email IS 'Endereços de correio eletrônico, separados por algum caracter (talvez /)';


--
-- TOC entry 5448 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN tb_enderecos.the_geom; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_enderecos.the_geom IS 'Dado georreferenciado: localização do endereço.';


--
-- TOC entry 290 (class 1259 OID 22126)
-- Name: tb_enderecos_id_endereco_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_enderecos_id_endereco_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_enderecos_id_endereco_seq OWNER TO postgres;

--
-- TOC entry 5449 (class 0 OID 0)
-- Dependencies: 290
-- Name: tb_enderecos_id_endereco_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_enderecos_id_endereco_seq OWNED BY public.tb_enderecos.id_endereco;


--
-- TOC entry 331 (class 1259 OID 61495)
-- Name: tb_entregas_sazonais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_entregas_sazonais (
    id_entrega_sazonal integer NOT NULL,
    id_negociacao_rodada integer NOT NULL,
    mes_entrega smallint NOT NULL,
    valor_mes numeric NOT NULL
);


ALTER TABLE public.tb_entregas_sazonais OWNER TO postgres;

--
-- TOC entry 5450 (class 0 OID 0)
-- Dependencies: 331
-- Name: TABLE tb_entregas_sazonais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_entregas_sazonais IS 'Na entrega sazonal, os valores podem variar mês a mês.';


--
-- TOC entry 5451 (class 0 OID 0)
-- Dependencies: 331
-- Name: COLUMN tb_entregas_sazonais.id_entrega_sazonal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_entregas_sazonais.id_entrega_sazonal IS 'Identificador.';


--
-- TOC entry 5452 (class 0 OID 0)
-- Dependencies: 331
-- Name: COLUMN tb_entregas_sazonais.id_negociacao_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_entregas_sazonais.id_negociacao_rodada IS 'Rodada em que houve a negociação dos meses de entrega.';


--
-- TOC entry 5453 (class 0 OID 0)
-- Dependencies: 331
-- Name: COLUMN tb_entregas_sazonais.mes_entrega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_entregas_sazonais.mes_entrega IS 'Mês da entrega.';


--
-- TOC entry 5454 (class 0 OID 0)
-- Dependencies: 331
-- Name: COLUMN tb_entregas_sazonais.valor_mes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_entregas_sazonais.valor_mes IS 'Valor (metros cúbicos) negociado para aquele mês.';


--
-- TOC entry 330 (class 1259 OID 61493)
-- Name: tb_entregas_sazonais_id_entrega_sazonal_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_entregas_sazonais_id_entrega_sazonal_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_entregas_sazonais_id_entrega_sazonal_seq OWNER TO postgres;

--
-- TOC entry 5455 (class 0 OID 0)
-- Dependencies: 330
-- Name: tb_entregas_sazonais_id_entrega_sazonal_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_entregas_sazonais_id_entrega_sazonal_seq OWNED BY public.tb_entregas_sazonais.id_entrega_sazonal;


--
-- TOC entry 333 (class 1259 OID 69665)
-- Name: tb_frete_tipos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_frete_tipos (
    id_frete_tipo smallint NOT NULL,
    sg_frete_tipo character varying(50) NOT NULL,
    ds_frete_tipo character varying(50) NOT NULL
);


ALTER TABLE public.tb_frete_tipos OWNER TO postgres;

--
-- TOC entry 5456 (class 0 OID 0)
-- Dependencies: 333
-- Name: TABLE tb_frete_tipos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_frete_tipos IS 'Tipos de frete: CIF/FOB.';


--
-- TOC entry 5457 (class 0 OID 0)
-- Dependencies: 333
-- Name: COLUMN tb_frete_tipos.id_frete_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_frete_tipos.id_frete_tipo IS 'Identificador.';


--
-- TOC entry 5458 (class 0 OID 0)
-- Dependencies: 333
-- Name: COLUMN tb_frete_tipos.sg_frete_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_frete_tipos.sg_frete_tipo IS 'Sigla do tipo de frete.';


--
-- TOC entry 5459 (class 0 OID 0)
-- Dependencies: 333
-- Name: COLUMN tb_frete_tipos.ds_frete_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_frete_tipos.ds_frete_tipo IS 'Descrição do tipo de frete.';


--
-- TOC entry 332 (class 1259 OID 69663)
-- Name: tb_frete_tipos_id_frete_tipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_frete_tipos_id_frete_tipo_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_frete_tipos_id_frete_tipo_seq OWNER TO postgres;

--
-- TOC entry 5460 (class 0 OID 0)
-- Dependencies: 332
-- Name: tb_frete_tipos_id_frete_tipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_frete_tipos_id_frete_tipo_seq OWNED BY public.tb_frete_tipos.id_frete_tipo;


--
-- TOC entry 303 (class 1259 OID 22411)
-- Name: tb_locais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_locais (
    id_local smallint NOT NULL,
    ds_local character varying(100),
    id_endereco integer,
    nm_local character varying(50) NOT NULL,
    id_empresa integer
);


ALTER TABLE public.tb_locais OWNER TO postgres;

--
-- TOC entry 5461 (class 0 OID 0)
-- Dependencies: 303
-- Name: TABLE tb_locais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_locais IS 'Locais de entrega ou retirada de compras.';


--
-- TOC entry 5462 (class 0 OID 0)
-- Dependencies: 303
-- Name: COLUMN tb_locais.id_local; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_locais.id_local IS 'Identificador.';


--
-- TOC entry 5463 (class 0 OID 0)
-- Dependencies: 303
-- Name: COLUMN tb_locais.ds_local; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_locais.ds_local IS 'Descrição do local.';


--
-- TOC entry 5464 (class 0 OID 0)
-- Dependencies: 303
-- Name: COLUMN tb_locais.nm_local; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_locais.nm_local IS 'Nome do local.';


--
-- TOC entry 5465 (class 0 OID 0)
-- Dependencies: 303
-- Name: COLUMN tb_locais.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_locais.id_empresa IS 'Empresa a que pertence o local. Se nulo, o local é público.';


--
-- TOC entry 302 (class 1259 OID 22409)
-- Name: tb_locais_id_local_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_locais_id_local_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_locais_id_local_seq OWNER TO postgres;

--
-- TOC entry 5466 (class 0 OID 0)
-- Dependencies: 302
-- Name: tb_locais_id_local_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_locais_id_local_seq OWNED BY public.tb_locais.id_local;


--
-- TOC entry 347 (class 1259 OID 86236)
-- Name: tb_logistica_coletas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_logistica_coletas (
    id_logistica_coleta integer NOT NULL,
    entrada character varying(3) NOT NULL,
    id_endereco integer NOT NULL,
    id_logistica integer NOT NULL,
    id_empresa integer
);


ALTER TABLE public.tb_logistica_coletas OWNER TO postgres;

--
-- TOC entry 5467 (class 0 OID 0)
-- Dependencies: 347
-- Name: TABLE tb_logistica_coletas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_logistica_coletas IS 'Pontos de coleta.';


--
-- TOC entry 5468 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN tb_logistica_coletas.id_logistica_coleta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_coletas.id_logistica_coleta IS 'Identificador.';


--
-- TOC entry 5469 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN tb_logistica_coletas.entrada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_coletas.entrada IS 'E = entrada, S = saída, E/S = entrada/saída.';


--
-- TOC entry 5470 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN tb_logistica_coletas.id_endereco; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_coletas.id_endereco IS 'Endereço do ponto de coleta.';


--
-- TOC entry 5471 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN tb_logistica_coletas.id_logistica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_coletas.id_logistica IS 'Logística de transporte envolvendo o ponto de coleta.';


--
-- TOC entry 5472 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN tb_logistica_coletas.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_coletas.id_empresa IS 'Empresa a que pertence o ponto de coleta.';


--
-- TOC entry 346 (class 1259 OID 86234)
-- Name: tb_logistica_coletas_id_logistica_coleta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_logistica_coletas_id_logistica_coleta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_logistica_coletas_id_logistica_coleta_seq OWNER TO postgres;

--
-- TOC entry 5473 (class 0 OID 0)
-- Dependencies: 346
-- Name: tb_logistica_coletas_id_logistica_coleta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_logistica_coletas_id_logistica_coleta_seq OWNED BY public.tb_logistica_coletas.id_logistica_coleta;


--
-- TOC entry 315 (class 1259 OID 22634)
-- Name: tb_logistica_compras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_logistica_compras (
    id_logistica_compra integer NOT NULL,
    id_compra integer NOT NULL,
    id_logistica integer NOT NULL,
    valor_logistica numeric NOT NULL
);


ALTER TABLE public.tb_logistica_compras OWNER TO postgres;

--
-- TOC entry 5474 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE tb_logistica_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_logistica_compras IS 'Logísticas de uma compra.';


--
-- TOC entry 5475 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN tb_logistica_compras.id_logistica_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_compras.id_logistica_compra IS 'Identificador.';


--
-- TOC entry 5476 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN tb_logistica_compras.id_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_compras.id_compra IS 'Compra de biometano.';


--
-- TOC entry 5477 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN tb_logistica_compras.id_logistica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_compras.id_logistica IS 'Logística da compra.';


--
-- TOC entry 5478 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN tb_logistica_compras.valor_logistica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_compras.valor_logistica IS 'Valor da logística da compra.';


--
-- TOC entry 314 (class 1259 OID 22632)
-- Name: tb_logistica_compras_id_logistica_compra_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_logistica_compras_id_logistica_compra_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_logistica_compras_id_logistica_compra_seq OWNER TO postgres;

--
-- TOC entry 5479 (class 0 OID 0)
-- Dependencies: 314
-- Name: tb_logistica_compras_id_logistica_compra_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_logistica_compras_id_logistica_compra_seq OWNED BY public.tb_logistica_compras.id_logistica_compra;


--
-- TOC entry 345 (class 1259 OID 86215)
-- Name: tb_logistica_dutos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_logistica_dutos (
    id_logistica_duto integer NOT NULL,
    nome_duto character varying(100) NOT NULL,
    diametro_duto numeric NOT NULL,
    id_logistica integer NOT NULL,
    id_empresa integer,
    the_geom character varying(100)
);


ALTER TABLE public.tb_logistica_dutos OWNER TO postgres;

--
-- TOC entry 5480 (class 0 OID 0)
-- Dependencies: 345
-- Name: TABLE tb_logistica_dutos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_logistica_dutos IS 'Logística de transporte por tudos.';


--
-- TOC entry 5481 (class 0 OID 0)
-- Dependencies: 345
-- Name: COLUMN tb_logistica_dutos.id_logistica_duto; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_dutos.id_logistica_duto IS 'Identificador.';


--
-- TOC entry 5482 (class 0 OID 0)
-- Dependencies: 345
-- Name: COLUMN tb_logistica_dutos.id_logistica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_dutos.id_logistica IS 'Logística de transporte envolvendo o duto.';


--
-- TOC entry 5483 (class 0 OID 0)
-- Dependencies: 345
-- Name: COLUMN tb_logistica_dutos.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_dutos.id_empresa IS 'Empresa a que pertence o duto.';


--
-- TOC entry 5484 (class 0 OID 0)
-- Dependencies: 345
-- Name: COLUMN tb_logistica_dutos.the_geom; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logistica_dutos.the_geom IS 'Dado georreferenciado: localização do duto.';


--
-- TOC entry 344 (class 1259 OID 86213)
-- Name: tb_logistica_dutos_id_logistica_duto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_logistica_dutos_id_logistica_duto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_logistica_dutos_id_logistica_duto_seq OWNER TO postgres;

--
-- TOC entry 5485 (class 0 OID 0)
-- Dependencies: 344
-- Name: tb_logistica_dutos_id_logistica_duto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_logistica_dutos_id_logistica_duto_seq OWNED BY public.tb_logistica_dutos.id_logistica_duto;


--
-- TOC entry 313 (class 1259 OID 22587)
-- Name: tb_logisticas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_logisticas (
    id_logistica integer NOT NULL,
    tipo_transporte character varying(50) NOT NULL,
    id_empresa_transportadora integer NOT NULL
);


ALTER TABLE public.tb_logisticas OWNER TO postgres;

--
-- TOC entry 5486 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE tb_logisticas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_logisticas IS 'Logística de transporte.';


--
-- TOC entry 5487 (class 0 OID 0)
-- Dependencies: 313
-- Name: COLUMN tb_logisticas.id_logistica; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logisticas.id_logistica IS 'Identificador.';


--
-- TOC entry 5488 (class 0 OID 0)
-- Dependencies: 313
-- Name: COLUMN tb_logisticas.tipo_transporte; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logisticas.tipo_transporte IS 'Transporte, distribuição, GNC, GNL, outros (campo livre).';


--
-- TOC entry 5489 (class 0 OID 0)
-- Dependencies: 313
-- Name: COLUMN tb_logisticas.id_empresa_transportadora; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_logisticas.id_empresa_transportadora IS 'Empresa responsável pelo transporte.';


--
-- TOC entry 312 (class 1259 OID 22585)
-- Name: tb_logisticas_id_logistica_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_logisticas_id_logistica_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_logisticas_id_logistica_seq OWNER TO postgres;

--
-- TOC entry 5490 (class 0 OID 0)
-- Dependencies: 312
-- Name: tb_logisticas_id_logistica_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_logisticas_id_logistica_seq OWNED BY public.tb_logisticas.id_logistica;


--
-- TOC entry 327 (class 1259 OID 61454)
-- Name: tb_negociacao_itens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_negociacao_itens (
    id_negociacao_item smallint NOT NULL,
    ds_negociacao_item character varying(100) NOT NULL
);


ALTER TABLE public.tb_negociacao_itens OWNER TO postgres;

--
-- TOC entry 5491 (class 0 OID 0)
-- Dependencies: 327
-- Name: TABLE tb_negociacao_itens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_negociacao_itens IS 'Ítens de negociação de uma compra.';


--
-- TOC entry 5492 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN tb_negociacao_itens.id_negociacao_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_itens.id_negociacao_item IS 'Identificador.';


--
-- TOC entry 5493 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN tb_negociacao_itens.ds_negociacao_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_itens.ds_negociacao_item IS 'Descrição do item de negociação.';


--
-- TOC entry 326 (class 1259 OID 61452)
-- Name: tb_negociacao_itens_id_negociacao_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_negociacao_itens_id_negociacao_item_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_negociacao_itens_id_negociacao_item_seq OWNER TO postgres;

--
-- TOC entry 5494 (class 0 OID 0)
-- Dependencies: 326
-- Name: tb_negociacao_itens_id_negociacao_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_negociacao_itens_id_negociacao_item_seq OWNED BY public.tb_negociacao_itens.id_negociacao_item;


--
-- TOC entry 339 (class 1259 OID 69759)
-- Name: tb_negociacao_propostas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_negociacao_propostas (
    id_negociacao_proposta integer NOT NULL,
    id_negociacao_rodada integer NOT NULL,
    id_negociacao_item smallint NOT NULL,
    valor_proposto character varying(50) NOT NULL
);


ALTER TABLE public.tb_negociacao_propostas OWNER TO postgres;

--
-- TOC entry 5495 (class 0 OID 0)
-- Dependencies: 339
-- Name: TABLE tb_negociacao_propostas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_negociacao_propostas IS 'Propostas feitas em uma rodada de negociação.';


--
-- TOC entry 5496 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN tb_negociacao_propostas.id_negociacao_proposta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_proposta IS 'Identificador.';


--
-- TOC entry 5497 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN tb_negociacao_propostas.id_negociacao_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_rodada IS 'Rodada de negociação a que pertence a proposta sendo feita.';


--
-- TOC entry 5498 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN tb_negociacao_propostas.id_negociacao_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_item IS 'Item sendo negociado na proposta.';


--
-- TOC entry 5499 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN tb_negociacao_propostas.valor_proposto; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_propostas.valor_proposto IS 'Valor proposto do item.';


--
-- TOC entry 338 (class 1259 OID 69757)
-- Name: tb_negociacao_propostas_id_negociacao_proposta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_negociacao_propostas_id_negociacao_proposta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_negociacao_propostas_id_negociacao_proposta_seq OWNER TO postgres;

--
-- TOC entry 5500 (class 0 OID 0)
-- Dependencies: 338
-- Name: tb_negociacao_propostas_id_negociacao_proposta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_negociacao_propostas_id_negociacao_proposta_seq OWNED BY public.tb_negociacao_propostas.id_negociacao_proposta;


--
-- TOC entry 337 (class 1259 OID 69696)
-- Name: tb_negociacao_rodadas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_negociacao_rodadas (
    id_negociacao_rodada integer NOT NULL,
    id_oferta integer NOT NULL,
    nr_rodada smallint NOT NULL,
    dh_rodada timestamp without time zone NOT NULL,
    observacao character varying(500),
    finalizada boolean DEFAULT false NOT NULL,
    id_empresa_proponente integer NOT NULL,
    id_negociacao_rodada_anterior integer
);


ALTER TABLE public.tb_negociacao_rodadas OWNER TO postgres;

--
-- TOC entry 5501 (class 0 OID 0)
-- Dependencies: 337
-- Name: TABLE tb_negociacao_rodadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_negociacao_rodadas IS 'Rodadas de uma negociação.';


--
-- TOC entry 5502 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.id_negociacao_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_negociacao_rodada IS 'Identificador.';


--
-- TOC entry 5503 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.id_oferta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_oferta IS 'Oferta sendo negociada.';


--
-- TOC entry 5504 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.nr_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.nr_rodada IS 'Número da rodada de negociação.';


--
-- TOC entry 5505 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.dh_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.dh_rodada IS 'Data/hora da rodada de negociação.';


--
-- TOC entry 5506 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.observacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.observacao IS 'Campo livre para observações acerca da negociação.';


--
-- TOC entry 5507 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.finalizada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.finalizada IS 'Flag indicando se a negociação se encerrou nessa rodada.';


--
-- TOC entry 5508 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.id_empresa_proponente; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_empresa_proponente IS 'Empresa que fez a proposta sobre o item.';


--
-- TOC entry 5509 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN tb_negociacao_rodadas.id_negociacao_rodada_anterior; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_negociacao_rodada_anterior IS 'Rodada anterior na negociação.';


--
-- TOC entry 329 (class 1259 OID 61462)
-- Name: tb_negociacao_rodadas_antiga; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_negociacao_rodadas_antiga (
    id_negociacao_rodada integer NOT NULL,
    id_oferta integer NOT NULL,
    id_negociacao_item smallint NOT NULL,
    valor_proposto character varying(50) NOT NULL,
    dh_rodada timestamp without time zone NOT NULL,
    id_empresa_proponente integer NOT NULL,
    id_negociacao_rodada_anterior integer NOT NULL,
    observacao character varying(500),
    finalizada boolean DEFAULT false NOT NULL,
    nr_rodada smallint NOT NULL
);


ALTER TABLE public.tb_negociacao_rodadas_antiga OWNER TO postgres;

--
-- TOC entry 5510 (class 0 OID 0)
-- Dependencies: 329
-- Name: TABLE tb_negociacao_rodadas_antiga; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_negociacao_rodadas_antiga IS 'Rodadas de negociação de uma compra.';


--
-- TOC entry 5511 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.id_negociacao_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.id_negociacao_rodada IS 'Identificador.';


--
-- TOC entry 5512 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.id_oferta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.id_oferta IS 'Oferta sendo negociada.';


--
-- TOC entry 5513 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.id_negociacao_item; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.id_negociacao_item IS 'Item sendo negociado.';


--
-- TOC entry 5514 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.valor_proposto; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.valor_proposto IS 'Valor proposto do item.';


--
-- TOC entry 5515 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.dh_rodada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.dh_rodada IS 'Data/hora da rodada de negociação.';


--
-- TOC entry 5516 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.id_empresa_proponente; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.id_empresa_proponente IS 'Empresa que fez a proposta do item.';


--
-- TOC entry 5517 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.id_negociacao_rodada_anterior; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.id_negociacao_rodada_anterior IS 'Proposta a que se está respondendo.';


--
-- TOC entry 5518 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN tb_negociacao_rodadas_antiga.observacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_negociacao_rodadas_antiga.observacao IS 'Campo livre para observações acerca da negociação.';


--
-- TOC entry 328 (class 1259 OID 61460)
-- Name: tb_negociacao_rodadas_id_negociacao_rodada_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_negociacao_rodadas_id_negociacao_rodada_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_negociacao_rodadas_id_negociacao_rodada_seq OWNER TO postgres;

--
-- TOC entry 5519 (class 0 OID 0)
-- Dependencies: 328
-- Name: tb_negociacao_rodadas_id_negociacao_rodada_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_negociacao_rodadas_id_negociacao_rodada_seq OWNED BY public.tb_negociacao_rodadas_antiga.id_negociacao_rodada;


--
-- TOC entry 336 (class 1259 OID 69694)
-- Name: tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq OWNER TO postgres;

--
-- TOC entry 5520 (class 0 OID 0)
-- Dependencies: 336
-- Name: tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq OWNED BY public.tb_negociacao_rodadas.id_negociacao_rodada;


--
-- TOC entry 325 (class 1259 OID 53229)
-- Name: tb_noticia_situacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_noticia_situacoes (
    id_noticia_situacao smallint NOT NULL,
    ds_noticia_situacao character varying(100) NOT NULL
);


ALTER TABLE public.tb_noticia_situacoes OWNER TO postgres;

--
-- TOC entry 5521 (class 0 OID 0)
-- Dependencies: 325
-- Name: TABLE tb_noticia_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_noticia_situacoes IS 'Situações possíveis de uma notícia.';


--
-- TOC entry 5522 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN tb_noticia_situacoes.id_noticia_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticia_situacoes.id_noticia_situacao IS 'Identificador.';


--
-- TOC entry 5523 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN tb_noticia_situacoes.ds_noticia_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticia_situacoes.ds_noticia_situacao IS 'Descrição da situação da notícia.';


--
-- TOC entry 324 (class 1259 OID 53227)
-- Name: tb_noticia_situacoes_id_noticia_situacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_noticia_situacoes_id_noticia_situacao_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_noticia_situacoes_id_noticia_situacao_seq OWNER TO postgres;

--
-- TOC entry 5524 (class 0 OID 0)
-- Dependencies: 324
-- Name: tb_noticia_situacoes_id_noticia_situacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_noticia_situacoes_id_noticia_situacao_seq OWNED BY public.tb_noticia_situacoes.id_noticia_situacao;


--
-- TOC entry 309 (class 1259 OID 22542)
-- Name: tb_noticias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_noticias (
    id_noticia integer NOT NULL,
    dt_noticia timestamp without time zone NOT NULL,
    texto_noticia text NOT NULL,
    id_empresa integer NOT NULL,
    id_noticia_situacao smallint NOT NULL,
    id_usuario_inclusao integer NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    id_usuario_alteracao integer,
    dt_alteracao timestamp without time zone,
    titulo_noticia character varying(60) NOT NULL
);


ALTER TABLE public.tb_noticias OWNER TO postgres;

--
-- TOC entry 5525 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE tb_noticias; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_noticias IS 'Notícias das empresas.';


--
-- TOC entry 5526 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.id_noticia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.id_noticia IS 'Identificador.';


--
-- TOC entry 5527 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.dt_noticia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.dt_noticia IS 'Data da notícia';


--
-- TOC entry 5528 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.texto_noticia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.texto_noticia IS 'Texto da notícia.';


--
-- TOC entry 5529 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.id_empresa IS 'Empresa relacionada (ou responsável?) pela notícia.';


--
-- TOC entry 5530 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.id_noticia_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.id_noticia_situacao IS 'Situação em que se encontra a notícia.';


--
-- TOC entry 5531 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.id_usuario_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.id_usuario_inclusao IS 'Usuário responsável pela inclusão da notícia.';


--
-- TOC entry 5532 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.dt_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.dt_inclusao IS 'Data/hora da inclusão da notícia.';


--
-- TOC entry 5533 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.id_usuario_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.id_usuario_alteracao IS 'Usuário responsável pela alteração da notícia.';


--
-- TOC entry 5534 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.dt_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.dt_alteracao IS 'Data/hora da alteração da notícia.';


--
-- TOC entry 5535 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN tb_noticias.titulo_noticia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_noticias.titulo_noticia IS 'Título da notícia.';


--
-- TOC entry 308 (class 1259 OID 22540)
-- Name: tb_noticias_id_noticia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_noticias_id_noticia_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_noticias_id_noticia_seq OWNER TO postgres;

--
-- TOC entry 5536 (class 0 OID 0)
-- Dependencies: 308
-- Name: tb_noticias_id_noticia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_noticias_id_noticia_seq OWNED BY public.tb_noticias.id_noticia;


--
-- TOC entry 319 (class 1259 OID 36845)
-- Name: tb_oferta_situacoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_oferta_situacoes (
    id_oferta_situacao smallint NOT NULL,
    ds_oferta_situacao character varying(100) NOT NULL
);


ALTER TABLE public.tb_oferta_situacoes OWNER TO postgres;

--
-- TOC entry 5537 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE tb_oferta_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_oferta_situacoes IS 'Situações possíveis de uma oferta.';


--
-- TOC entry 5538 (class 0 OID 0)
-- Dependencies: 319
-- Name: COLUMN tb_oferta_situacoes.id_oferta_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_oferta_situacoes.id_oferta_situacao IS 'Identificador.';


--
-- TOC entry 5539 (class 0 OID 0)
-- Dependencies: 319
-- Name: COLUMN tb_oferta_situacoes.ds_oferta_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_oferta_situacoes.ds_oferta_situacao IS 'Descrição da situação da oferta.';


--
-- TOC entry 318 (class 1259 OID 36843)
-- Name: tb_oferta_situacoes_id_oferta_situacao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_oferta_situacoes_id_oferta_situacao_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_oferta_situacoes_id_oferta_situacao_seq OWNER TO postgres;

--
-- TOC entry 5540 (class 0 OID 0)
-- Dependencies: 318
-- Name: tb_oferta_situacoes_id_oferta_situacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_oferta_situacoes_id_oferta_situacao_seq OWNED BY public.tb_oferta_situacoes.id_oferta_situacao;


--
-- TOC entry 323 (class 1259 OID 45037)
-- Name: tb_oferta_tipos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_oferta_tipos (
    id_oferta_tipo smallint NOT NULL,
    ds_oferta_tipo character varying(100) NOT NULL
);


ALTER TABLE public.tb_oferta_tipos OWNER TO postgres;

--
-- TOC entry 5541 (class 0 OID 0)
-- Dependencies: 323
-- Name: TABLE tb_oferta_tipos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_oferta_tipos IS 'Tipos possíveis de uma oferta: só biometano, biometano+certificados, só certificados.';


--
-- TOC entry 5542 (class 0 OID 0)
-- Dependencies: 323
-- Name: COLUMN tb_oferta_tipos.id_oferta_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_oferta_tipos.id_oferta_tipo IS 'Identificador.';


--
-- TOC entry 5543 (class 0 OID 0)
-- Dependencies: 323
-- Name: COLUMN tb_oferta_tipos.ds_oferta_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_oferta_tipos.ds_oferta_tipo IS 'Descrição do tipo de oferta.';


--
-- TOC entry 322 (class 1259 OID 45035)
-- Name: tb_oferta_tipos_id_oferta_tipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_oferta_tipos_id_oferta_tipo_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_oferta_tipos_id_oferta_tipo_seq OWNER TO postgres;

--
-- TOC entry 5544 (class 0 OID 0)
-- Dependencies: 322
-- Name: tb_oferta_tipos_id_oferta_tipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_oferta_tipos_id_oferta_tipo_seq OWNED BY public.tb_oferta_tipos.id_oferta_tipo;


--
-- TOC entry 307 (class 1259 OID 22490)
-- Name: tb_ofertas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_ofertas (
    id_oferta integer NOT NULL,
    dt_oferta timestamp without time zone NOT NULL,
    quantidade_ofertada numeric,
    id_empresa integer NOT NULL,
    id_oferta_situacao smallint NOT NULL,
    id_oferta_tipo smallint NOT NULL,
    dt_validade timestamp without time zone,
    id_empresa_privada integer,
    compra_venda character(1),
    id_certificado integer,
    quantidade_certificados integer,
    exibe_nome_empresa boolean
);


ALTER TABLE public.tb_ofertas OWNER TO postgres;

--
-- TOC entry 5545 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_ofertas IS 'Ofertas de biometano.';


--
-- TOC entry 5546 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.id_oferta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.id_oferta IS 'Identificador.';


--
-- TOC entry 5547 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.dt_oferta; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.dt_oferta IS 'Data da oferta.';


--
-- TOC entry 5548 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.quantidade_ofertada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.quantidade_ofertada IS 'Quantidade de material ofertado.';


--
-- TOC entry 5549 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.id_empresa IS 'Empresa com a oferta.';


--
-- TOC entry 5550 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.id_oferta_situacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.id_oferta_situacao IS 'Situação em que se encontra a oferta.';


--
-- TOC entry 5551 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.id_oferta_tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.id_oferta_tipo IS 'Tipo da oferta: só biometano, biometano+certificado, só certificado.';


--
-- TOC entry 5552 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.dt_validade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.dt_validade IS 'Validade da oferta.';


--
-- TOC entry 5553 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.id_empresa_privada; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.id_empresa_privada IS 'Empresa a quem se destina a oferta no caso de a oferta ser privada.';


--
-- TOC entry 5554 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.compra_venda; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.compra_venda IS 'Compra ou venda: compra = ''C'', venda = ''V''.';


--
-- TOC entry 5555 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.id_certificado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.id_certificado IS 'Certificados sendo oferecidos.';


--
-- TOC entry 5556 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.quantidade_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.quantidade_certificados IS 'Quantidade de certificados oferecidos.';


--
-- TOC entry 5557 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN tb_ofertas.exibe_nome_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_ofertas.exibe_nome_empresa IS 'No caso de uma oferta pública, true exibe o nome da empresa, false não exibe.';


--
-- TOC entry 306 (class 1259 OID 22488)
-- Name: tb_ofertas_id_oferta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_ofertas_id_oferta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_ofertas_id_oferta_seq OWNER TO postgres;

--
-- TOC entry 5558 (class 0 OID 0)
-- Dependencies: 306
-- Name: tb_ofertas_id_oferta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_ofertas_id_oferta_seq OWNED BY public.tb_ofertas.id_oferta;


--
-- TOC entry 289 (class 1259 OID 22107)
-- Name: tb_perfil_permissoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_perfil_permissoes (
    id_perfil_permissao integer NOT NULL,
    id_perfil smallint NOT NULL,
    id_permissao smallint NOT NULL
);


ALTER TABLE public.tb_perfil_permissoes OWNER TO postgres;

--
-- TOC entry 5559 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE tb_perfil_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_perfil_permissoes IS 'Permissões atribuídas a um perfil.';


--
-- TOC entry 5560 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN tb_perfil_permissoes.id_perfil_permissao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfil_permissoes.id_perfil_permissao IS 'Identificador.';


--
-- TOC entry 5561 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN tb_perfil_permissoes.id_perfil; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfil_permissoes.id_perfil IS 'Perfil a que é atribuída uma permissão.';


--
-- TOC entry 5562 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN tb_perfil_permissoes.id_permissao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfil_permissoes.id_permissao IS 'Permissão sendo atribuída a um perfil.';


--
-- TOC entry 288 (class 1259 OID 22105)
-- Name: tb_perfil_permissoes_id_perfil_permissao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_perfil_permissoes_id_perfil_permissao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_perfil_permissoes_id_perfil_permissao_seq OWNER TO postgres;

--
-- TOC entry 5563 (class 0 OID 0)
-- Dependencies: 288
-- Name: tb_perfil_permissoes_id_perfil_permissao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_perfil_permissoes_id_perfil_permissao_seq OWNED BY public.tb_perfil_permissoes.id_perfil_permissao;


--
-- TOC entry 287 (class 1259 OID 22067)
-- Name: tb_perfis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_perfis (
    id_perfil smallint NOT NULL,
    nome_perfil character varying(100) NOT NULL,
    ds_perfil character varying(255) NOT NULL,
    id_usuario_inclusao integer NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    id_usuario_alteracao integer,
    dt_alteracao timestamp without time zone NOT NULL,
    ativo boolean NOT NULL
);


ALTER TABLE public.tb_perfis OWNER TO postgres;

--
-- TOC entry 5564 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE tb_perfis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_perfis IS 'Perfil a ser atribuído a um usuário.';


--
-- TOC entry 5565 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.id_perfil; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.id_perfil IS 'Identificador.';


--
-- TOC entry 5566 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.nome_perfil; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.nome_perfil IS 'Nome do perfil.';


--
-- TOC entry 5567 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.ds_perfil; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.ds_perfil IS 'Descrição do perfil.';


--
-- TOC entry 5568 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.id_usuario_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.id_usuario_inclusao IS 'Usuário responsável pela inclusão do perfil.';


--
-- TOC entry 5569 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.dt_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.dt_inclusao IS 'Data/hora da inclusão do perfil.';


--
-- TOC entry 5570 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.id_usuario_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.id_usuario_alteracao IS 'Usuário responsável pela alteração do perfil.';


--
-- TOC entry 5571 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.dt_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.dt_alteracao IS 'Data/hora da alteração do perfil.';


--
-- TOC entry 5572 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN tb_perfis.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_perfis.ativo IS 'Flag: ativo/inativo.';


--
-- TOC entry 286 (class 1259 OID 22065)
-- Name: tb_perfis_id_perfil_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_perfis_id_perfil_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_perfis_id_perfil_seq OWNER TO postgres;

--
-- TOC entry 5573 (class 0 OID 0)
-- Dependencies: 286
-- Name: tb_perfis_id_perfil_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_perfis_id_perfil_seq OWNED BY public.tb_perfis.id_perfil;


--
-- TOC entry 283 (class 1259 OID 21993)
-- Name: tb_permissoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_permissoes (
    id_permissao smallint NOT NULL,
    ds_permissao character varying(255) NOT NULL
);


ALTER TABLE public.tb_permissoes OWNER TO postgres;

--
-- TOC entry 5574 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE tb_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_permissoes IS 'Permissões a serem atribuídas a um perfil.';


--
-- TOC entry 5575 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN tb_permissoes.id_permissao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_permissoes.id_permissao IS 'Identificador.';


--
-- TOC entry 5576 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN tb_permissoes.ds_permissao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_permissoes.ds_permissao IS 'Descrição da permissão.';


--
-- TOC entry 282 (class 1259 OID 21991)
-- Name: tb_permissoes_id_permissao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_permissoes_id_permissao_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_permissoes_id_permissao_seq OWNER TO postgres;

--
-- TOC entry 5577 (class 0 OID 0)
-- Dependencies: 282
-- Name: tb_permissoes_id_permissao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_permissoes_id_permissao_seq OWNED BY public.tb_permissoes.id_permissao;


--
-- TOC entry 305 (class 1259 OID 22469)
-- Name: tb_producoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_producoes (
    id_producao integer NOT NULL,
    dt_producao timestamp without time zone NOT NULL,
    quantidade_produzida numeric NOT NULL,
    id_empresa_fornecedora integer NOT NULL
);


ALTER TABLE public.tb_producoes OWNER TO postgres;

--
-- TOC entry 5578 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE tb_producoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_producoes IS 'Produção de biometano.';


--
-- TOC entry 5579 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN tb_producoes.id_producao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_producoes.id_producao IS 'Identificador.';


--
-- TOC entry 5580 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN tb_producoes.dt_producao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_producoes.dt_producao IS 'Data de produção do material.';


--
-- TOC entry 5581 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN tb_producoes.quantidade_produzida; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_producoes.quantidade_produzida IS 'Quantidade de material produzido.';


--
-- TOC entry 5582 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN tb_producoes.id_empresa_fornecedora; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_producoes.id_empresa_fornecedora IS 'Empresa fornecedora da produção.';


--
-- TOC entry 304 (class 1259 OID 22467)
-- Name: tb_producao_id_producao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_producao_id_producao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_producao_id_producao_seq OWNER TO postgres;

--
-- TOC entry 5583 (class 0 OID 0)
-- Dependencies: 304
-- Name: tb_producao_id_producao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_producao_id_producao_seq OWNED BY public.tb_producoes.id_producao;


--
-- TOC entry 343 (class 1259 OID 78023)
-- Name: tb_relatorios_anuais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_relatorios_anuais (
    id_relatorio_anual integer NOT NULL,
    id_compra integer NOT NULL,
    dh_relatorio_anual timestamp without time zone NOT NULL,
    arquivo_relatorio bytea
);


ALTER TABLE public.tb_relatorios_anuais OWNER TO postgres;

--
-- TOC entry 5584 (class 0 OID 0)
-- Dependencies: 343
-- Name: TABLE tb_relatorios_anuais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_relatorios_anuais IS 'Relatórios anuais de entregas.';


--
-- TOC entry 5585 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN tb_relatorios_anuais.id_relatorio_anual; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_relatorios_anuais.id_relatorio_anual IS 'Identificador.';


--
-- TOC entry 5586 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN tb_relatorios_anuais.id_compra; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_relatorios_anuais.id_compra IS 'Compra de biometano.';


--
-- TOC entry 5587 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN tb_relatorios_anuais.dh_relatorio_anual; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_relatorios_anuais.dh_relatorio_anual IS 'Data/hora do relatório.';


--
-- TOC entry 5588 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN tb_relatorios_anuais.arquivo_relatorio; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_relatorios_anuais.arquivo_relatorio IS 'Arquivo contendo o relatório.';


--
-- TOC entry 342 (class 1259 OID 78021)
-- Name: tb_relatorios_anuais_id_relatorio_anual_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_relatorios_anuais_id_relatorio_anual_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_relatorios_anuais_id_relatorio_anual_seq OWNER TO postgres;

--
-- TOC entry 5589 (class 0 OID 0)
-- Dependencies: 342
-- Name: tb_relatorios_anuais_id_relatorio_anual_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_relatorios_anuais_id_relatorio_anual_seq OWNED BY public.tb_relatorios_anuais.id_relatorio_anual;


--
-- TOC entry 297 (class 1259 OID 22247)
-- Name: tb_representantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_representantes (
    id_representante integer NOT NULL,
    cpf character varying(9),
    nome character varying(50),
    id_endereco integer
);


ALTER TABLE public.tb_representantes OWNER TO postgres;

--
-- TOC entry 5590 (class 0 OID 0)
-- Dependencies: 297
-- Name: TABLE tb_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_representantes IS 'Representantes.';


--
-- TOC entry 5591 (class 0 OID 0)
-- Dependencies: 297
-- Name: COLUMN tb_representantes.id_representante; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_representantes.id_representante IS 'Identificador.';


--
-- TOC entry 5592 (class 0 OID 0)
-- Dependencies: 297
-- Name: COLUMN tb_representantes.cpf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_representantes.cpf IS 'Cadastro de Pessoa Física.';


--
-- TOC entry 5593 (class 0 OID 0)
-- Dependencies: 297
-- Name: COLUMN tb_representantes.nome; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_representantes.nome IS 'Nome.';


--
-- TOC entry 5594 (class 0 OID 0)
-- Dependencies: 297
-- Name: COLUMN tb_representantes.id_endereco; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_representantes.id_endereco IS 'Endereço.';


--
-- TOC entry 296 (class 1259 OID 22245)
-- Name: tb_representantes_id_representante_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_representantes_id_representante_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_representantes_id_representante_seq OWNER TO postgres;

--
-- TOC entry 5595 (class 0 OID 0)
-- Dependencies: 296
-- Name: tb_representantes_id_representante_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_representantes_id_representante_seq OWNED BY public.tb_representantes.id_representante;


--
-- TOC entry 285 (class 1259 OID 22026)
-- Name: tb_usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_usuarios (
    id_usuario integer NOT NULL,
    username character varying(30) NOT NULL,
    nome_completo character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    account_non_expired boolean DEFAULT true,
    account_non_locked boolean DEFAULT true,
    credentials_non_expired boolean DEFAULT true,
    enabled boolean DEFAULT true,
    id_perfil smallint,
    id_empresa integer,
    id_usuario_inclusao integer,
    dt_inclusao timestamp without time zone,
    id_usuario_alteracao integer,
    dt_alteracao timestamp without time zone,
    email character varying(50)
);


ALTER TABLE public.tb_usuarios OWNER TO postgres;

--
-- TOC entry 5596 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_usuarios IS 'Usuários do sistema.';


--
-- TOC entry 5597 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.id_usuario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.id_usuario IS 'Identificador.';


--
-- TOC entry 5598 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.username IS 'Login do usuário.';


--
-- TOC entry 5599 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.nome_completo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.nome_completo IS 'Nome completo do usuário.';


--
-- TOC entry 5600 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.password IS 'Senha encriptada do usuário.';


--
-- TOC entry 5601 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.account_non_expired; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.account_non_expired IS 'Flag para conta expirada.';


--
-- TOC entry 5602 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.account_non_locked; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.account_non_locked IS 'Flag para conta bloqueada.';


--
-- TOC entry 5603 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.credentials_non_expired; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.credentials_non_expired IS 'Flag para credenciais expiradas.';


--
-- TOC entry 5604 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.enabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.enabled IS 'Flag para usuário habilitado (ativo).';


--
-- TOC entry 5605 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.id_perfil; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.id_perfil IS 'Perfil do usuário.';


--
-- TOC entry 5606 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.id_empresa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.id_empresa IS 'Empresa a que pertence o usuário.';


--
-- TOC entry 5607 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.id_usuario_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.id_usuario_inclusao IS 'Usuário responsável pela inclusão do usuário.';


--
-- TOC entry 5608 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.dt_inclusao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.dt_inclusao IS 'Data/hora da inclusão do usuário.';


--
-- TOC entry 5609 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.id_usuario_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.id_usuario_alteracao IS 'Usuário responsável pela alteração do usuário.';


--
-- TOC entry 5610 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN tb_usuarios.dt_alteracao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_usuarios.dt_alteracao IS 'Data/hora da alteração do usuário.';


--
-- TOC entry 284 (class 1259 OID 22024)
-- Name: tb_usuarios_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_usuarios_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_usuarios_id_usuario_seq OWNER TO postgres;

--
-- TOC entry 5611 (class 0 OID 0)
-- Dependencies: 284
-- Name: tb_usuarios_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_usuarios_id_usuario_seq OWNED BY public.tb_usuarios.id_usuario;


--
-- TOC entry 4837 (class 2604 OID 22572)
-- Name: tb_autorizacoes id_autorizacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_autorizacoes ALTER COLUMN id_autorizacao SET DEFAULT nextval('public.tb_certificados_id_certificado_seq'::regclass);


--
-- TOC entry 4854 (class 2604 OID 69811)
-- Name: tb_certificados id_certificado; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_certificados ALTER COLUMN id_certificado SET DEFAULT nextval('public.tb_certificados_id_certificado_seq1'::regclass);


--
-- TOC entry 4842 (class 2604 OID 36861)
-- Name: tb_compra_situacoes id_compra_situacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compra_situacoes ALTER COLUMN id_compra_situacao SET DEFAULT nextval('public.tb_compra_situacoes_id_compra_situacao_seq'::regclass);


--
-- TOC entry 4832 (class 2604 OID 22401)
-- Name: tb_compras id_compra; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras ALTER COLUMN id_compra SET DEFAULT nextval('public.tb_compras_id_compra_seq'::regclass);


--
-- TOC entry 4860 (class 2604 OID 86286)
-- Name: tb_contrato_dados id_contrato_dado; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contrato_dados ALTER COLUMN id_contrato_dado SET DEFAULT nextval('public.tb_contrato_dados_id_contrato_dado_seq'::regclass);


--
-- TOC entry 4859 (class 2604 OID 86278)
-- Name: tb_contrato_itens id_contrato_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contrato_itens ALTER COLUMN id_contrato_item SET DEFAULT nextval('public.tb_contrato_itens_id_contrato_item_seq'::regclass);


--
-- TOC entry 4858 (class 2604 OID 86262)
-- Name: tb_contratos id_contrato; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contratos ALTER COLUMN id_contrato SET DEFAULT nextval('public.tb_contratos_id_contrato_seq'::regclass);


--
-- TOC entry 4831 (class 2604 OID 22368)
-- Name: tb_empresa_representantes id_empresa_representante; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_representantes ALTER COLUMN id_empresa_representante SET DEFAULT nextval('public.tb_empresa_representantes_id_empresa_representante_seq'::regclass);


--
-- TOC entry 4829 (class 2604 OID 22168)
-- Name: tb_empresa_situacoes id_empresa_situacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_situacoes ALTER COLUMN id_empresa_situacao SET DEFAULT nextval('public.tb_empresa_situacoes_id_empresa_situacao_seq'::regclass);


--
-- TOC entry 4850 (class 2604 OID 69686)
-- Name: tb_empresa_tipos id_empresa_tipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_tipos ALTER COLUMN id_empresa_tipo SET DEFAULT nextval('public.tb_empresa_tipos_id_empresa_tipo_seq'::regclass);


--
-- TOC entry 4828 (class 2604 OID 22152)
-- Name: tb_empresas id_empresa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas ALTER COLUMN id_empresa SET DEFAULT nextval('public.tb_empresas_id_empresa_seq'::regclass);


--
-- TOC entry 4827 (class 2604 OID 22131)
-- Name: tb_enderecos id_endereco; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_enderecos ALTER COLUMN id_endereco SET DEFAULT nextval('public.tb_enderecos_id_endereco_seq'::regclass);


--
-- TOC entry 4848 (class 2604 OID 61498)
-- Name: tb_entregas_sazonais id_entrega_sazonal; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_entregas_sazonais ALTER COLUMN id_entrega_sazonal SET DEFAULT nextval('public.tb_entregas_sazonais_id_entrega_sazonal_seq'::regclass);


--
-- TOC entry 4849 (class 2604 OID 69668)
-- Name: tb_frete_tipos id_frete_tipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_frete_tipos ALTER COLUMN id_frete_tipo SET DEFAULT nextval('public.tb_frete_tipos_id_frete_tipo_seq'::regclass);


--
-- TOC entry 4833 (class 2604 OID 22414)
-- Name: tb_locais id_local; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_locais ALTER COLUMN id_local SET DEFAULT nextval('public.tb_locais_id_local_seq'::regclass);


--
-- TOC entry 4857 (class 2604 OID 86239)
-- Name: tb_logistica_coletas id_logistica_coleta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_coletas ALTER COLUMN id_logistica_coleta SET DEFAULT nextval('public.tb_logistica_coletas_id_logistica_coleta_seq'::regclass);


--
-- TOC entry 4839 (class 2604 OID 22637)
-- Name: tb_logistica_compras id_logistica_compra; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_compras ALTER COLUMN id_logistica_compra SET DEFAULT nextval('public.tb_logistica_compras_id_logistica_compra_seq'::regclass);


--
-- TOC entry 4856 (class 2604 OID 86218)
-- Name: tb_logistica_dutos id_logistica_duto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_dutos ALTER COLUMN id_logistica_duto SET DEFAULT nextval('public.tb_logistica_dutos_id_logistica_duto_seq'::regclass);


--
-- TOC entry 4838 (class 2604 OID 22590)
-- Name: tb_logisticas id_logistica; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logisticas ALTER COLUMN id_logistica SET DEFAULT nextval('public.tb_logisticas_id_logistica_seq'::regclass);


--
-- TOC entry 4845 (class 2604 OID 61457)
-- Name: tb_negociacao_itens id_negociacao_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_itens ALTER COLUMN id_negociacao_item SET DEFAULT nextval('public.tb_negociacao_itens_id_negociacao_item_seq'::regclass);


--
-- TOC entry 4853 (class 2604 OID 69762)
-- Name: tb_negociacao_propostas id_negociacao_proposta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_propostas ALTER COLUMN id_negociacao_proposta SET DEFAULT nextval('public.tb_negociacao_propostas_id_negociacao_proposta_seq'::regclass);


--
-- TOC entry 4851 (class 2604 OID 69699)
-- Name: tb_negociacao_rodadas id_negociacao_rodada; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas ALTER COLUMN id_negociacao_rodada SET DEFAULT nextval('public.tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq'::regclass);


--
-- TOC entry 4846 (class 2604 OID 61465)
-- Name: tb_negociacao_rodadas_antiga id_negociacao_rodada; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas_antiga ALTER COLUMN id_negociacao_rodada SET DEFAULT nextval('public.tb_negociacao_rodadas_id_negociacao_rodada_seq'::regclass);


--
-- TOC entry 4844 (class 2604 OID 53232)
-- Name: tb_noticia_situacoes id_noticia_situacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticia_situacoes ALTER COLUMN id_noticia_situacao SET DEFAULT nextval('public.tb_noticia_situacoes_id_noticia_situacao_seq'::regclass);


--
-- TOC entry 4836 (class 2604 OID 22545)
-- Name: tb_noticias id_noticia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticias ALTER COLUMN id_noticia SET DEFAULT nextval('public.tb_noticias_id_noticia_seq'::regclass);


--
-- TOC entry 4841 (class 2604 OID 36848)
-- Name: tb_oferta_situacoes id_oferta_situacao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_oferta_situacoes ALTER COLUMN id_oferta_situacao SET DEFAULT nextval('public.tb_oferta_situacoes_id_oferta_situacao_seq'::regclass);


--
-- TOC entry 4843 (class 2604 OID 45040)
-- Name: tb_oferta_tipos id_oferta_tipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_oferta_tipos ALTER COLUMN id_oferta_tipo SET DEFAULT nextval('public.tb_oferta_tipos_id_oferta_tipo_seq'::regclass);


--
-- TOC entry 4835 (class 2604 OID 22493)
-- Name: tb_ofertas id_oferta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas ALTER COLUMN id_oferta SET DEFAULT nextval('public.tb_ofertas_id_oferta_seq'::regclass);


--
-- TOC entry 4826 (class 2604 OID 22110)
-- Name: tb_perfil_permissoes id_perfil_permissao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfil_permissoes ALTER COLUMN id_perfil_permissao SET DEFAULT nextval('public.tb_perfil_permissoes_id_perfil_permissao_seq'::regclass);


--
-- TOC entry 4825 (class 2604 OID 22070)
-- Name: tb_perfis id_perfil; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfis ALTER COLUMN id_perfil SET DEFAULT nextval('public.tb_perfis_id_perfil_seq'::regclass);


--
-- TOC entry 4819 (class 2604 OID 21996)
-- Name: tb_permissoes id_permissao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_permissoes ALTER COLUMN id_permissao SET DEFAULT nextval('public.tb_permissoes_id_permissao_seq'::regclass);


--
-- TOC entry 4834 (class 2604 OID 22472)
-- Name: tb_producoes id_producao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_producoes ALTER COLUMN id_producao SET DEFAULT nextval('public.tb_producao_id_producao_seq'::regclass);


--
-- TOC entry 4855 (class 2604 OID 78026)
-- Name: tb_relatorios_anuais id_relatorio_anual; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_relatorios_anuais ALTER COLUMN id_relatorio_anual SET DEFAULT nextval('public.tb_relatorios_anuais_id_relatorio_anual_seq'::regclass);


--
-- TOC entry 4830 (class 2604 OID 22250)
-- Name: tb_representantes id_representante; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_representantes ALTER COLUMN id_representante SET DEFAULT nextval('public.tb_representantes_id_representante_seq'::regclass);


--
-- TOC entry 4820 (class 2604 OID 22029)
-- Name: tb_usuarios id_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios ALTER COLUMN id_usuario SET DEFAULT nextval('public.tb_usuarios_id_usuario_seq'::regclass);


--
-- TOC entry 4747 (class 0 OID 19975)
-- Dependencies: 211
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- TOC entry 5286 (class 0 OID 22569)
-- Dependencies: 311
-- Data for Name: tb_autorizacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_autorizacoes (id_autorizacao, dt_autorizacao, dt_validade, id_empresa_autorizada) FROM stdin;
\.


--
-- TOC entry 5316 (class 0 OID 69808)
-- Dependencies: 341
-- Data for Name: tb_certificados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_certificados (id_certificado, id_empresa, quantidade, equivalencia, id_empresa_certificadora, nm_certificado) FROM stdin;
\.


--
-- TOC entry 5296 (class 0 OID 36858)
-- Dependencies: 321
-- Data for Name: tb_compra_situacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_compra_situacoes (id_compra_situacao, ds_compra_situacao) FROM stdin;
\.


--
-- TOC entry 5276 (class 0 OID 22398)
-- Dependencies: 301
-- Data for Name: tb_compras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_compras (id_compra, id_empresa_compradora, sazonalidade, id_local_entrega, id_local_retirada, quantidade_comprada, valor_compra, id_empresa_fornecedora, id_compra_situacao, id_compra_aditivada, id_oferta, flexibilidade, id_frete_tipo, dt_inicio_entrega, dt_fim_entrega, quantidade_certificados, valor_certificados) FROM stdin;
\.


--
-- TOC entry 5328 (class 0 OID 86283)
-- Dependencies: 353
-- Data for Name: tb_contrato_dados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_contrato_dados (id_contrato_dado, id_contrato, id_contrato_item, valor_contrato_dado) FROM stdin;
\.


--
-- TOC entry 5326 (class 0 OID 86275)
-- Dependencies: 351
-- Data for Name: tb_contrato_itens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_contrato_itens (id_contrato_item, ds_contrato_item) FROM stdin;
\.


--
-- TOC entry 5324 (class 0 OID 86259)
-- Dependencies: 349
-- Data for Name: tb_contratos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_contratos (id_contrato, id_compra, documento) FROM stdin;
\.


--
-- TOC entry 5274 (class 0 OID 22365)
-- Dependencies: 299
-- Data for Name: tb_empresa_representantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_empresa_representantes (id_empresa_representante, id_empresa, id_representante, id_usuario_inclusao, dt_inclusao, id_usuario_alteracao, dt_alteracao, ativo) FROM stdin;
\.


--
-- TOC entry 5270 (class 0 OID 22165)
-- Dependencies: 295
-- Data for Name: tb_empresa_situacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_empresa_situacoes (id_empresa_situacao, ds_empresa_situacao) FROM stdin;
\.


--
-- TOC entry 5310 (class 0 OID 69683)
-- Dependencies: 335
-- Data for Name: tb_empresa_tipos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_empresa_tipos (id_empresa_tipo, ds_empresa_tipo) FROM stdin;
\.


--
-- TOC entry 5268 (class 0 OID 22149)
-- Dependencies: 293
-- Data for Name: tb_empresas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_empresas (id_empresa, cnpj, razao_social, nome_fantasia, id_endereco, inscricao_estadual, inscricao_municipal, nicho_mercado, servicos_produtos, port_empr, id_empresa_situacao, id_usuario_inclusao, id_usuario_alteracao, dt_inclusao, dt_alteracao, area_atuacao_rodoviaria, id_empresa_tipo, area_atuacao_dutos) FROM stdin;
\.


--
-- TOC entry 5266 (class 0 OID 22128)
-- Dependencies: 291
-- Data for Name: tb_enderecos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_enderecos (id_endereco, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, telefone, email, the_geom) FROM stdin;
\.


--
-- TOC entry 5306 (class 0 OID 61495)
-- Dependencies: 331
-- Data for Name: tb_entregas_sazonais; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_entregas_sazonais (id_entrega_sazonal, id_negociacao_rodada, mes_entrega, valor_mes) FROM stdin;
\.


--
-- TOC entry 5308 (class 0 OID 69665)
-- Dependencies: 333
-- Data for Name: tb_frete_tipos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_frete_tipos (id_frete_tipo, sg_frete_tipo, ds_frete_tipo) FROM stdin;
\.


--
-- TOC entry 5278 (class 0 OID 22411)
-- Dependencies: 303
-- Data for Name: tb_locais; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_locais (id_local, ds_local, id_endereco, nm_local, id_empresa) FROM stdin;
\.


--
-- TOC entry 5322 (class 0 OID 86236)
-- Dependencies: 347
-- Data for Name: tb_logistica_coletas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_logistica_coletas (id_logistica_coleta, entrada, id_endereco, id_logistica, id_empresa) FROM stdin;
\.


--
-- TOC entry 5290 (class 0 OID 22634)
-- Dependencies: 315
-- Data for Name: tb_logistica_compras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_logistica_compras (id_logistica_compra, id_compra, id_logistica, valor_logistica) FROM stdin;
\.


--
-- TOC entry 5320 (class 0 OID 86215)
-- Dependencies: 345
-- Data for Name: tb_logistica_dutos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_logistica_dutos (id_logistica_duto, nome_duto, diametro_duto, id_logistica, id_empresa, the_geom) FROM stdin;
\.


--
-- TOC entry 5288 (class 0 OID 22587)
-- Dependencies: 313
-- Data for Name: tb_logisticas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_logisticas (id_logistica, tipo_transporte, id_empresa_transportadora) FROM stdin;
\.


--
-- TOC entry 5302 (class 0 OID 61454)
-- Dependencies: 327
-- Data for Name: tb_negociacao_itens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_negociacao_itens (id_negociacao_item, ds_negociacao_item) FROM stdin;
\.


--
-- TOC entry 5314 (class 0 OID 69759)
-- Dependencies: 339
-- Data for Name: tb_negociacao_propostas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_negociacao_propostas (id_negociacao_proposta, id_negociacao_rodada, id_negociacao_item, valor_proposto) FROM stdin;
\.


--
-- TOC entry 5312 (class 0 OID 69696)
-- Dependencies: 337
-- Data for Name: tb_negociacao_rodadas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_negociacao_rodadas (id_negociacao_rodada, id_oferta, nr_rodada, dh_rodada, observacao, finalizada, id_empresa_proponente, id_negociacao_rodada_anterior) FROM stdin;
\.


--
-- TOC entry 5304 (class 0 OID 61462)
-- Dependencies: 329
-- Data for Name: tb_negociacao_rodadas_antiga; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_negociacao_rodadas_antiga (id_negociacao_rodada, id_oferta, id_negociacao_item, valor_proposto, dh_rodada, id_empresa_proponente, id_negociacao_rodada_anterior, observacao, finalizada, nr_rodada) FROM stdin;
\.


--
-- TOC entry 5300 (class 0 OID 53229)
-- Dependencies: 325
-- Data for Name: tb_noticia_situacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_noticia_situacoes (id_noticia_situacao, ds_noticia_situacao) FROM stdin;
\.


--
-- TOC entry 5284 (class 0 OID 22542)
-- Dependencies: 309
-- Data for Name: tb_noticias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_noticias (id_noticia, dt_noticia, texto_noticia, id_empresa, id_noticia_situacao, id_usuario_inclusao, dt_inclusao, id_usuario_alteracao, dt_alteracao, titulo_noticia) FROM stdin;
\.


--
-- TOC entry 5294 (class 0 OID 36845)
-- Dependencies: 319
-- Data for Name: tb_oferta_situacoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_oferta_situacoes (id_oferta_situacao, ds_oferta_situacao) FROM stdin;
\.


--
-- TOC entry 5298 (class 0 OID 45037)
-- Dependencies: 323
-- Data for Name: tb_oferta_tipos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_oferta_tipos (id_oferta_tipo, ds_oferta_tipo) FROM stdin;
\.


--
-- TOC entry 5282 (class 0 OID 22490)
-- Dependencies: 307
-- Data for Name: tb_ofertas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_ofertas (id_oferta, dt_oferta, quantidade_ofertada, id_empresa, id_oferta_situacao, id_oferta_tipo, dt_validade, id_empresa_privada, compra_venda, id_certificado, quantidade_certificados, exibe_nome_empresa) FROM stdin;
\.


--
-- TOC entry 5264 (class 0 OID 22107)
-- Dependencies: 289
-- Data for Name: tb_perfil_permissoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_perfil_permissoes (id_perfil_permissao, id_perfil, id_permissao) FROM stdin;
\.


--
-- TOC entry 5262 (class 0 OID 22067)
-- Dependencies: 287
-- Data for Name: tb_perfis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_perfis (id_perfil, nome_perfil, ds_perfil, id_usuario_inclusao, dt_inclusao, id_usuario_alteracao, dt_alteracao, ativo) FROM stdin;
\.


--
-- TOC entry 5258 (class 0 OID 21993)
-- Dependencies: 283
-- Data for Name: tb_permissoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_permissoes (id_permissao, ds_permissao) FROM stdin;
\.


--
-- TOC entry 5280 (class 0 OID 22469)
-- Dependencies: 305
-- Data for Name: tb_producoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_producoes (id_producao, dt_producao, quantidade_produzida, id_empresa_fornecedora) FROM stdin;
\.


--
-- TOC entry 5318 (class 0 OID 78023)
-- Dependencies: 343
-- Data for Name: tb_relatorios_anuais; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_relatorios_anuais (id_relatorio_anual, id_compra, dh_relatorio_anual, arquivo_relatorio) FROM stdin;
\.


--
-- TOC entry 5272 (class 0 OID 22247)
-- Dependencies: 297
-- Data for Name: tb_representantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_representantes (id_representante, cpf, nome, id_endereco) FROM stdin;
\.


--
-- TOC entry 5260 (class 0 OID 22026)
-- Dependencies: 285
-- Data for Name: tb_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_usuarios (id_usuario, username, nome_completo, password, account_non_expired, account_non_locked, credentials_non_expired, enabled, id_perfil, id_empresa, id_usuario_inclusao, dt_inclusao, id_usuario_alteracao, dt_alteracao, email) FROM stdin;
\.


--
-- TOC entry 4750 (class 0 OID 21436)
-- Dependencies: 232
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- TOC entry 4751 (class 0 OID 21799)
-- Dependencies: 277
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- TOC entry 4752 (class 0 OID 21811)
-- Dependencies: 279
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- TOC entry 4753 (class 0 OID 21823)
-- Dependencies: 281
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- TOC entry 4748 (class 0 OID 21258)
-- Dependencies: 226
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- TOC entry 4749 (class 0 OID 21271)
-- Dependencies: 227
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- TOC entry 5612 (class 0 OID 0)
-- Dependencies: 317
-- Name: br_municipios_ogc_fid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.br_municipios_ogc_fid_seq', 1, false);


--
-- TOC entry 5613 (class 0 OID 0)
-- Dependencies: 310
-- Name: tb_certificados_id_certificado_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_certificados_id_certificado_seq', 1, false);


--
-- TOC entry 5614 (class 0 OID 0)
-- Dependencies: 340
-- Name: tb_certificados_id_certificado_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_certificados_id_certificado_seq1', 1, false);


--
-- TOC entry 5615 (class 0 OID 0)
-- Dependencies: 320
-- Name: tb_compra_situacoes_id_compra_situacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_compra_situacoes_id_compra_situacao_seq', 1, false);


--
-- TOC entry 5616 (class 0 OID 0)
-- Dependencies: 300
-- Name: tb_compras_id_compra_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_compras_id_compra_seq', 1, false);


--
-- TOC entry 5617 (class 0 OID 0)
-- Dependencies: 352
-- Name: tb_contrato_dados_id_contrato_dado_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_contrato_dados_id_contrato_dado_seq', 1, false);


--
-- TOC entry 5618 (class 0 OID 0)
-- Dependencies: 350
-- Name: tb_contrato_itens_id_contrato_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_contrato_itens_id_contrato_item_seq', 1, false);


--
-- TOC entry 5619 (class 0 OID 0)
-- Dependencies: 348
-- Name: tb_contratos_id_contrato_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_contratos_id_contrato_seq', 1, false);


--
-- TOC entry 5620 (class 0 OID 0)
-- Dependencies: 298
-- Name: tb_empresa_representantes_id_empresa_representante_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_empresa_representantes_id_empresa_representante_seq', 1, false);


--
-- TOC entry 5621 (class 0 OID 0)
-- Dependencies: 294
-- Name: tb_empresa_situacoes_id_empresa_situacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_empresa_situacoes_id_empresa_situacao_seq', 1, false);


--
-- TOC entry 5622 (class 0 OID 0)
-- Dependencies: 334
-- Name: tb_empresa_tipos_id_empresa_tipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_empresa_tipos_id_empresa_tipo_seq', 1, false);


--
-- TOC entry 5623 (class 0 OID 0)
-- Dependencies: 292
-- Name: tb_empresas_id_empresa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_empresas_id_empresa_seq', 1, false);


--
-- TOC entry 5624 (class 0 OID 0)
-- Dependencies: 290
-- Name: tb_enderecos_id_endereco_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_enderecos_id_endereco_seq', 1, false);


--
-- TOC entry 5625 (class 0 OID 0)
-- Dependencies: 330
-- Name: tb_entregas_sazonais_id_entrega_sazonal_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_entregas_sazonais_id_entrega_sazonal_seq', 1, false);


--
-- TOC entry 5626 (class 0 OID 0)
-- Dependencies: 332
-- Name: tb_frete_tipos_id_frete_tipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_frete_tipos_id_frete_tipo_seq', 1, false);


--
-- TOC entry 5627 (class 0 OID 0)
-- Dependencies: 302
-- Name: tb_locais_id_local_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_locais_id_local_seq', 1, false);


--
-- TOC entry 5628 (class 0 OID 0)
-- Dependencies: 346
-- Name: tb_logistica_coletas_id_logistica_coleta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_logistica_coletas_id_logistica_coleta_seq', 1, false);


--
-- TOC entry 5629 (class 0 OID 0)
-- Dependencies: 314
-- Name: tb_logistica_compras_id_logistica_compra_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_logistica_compras_id_logistica_compra_seq', 1, false);


--
-- TOC entry 5630 (class 0 OID 0)
-- Dependencies: 344
-- Name: tb_logistica_dutos_id_logistica_duto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_logistica_dutos_id_logistica_duto_seq', 1, false);


--
-- TOC entry 5631 (class 0 OID 0)
-- Dependencies: 312
-- Name: tb_logisticas_id_logistica_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_logisticas_id_logistica_seq', 1, false);


--
-- TOC entry 5632 (class 0 OID 0)
-- Dependencies: 326
-- Name: tb_negociacao_itens_id_negociacao_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_negociacao_itens_id_negociacao_item_seq', 1, false);


--
-- TOC entry 5633 (class 0 OID 0)
-- Dependencies: 338
-- Name: tb_negociacao_propostas_id_negociacao_proposta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_negociacao_propostas_id_negociacao_proposta_seq', 1, false);


--
-- TOC entry 5634 (class 0 OID 0)
-- Dependencies: 328
-- Name: tb_negociacao_rodadas_id_negociacao_rodada_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_negociacao_rodadas_id_negociacao_rodada_seq', 1, false);


--
-- TOC entry 5635 (class 0 OID 0)
-- Dependencies: 336
-- Name: tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_negociacao_rodadas_nova_id_negociacao_rodada_nova_seq', 1, false);


--
-- TOC entry 5636 (class 0 OID 0)
-- Dependencies: 324
-- Name: tb_noticia_situacoes_id_noticia_situacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_noticia_situacoes_id_noticia_situacao_seq', 1, false);


--
-- TOC entry 5637 (class 0 OID 0)
-- Dependencies: 308
-- Name: tb_noticias_id_noticia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_noticias_id_noticia_seq', 1, false);


--
-- TOC entry 5638 (class 0 OID 0)
-- Dependencies: 318
-- Name: tb_oferta_situacoes_id_oferta_situacao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_oferta_situacoes_id_oferta_situacao_seq', 1, false);


--
-- TOC entry 5639 (class 0 OID 0)
-- Dependencies: 322
-- Name: tb_oferta_tipos_id_oferta_tipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_oferta_tipos_id_oferta_tipo_seq', 1, false);


--
-- TOC entry 5640 (class 0 OID 0)
-- Dependencies: 306
-- Name: tb_ofertas_id_oferta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_ofertas_id_oferta_seq', 1, false);


--
-- TOC entry 5641 (class 0 OID 0)
-- Dependencies: 288
-- Name: tb_perfil_permissoes_id_perfil_permissao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_perfil_permissoes_id_perfil_permissao_seq', 1, false);


--
-- TOC entry 5642 (class 0 OID 0)
-- Dependencies: 286
-- Name: tb_perfis_id_perfil_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_perfis_id_perfil_seq', 1, false);


--
-- TOC entry 5643 (class 0 OID 0)
-- Dependencies: 282
-- Name: tb_permissoes_id_permissao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_permissoes_id_permissao_seq', 1, false);


--
-- TOC entry 5644 (class 0 OID 0)
-- Dependencies: 304
-- Name: tb_producao_id_producao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_producao_id_producao_seq', 1, false);


--
-- TOC entry 5645 (class 0 OID 0)
-- Dependencies: 342
-- Name: tb_relatorios_anuais_id_relatorio_anual_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_relatorios_anuais_id_relatorio_anual_seq', 1, false);


--
-- TOC entry 5646 (class 0 OID 0)
-- Dependencies: 296
-- Name: tb_representantes_id_representante_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_representantes_id_representante_seq', 1, false);


--
-- TOC entry 5647 (class 0 OID 0)
-- Dependencies: 284
-- Name: tb_usuarios_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_usuarios_id_usuario_seq', 1, false);


--
-- TOC entry 5018 (class 2606 OID 22574)
-- Name: tb_autorizacoes pk_autorizacoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_autorizacoes
    ADD CONSTRAINT pk_autorizacoes PRIMARY KEY (id_autorizacao);


--
-- TOC entry 5648 (class 0 OID 0)
-- Dependencies: 5018
-- Name: CONSTRAINT pk_autorizacoes ON tb_autorizacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_autorizacoes ON public.tb_autorizacoes IS 'Chave primária da tabela tb_certificados.';


--
-- TOC entry 5048 (class 2606 OID 69813)
-- Name: tb_certificados pk_certificados; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_certificados
    ADD CONSTRAINT pk_certificados PRIMARY KEY (id_certificado);


--
-- TOC entry 5649 (class 0 OID 0)
-- Dependencies: 5048
-- Name: CONSTRAINT pk_certificados ON tb_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_certificados ON public.tb_certificados IS 'Chave primária da tabela tb_certificados.';


--
-- TOC entry 5022 (class 2606 OID 22642)
-- Name: tb_logistica_compras pk_compra_logisticas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_compras
    ADD CONSTRAINT pk_compra_logisticas PRIMARY KEY (id_logistica_compra);


--
-- TOC entry 5650 (class 0 OID 0)
-- Dependencies: 5022
-- Name: CONSTRAINT pk_compra_logisticas ON tb_logistica_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_compra_logisticas ON public.tb_logistica_compras IS 'Chave primária da tabela tb_compra_logisticas.';


--
-- TOC entry 5028 (class 2606 OID 36863)
-- Name: tb_compra_situacoes pk_compra_situacoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compra_situacoes
    ADD CONSTRAINT pk_compra_situacoes PRIMARY KEY (id_compra_situacao);


--
-- TOC entry 5651 (class 0 OID 0)
-- Dependencies: 5028
-- Name: CONSTRAINT pk_compra_situacoes ON tb_compra_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_compra_situacoes ON public.tb_compra_situacoes IS 'Chave primária da tabela tb_compra_situacoes.';


--
-- TOC entry 5008 (class 2606 OID 22403)
-- Name: tb_compras pk_compras; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT pk_compras PRIMARY KEY (id_compra);


--
-- TOC entry 5652 (class 0 OID 0)
-- Dependencies: 5008
-- Name: CONSTRAINT pk_compras ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_compras ON public.tb_compras IS 'Chave primária da tabela tb_compras.';


--
-- TOC entry 5060 (class 2606 OID 86291)
-- Name: tb_contrato_dados pk_contrato_dado; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contrato_dados
    ADD CONSTRAINT pk_contrato_dado PRIMARY KEY (id_contrato_dado);


--
-- TOC entry 5653 (class 0 OID 0)
-- Dependencies: 5060
-- Name: CONSTRAINT pk_contrato_dado ON tb_contrato_dados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_contrato_dado ON public.tb_contrato_dados IS 'Chave primária da tabela tb_contrato_dados.';


--
-- TOC entry 5058 (class 2606 OID 86280)
-- Name: tb_contrato_itens pk_contrato_itens; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contrato_itens
    ADD CONSTRAINT pk_contrato_itens PRIMARY KEY (id_contrato_item);


--
-- TOC entry 5654 (class 0 OID 0)
-- Dependencies: 5058
-- Name: CONSTRAINT pk_contrato_itens ON tb_contrato_itens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_contrato_itens ON public.tb_contrato_itens IS 'Chave primária da tabela tb_contrato_itens.';


--
-- TOC entry 5056 (class 2606 OID 86267)
-- Name: tb_contratos pk_contratos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contratos
    ADD CONSTRAINT pk_contratos PRIMARY KEY (id_contrato);


--
-- TOC entry 5655 (class 0 OID 0)
-- Dependencies: 5056
-- Name: CONSTRAINT pk_contratos ON tb_contratos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_contratos ON public.tb_contratos IS 'Chave primária da tabela tb_contratos.';


--
-- TOC entry 5006 (class 2606 OID 22370)
-- Name: tb_empresa_representantes pk_empresa_representantes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_representantes
    ADD CONSTRAINT pk_empresa_representantes PRIMARY KEY (id_empresa_representante);


--
-- TOC entry 5656 (class 0 OID 0)
-- Dependencies: 5006
-- Name: CONSTRAINT pk_empresa_representantes ON tb_empresa_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_empresa_representantes ON public.tb_empresa_representantes IS 'Chave primária da tabela tb_empresa_representantes.';


--
-- TOC entry 5002 (class 2606 OID 22170)
-- Name: tb_empresa_situacoes pk_empresa_situacoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_situacoes
    ADD CONSTRAINT pk_empresa_situacoes PRIMARY KEY (id_empresa_situacao);


--
-- TOC entry 5657 (class 0 OID 0)
-- Dependencies: 5002
-- Name: CONSTRAINT pk_empresa_situacoes ON tb_empresa_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_empresa_situacoes ON public.tb_empresa_situacoes IS 'Chave primária da tabela tb_empresa_situacoes.';


--
-- TOC entry 5042 (class 2606 OID 69688)
-- Name: tb_empresa_tipos pk_empresa_tipos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_tipos
    ADD CONSTRAINT pk_empresa_tipos PRIMARY KEY (id_empresa_tipo);


--
-- TOC entry 5658 (class 0 OID 0)
-- Dependencies: 5042
-- Name: CONSTRAINT pk_empresa_tipos ON tb_empresa_tipos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_empresa_tipos ON public.tb_empresa_tipos IS 'Chave primária da tabela tb_empresa_tipos.';


--
-- TOC entry 5000 (class 2606 OID 22154)
-- Name: tb_empresas pk_empresas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas
    ADD CONSTRAINT pk_empresas PRIMARY KEY (id_empresa);


--
-- TOC entry 5659 (class 0 OID 0)
-- Dependencies: 5000
-- Name: CONSTRAINT pk_empresas ON tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_empresas ON public.tb_empresas IS 'Chave primária da tabela tb_empresas.';


--
-- TOC entry 4998 (class 2606 OID 22136)
-- Name: tb_enderecos pk_enderecos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_enderecos
    ADD CONSTRAINT pk_enderecos PRIMARY KEY (id_endereco);


--
-- TOC entry 5660 (class 0 OID 0)
-- Dependencies: 4998
-- Name: CONSTRAINT pk_enderecos ON tb_enderecos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_enderecos ON public.tb_enderecos IS 'Chave primária da tabela tb_enderecos.';


--
-- TOC entry 5038 (class 2606 OID 61503)
-- Name: tb_entregas_sazonais pk_entregas_sazonais; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_entregas_sazonais
    ADD CONSTRAINT pk_entregas_sazonais PRIMARY KEY (id_entrega_sazonal);


--
-- TOC entry 5661 (class 0 OID 0)
-- Dependencies: 5038
-- Name: CONSTRAINT pk_entregas_sazonais ON tb_entregas_sazonais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_entregas_sazonais ON public.tb_entregas_sazonais IS 'Chave primária da tabela tb_entregas_sazonais.';


--
-- TOC entry 5040 (class 2606 OID 69670)
-- Name: tb_frete_tipos pk_frete_tipos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_frete_tipos
    ADD CONSTRAINT pk_frete_tipos PRIMARY KEY (id_frete_tipo);


--
-- TOC entry 5662 (class 0 OID 0)
-- Dependencies: 5040
-- Name: CONSTRAINT pk_frete_tipos ON tb_frete_tipos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_frete_tipos ON public.tb_frete_tipos IS 'Chave primária da tabela tb_frete_tipos.';


--
-- TOC entry 5010 (class 2606 OID 22416)
-- Name: tb_locais pk_local; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_locais
    ADD CONSTRAINT pk_local PRIMARY KEY (id_local);


--
-- TOC entry 5663 (class 0 OID 0)
-- Dependencies: 5010
-- Name: CONSTRAINT pk_local ON tb_locais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_local ON public.tb_locais IS 'Chave primária da tabela tb_locais.';


--
-- TOC entry 5054 (class 2606 OID 86241)
-- Name: tb_logistica_coletas pk_logistica_coletas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_coletas
    ADD CONSTRAINT pk_logistica_coletas PRIMARY KEY (id_logistica_coleta);


--
-- TOC entry 5664 (class 0 OID 0)
-- Dependencies: 5054
-- Name: CONSTRAINT pk_logistica_coletas ON tb_logistica_coletas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_logistica_coletas ON public.tb_logistica_coletas IS 'Chave primária da tabela tb_logistica_coletas.';


--
-- TOC entry 5052 (class 2606 OID 86223)
-- Name: tb_logistica_dutos pk_logistica_dutos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_dutos
    ADD CONSTRAINT pk_logistica_dutos PRIMARY KEY (id_logistica_duto);


--
-- TOC entry 5665 (class 0 OID 0)
-- Dependencies: 5052
-- Name: CONSTRAINT pk_logistica_dutos ON tb_logistica_dutos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_logistica_dutos ON public.tb_logistica_dutos IS 'Chave primária da tabela tb_logistica_dutos.';


--
-- TOC entry 5020 (class 2606 OID 22592)
-- Name: tb_logisticas pk_logisticas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logisticas
    ADD CONSTRAINT pk_logisticas PRIMARY KEY (id_logistica);


--
-- TOC entry 5666 (class 0 OID 0)
-- Dependencies: 5020
-- Name: CONSTRAINT pk_logisticas ON tb_logisticas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_logisticas ON public.tb_logisticas IS 'Chave primária da tabela tb_logisticas.';


--
-- TOC entry 5034 (class 2606 OID 61459)
-- Name: tb_negociacao_itens pk_negociacao_itens; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_itens
    ADD CONSTRAINT pk_negociacao_itens PRIMARY KEY (id_negociacao_item);


--
-- TOC entry 5668 (class 0 OID 0)
-- Dependencies: 5034
-- Name: CONSTRAINT pk_negociacao_itens ON tb_negociacao_itens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_negociacao_itens ON public.tb_negociacao_itens IS 'Chave primária da tabela tb_negociacao_itens.';


--
-- TOC entry 5046 (class 2606 OID 69764)
-- Name: tb_negociacao_propostas pk_negociacao_proposta; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_propostas
    ADD CONSTRAINT pk_negociacao_proposta PRIMARY KEY (id_negociacao_proposta);


--
-- TOC entry 5669 (class 0 OID 0)
-- Dependencies: 5046
-- Name: CONSTRAINT pk_negociacao_proposta ON tb_negociacao_propostas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_negociacao_proposta ON public.tb_negociacao_propostas IS 'Chave primária da tabela tb_negociacao_proposta.';


--
-- TOC entry 5036 (class 2606 OID 61487)
-- Name: tb_negociacao_rodadas_antiga pk_negociacao_rodadas; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas_antiga
    ADD CONSTRAINT pk_negociacao_rodadas PRIMARY KEY (id_negociacao_rodada);


--
-- TOC entry 5044 (class 2606 OID 69705)
-- Name: tb_negociacao_rodadas pk_negociacao_rodadas_nova; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas
    ADD CONSTRAINT pk_negociacao_rodadas_nova PRIMARY KEY (id_negociacao_rodada);


--
-- TOC entry 5670 (class 0 OID 0)
-- Dependencies: 5044
-- Name: CONSTRAINT pk_negociacao_rodadas_nova ON tb_negociacao_rodadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_negociacao_rodadas_nova ON public.tb_negociacao_rodadas IS 'Chave primária da tabela tb_negociacao_rodadas_nova.';


--
-- TOC entry 5032 (class 2606 OID 53234)
-- Name: tb_noticia_situacoes pk_noticia_situacoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticia_situacoes
    ADD CONSTRAINT pk_noticia_situacoes PRIMARY KEY (id_noticia_situacao);


--
-- TOC entry 5671 (class 0 OID 0)
-- Dependencies: 5032
-- Name: CONSTRAINT pk_noticia_situacoes ON tb_noticia_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_noticia_situacoes ON public.tb_noticia_situacoes IS 'Chave primária da tabela tb_noticia_situacoes.';


--
-- TOC entry 5016 (class 2606 OID 22547)
-- Name: tb_noticias pk_noticias; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticias
    ADD CONSTRAINT pk_noticias PRIMARY KEY (id_noticia);


--
-- TOC entry 5672 (class 0 OID 0)
-- Dependencies: 5016
-- Name: CONSTRAINT pk_noticias ON tb_noticias; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_noticias ON public.tb_noticias IS 'Chave primária da tabela tb_noticias.';


--
-- TOC entry 5014 (class 2606 OID 22495)
-- Name: tb_ofertas pk_oferta; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas
    ADD CONSTRAINT pk_oferta PRIMARY KEY (id_oferta);


--
-- TOC entry 5673 (class 0 OID 0)
-- Dependencies: 5014
-- Name: CONSTRAINT pk_oferta ON tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_oferta ON public.tb_ofertas IS 'Chave primária da tabela tb_ofertas.';


--
-- TOC entry 5026 (class 2606 OID 36850)
-- Name: tb_oferta_situacoes pk_oferta_situacoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_oferta_situacoes
    ADD CONSTRAINT pk_oferta_situacoes PRIMARY KEY (id_oferta_situacao);


--
-- TOC entry 5674 (class 0 OID 0)
-- Dependencies: 5026
-- Name: CONSTRAINT pk_oferta_situacoes ON tb_oferta_situacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_oferta_situacoes ON public.tb_oferta_situacoes IS 'Chave primária da tabela tb_oferta_situacoes.';


--
-- TOC entry 5030 (class 2606 OID 45042)
-- Name: tb_oferta_tipos pk_oferta_tipos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_oferta_tipos
    ADD CONSTRAINT pk_oferta_tipos PRIMARY KEY (id_oferta_tipo);


--
-- TOC entry 5675 (class 0 OID 0)
-- Dependencies: 5030
-- Name: CONSTRAINT pk_oferta_tipos ON tb_oferta_tipos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_oferta_tipos ON public.tb_oferta_tipos IS 'Chave primária da tabela tb_oferta_tipos.';


--
-- TOC entry 4994 (class 2606 OID 22112)
-- Name: tb_perfil_permissoes pk_perfil_permissoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfil_permissoes
    ADD CONSTRAINT pk_perfil_permissoes PRIMARY KEY (id_perfil_permissao);


--
-- TOC entry 5676 (class 0 OID 0)
-- Dependencies: 4994
-- Name: CONSTRAINT pk_perfil_permissoes ON tb_perfil_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_perfil_permissoes ON public.tb_perfil_permissoes IS 'Chave primária da tabela tb_perfil_permissoes.';


--
-- TOC entry 4990 (class 2606 OID 22072)
-- Name: tb_perfis pk_perfis; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfis
    ADD CONSTRAINT pk_perfis PRIMARY KEY (id_perfil);


--
-- TOC entry 5677 (class 0 OID 0)
-- Dependencies: 4990
-- Name: CONSTRAINT pk_perfis ON tb_perfis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_perfis ON public.tb_perfis IS 'Chave primária da tabela tb_perfis.';


--
-- TOC entry 4984 (class 2606 OID 21998)
-- Name: tb_permissoes pk_permissoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_permissoes
    ADD CONSTRAINT pk_permissoes PRIMARY KEY (id_permissao);


--
-- TOC entry 5678 (class 0 OID 0)
-- Dependencies: 4984
-- Name: CONSTRAINT pk_permissoes ON tb_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_permissoes ON public.tb_permissoes IS 'Chave primária da tabela tb_permissoes.';


--
-- TOC entry 5012 (class 2606 OID 22474)
-- Name: tb_producoes pk_producoes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_producoes
    ADD CONSTRAINT pk_producoes PRIMARY KEY (id_producao);


--
-- TOC entry 5679 (class 0 OID 0)
-- Dependencies: 5012
-- Name: CONSTRAINT pk_producoes ON tb_producoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_producoes ON public.tb_producoes IS 'Chave primária da tabela tb_producoes.';


--
-- TOC entry 5050 (class 2606 OID 78031)
-- Name: tb_relatorios_anuais pk_relatorios_anuais; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_relatorios_anuais
    ADD CONSTRAINT pk_relatorios_anuais PRIMARY KEY (id_relatorio_anual);


--
-- TOC entry 5680 (class 0 OID 0)
-- Dependencies: 5050
-- Name: CONSTRAINT pk_relatorios_anuais ON tb_relatorios_anuais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_relatorios_anuais ON public.tb_relatorios_anuais IS 'Chave primária da tabela tb_relatorios_anuais.';


--
-- TOC entry 5004 (class 2606 OID 22252)
-- Name: tb_representantes pk_representantes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_representantes
    ADD CONSTRAINT pk_representantes PRIMARY KEY (id_representante);


--
-- TOC entry 5681 (class 0 OID 0)
-- Dependencies: 5004
-- Name: CONSTRAINT pk_representantes ON tb_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_representantes ON public.tb_representantes IS 'Chave primária da tabela tb_representantes.';


--
-- TOC entry 4986 (class 2606 OID 22035)
-- Name: tb_usuarios pk_usuarios; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios
    ADD CONSTRAINT pk_usuarios PRIMARY KEY (id_usuario);


--
-- TOC entry 5682 (class 0 OID 0)
-- Dependencies: 4986
-- Name: CONSTRAINT pk_usuarios ON tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT pk_usuarios ON public.tb_usuarios IS 'Chave primária da tabela tb_usuarios.';


--
-- TOC entry 4996 (class 2606 OID 22114)
-- Name: tb_perfil_permissoes uk_perfil_permissoes_perfil_permissao; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfil_permissoes
    ADD CONSTRAINT uk_perfil_permissoes_perfil_permissao UNIQUE (id_perfil, id_permissao);


--
-- TOC entry 5683 (class 0 OID 0)
-- Dependencies: 4996
-- Name: CONSTRAINT uk_perfil_permissoes_perfil_permissao ON tb_perfil_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT uk_perfil_permissoes_perfil_permissao ON public.tb_perfil_permissoes IS 'Unique constraint nas colunas id_perfil/id_permissao';


--
-- TOC entry 4992 (class 2606 OID 22074)
-- Name: tb_perfis uk_perfis_nomeperfil; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfis
    ADD CONSTRAINT uk_perfis_nomeperfil UNIQUE (nome_perfil);


--
-- TOC entry 4988 (class 2606 OID 22037)
-- Name: tb_usuarios uk_usuarios_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios
    ADD CONSTRAINT uk_usuarios_username UNIQUE (username);


--
-- TOC entry 5684 (class 0 OID 0)
-- Dependencies: 4988
-- Name: CONSTRAINT uk_usuarios_username ON tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT uk_usuarios_username ON public.tb_usuarios IS 'Unique constraint na coluna username';


--
-- TOC entry 5099 (class 2606 OID 22575)
-- Name: tb_autorizacoes fk_autorizacoes_empresa_certificada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_autorizacoes
    ADD CONSTRAINT fk_autorizacoes_empresa_certificada FOREIGN KEY (id_empresa_autorizada) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5685 (class 0 OID 0)
-- Dependencies: 5099
-- Name: CONSTRAINT fk_autorizacoes_empresa_certificada ON tb_autorizacoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_autorizacoes_empresa_certificada ON public.tb_autorizacoes IS 'Chave estrangeira da coluna id_empresa_certificada.';


--
-- TOC entry 5113 (class 2606 OID 69814)
-- Name: tb_certificados fk_certificados_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_certificados
    ADD CONSTRAINT fk_certificados_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5686 (class 0 OID 0)
-- Dependencies: 5113
-- Name: CONSTRAINT fk_certificados_empresa ON tb_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_certificados_empresa ON public.tb_certificados IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5114 (class 2606 OID 69819)
-- Name: tb_certificados fk_certificados_empresa_certificadora; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_certificados
    ADD CONSTRAINT fk_certificados_empresa_certificadora FOREIGN KEY (id_empresa_certificadora) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5687 (class 0 OID 0)
-- Dependencies: 5114
-- Name: CONSTRAINT fk_certificados_empresa_certificadora ON tb_certificados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_certificados_empresa_certificadora ON public.tb_certificados IS 'Chave estrangeira do campo id_empresa_certificadora.';


--
-- TOC entry 5084 (class 2606 OID 53264)
-- Name: tb_compras fk_compras_compra_aditivada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_compra_aditivada FOREIGN KEY (id_compra_aditivada) REFERENCES public.tb_compras(id_compra) NOT VALID;


--
-- TOC entry 5688 (class 0 OID 0)
-- Dependencies: 5084
-- Name: CONSTRAINT fk_compras_compra_aditivada ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_compra_aditivada ON public.tb_compras IS 'Chave estrangeira da coluna id_compra_aditivada.';


--
-- TOC entry 5082 (class 2606 OID 22404)
-- Name: tb_compras fk_compras_empresa_compradora; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_empresa_compradora FOREIGN KEY (id_empresa_compradora) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5689 (class 0 OID 0)
-- Dependencies: 5082
-- Name: CONSTRAINT fk_compras_empresa_compradora ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_empresa_compradora ON public.tb_compras IS 'Chave estrangeira da coluna id_empresa_compradora.';


--
-- TOC entry 5083 (class 2606 OID 22483)
-- Name: tb_compras fk_compras_empresa_fornecedora; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_empresa_fornecedora FOREIGN KEY (id_empresa_fornecedora) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5690 (class 0 OID 0)
-- Dependencies: 5083
-- Name: CONSTRAINT fk_compras_empresa_fornecedora ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_empresa_fornecedora ON public.tb_compras IS 'Chave estrangeira da coluna id_empresa_fornecedora.';


--
-- TOC entry 5080 (class 2606 OID 22422)
-- Name: tb_compras fk_compras_local_entrega; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_local_entrega FOREIGN KEY (id_local_entrega) REFERENCES public.tb_locais(id_local) NOT VALID;


--
-- TOC entry 5691 (class 0 OID 0)
-- Dependencies: 5080
-- Name: CONSTRAINT fk_compras_local_entrega ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_local_entrega ON public.tb_compras IS 'Chave estrangeira da coluna id_local_entrega.';


--
-- TOC entry 5081 (class 2606 OID 22427)
-- Name: tb_compras fk_compras_local_retirada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_local_retirada FOREIGN KEY (id_local_retirada) REFERENCES public.tb_locais(id_local) NOT VALID;


--
-- TOC entry 5692 (class 0 OID 0)
-- Dependencies: 5081
-- Name: CONSTRAINT fk_compras_local_retirada ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_local_retirada ON public.tb_compras IS 'Chave estrangeira da coluna id_local_retirada.';


--
-- TOC entry 5085 (class 2606 OID 69650)
-- Name: tb_compras fk_compras_oferta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_oferta FOREIGN KEY (id_oferta) REFERENCES public.tb_ofertas(id_oferta) NOT VALID;


--
-- TOC entry 5693 (class 0 OID 0)
-- Dependencies: 5085
-- Name: CONSTRAINT fk_compras_oferta ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_oferta ON public.tb_compras IS 'Chave estrangeira da coluna id_oferta.';


--
-- TOC entry 5079 (class 2606 OID 36864)
-- Name: tb_compras fk_compras_situacao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_situacao FOREIGN KEY (id_compra_situacao) REFERENCES public.tb_compra_situacoes(id_compra_situacao) NOT VALID;


--
-- TOC entry 5694 (class 0 OID 0)
-- Dependencies: 5079
-- Name: CONSTRAINT fk_compras_situacao ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_situacao ON public.tb_compras IS 'Chave estrangeira da coluna id_compra_situacao.';


--
-- TOC entry 5086 (class 2606 OID 69671)
-- Name: tb_compras fk_compras_tipo_frete; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_compras
    ADD CONSTRAINT fk_compras_tipo_frete FOREIGN KEY (id_frete_tipo) REFERENCES public.tb_frete_tipos(id_frete_tipo) NOT VALID;


--
-- TOC entry 5695 (class 0 OID 0)
-- Dependencies: 5086
-- Name: CONSTRAINT fk_compras_tipo_frete ON tb_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_compras_tipo_frete ON public.tb_compras IS 'Chave estrangeira da coluna id_frete_tipo.';


--
-- TOC entry 5122 (class 2606 OID 86297)
-- Name: tb_contrato_dados fk_contrato_dados_contrato; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contrato_dados
    ADD CONSTRAINT fk_contrato_dados_contrato FOREIGN KEY (id_contrato) REFERENCES public.tb_contratos(id_contrato);


--
-- TOC entry 5696 (class 0 OID 0)
-- Dependencies: 5122
-- Name: CONSTRAINT fk_contrato_dados_contrato ON tb_contrato_dados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_contrato_dados_contrato ON public.tb_contrato_dados IS 'Chave estrangeira da coluna id_contrato.';


--
-- TOC entry 5123 (class 2606 OID 86292)
-- Name: tb_contrato_dados fk_contrato_dados_contrato_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contrato_dados
    ADD CONSTRAINT fk_contrato_dados_contrato_item FOREIGN KEY (id_contrato_item) REFERENCES public.tb_contrato_itens(id_contrato_item);


--
-- TOC entry 5697 (class 0 OID 0)
-- Dependencies: 5123
-- Name: CONSTRAINT fk_contrato_dados_contrato_item ON tb_contrato_dados; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_contrato_dados_contrato_item ON public.tb_contrato_dados IS 'Chave estrangeira da coluna id_contrato_item.';


--
-- TOC entry 5121 (class 2606 OID 86268)
-- Name: tb_contratos fk_contratos_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_contratos
    ADD CONSTRAINT fk_contratos_compra FOREIGN KEY (id_compra) REFERENCES public.tb_compras(id_compra);


--
-- TOC entry 5698 (class 0 OID 0)
-- Dependencies: 5121
-- Name: CONSTRAINT fk_contratos_compra ON tb_contratos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_contratos_compra ON public.tb_contratos IS 'Chave estrangeira da coluna id_compra.';


--
-- TOC entry 5075 (class 2606 OID 22371)
-- Name: tb_empresa_representantes fk_empresa_representantes_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_representantes
    ADD CONSTRAINT fk_empresa_representantes_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5699 (class 0 OID 0)
-- Dependencies: 5075
-- Name: CONSTRAINT fk_empresa_representantes_empresa ON tb_empresa_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresa_representantes_empresa ON public.tb_empresa_representantes IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5076 (class 2606 OID 22376)
-- Name: tb_empresa_representantes fk_empresa_representantes_representante; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_representantes
    ADD CONSTRAINT fk_empresa_representantes_representante FOREIGN KEY (id_representante) REFERENCES public.tb_representantes(id_representante);


--
-- TOC entry 5700 (class 0 OID 0)
-- Dependencies: 5076
-- Name: CONSTRAINT fk_empresa_representantes_representante ON tb_empresa_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresa_representantes_representante ON public.tb_empresa_representantes IS 'Chave estrangeira da coluna id_representante.';


--
-- TOC entry 5077 (class 2606 OID 22386)
-- Name: tb_empresa_representantes fk_empresa_representantes_usuario_alteracao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_representantes
    ADD CONSTRAINT fk_empresa_representantes_usuario_alteracao FOREIGN KEY (id_usuario_alteracao) REFERENCES public.tb_usuarios(id_usuario);


--
-- TOC entry 5701 (class 0 OID 0)
-- Dependencies: 5077
-- Name: CONSTRAINT fk_empresa_representantes_usuario_alteracao ON tb_empresa_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresa_representantes_usuario_alteracao ON public.tb_empresa_representantes IS 'Chave estrangeira da coluna id_usuario_alteracao.';


--
-- TOC entry 5078 (class 2606 OID 22391)
-- Name: tb_empresa_representantes fk_empresa_representantes_usuario_inclusao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresa_representantes
    ADD CONSTRAINT fk_empresa_representantes_usuario_inclusao FOREIGN KEY (id_usuario_inclusao) REFERENCES public.tb_usuarios(id_usuario);


--
-- TOC entry 5702 (class 0 OID 0)
-- Dependencies: 5078
-- Name: CONSTRAINT fk_empresa_representantes_usuario_inclusao ON tb_empresa_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresa_representantes_usuario_inclusao ON public.tb_empresa_representantes IS 'Chave estrangeira da coluna id_usuario_inclusao.';


--
-- TOC entry 5069 (class 2606 OID 22155)
-- Name: tb_empresas fk_empresas_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas
    ADD CONSTRAINT fk_empresas_endereco FOREIGN KEY (id_endereco) REFERENCES public.tb_enderecos(id_endereco) NOT VALID;


--
-- TOC entry 5703 (class 0 OID 0)
-- Dependencies: 5069
-- Name: CONSTRAINT fk_empresas_endereco ON tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresas_endereco ON public.tb_empresas IS 'Chave estrangeira da coluna id_endereco.';


--
-- TOC entry 5070 (class 2606 OID 22171)
-- Name: tb_empresas fk_empresas_situacao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas
    ADD CONSTRAINT fk_empresas_situacao FOREIGN KEY (id_empresa_situacao) REFERENCES public.tb_empresa_situacoes(id_empresa_situacao) NOT VALID;


--
-- TOC entry 5704 (class 0 OID 0)
-- Dependencies: 5070
-- Name: CONSTRAINT fk_empresas_situacao ON tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresas_situacao ON public.tb_empresas IS 'Chave estrangeira da coluna id_empresa_situacao';


--
-- TOC entry 5073 (class 2606 OID 69689)
-- Name: tb_empresas fk_empresas_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas
    ADD CONSTRAINT fk_empresas_tipo FOREIGN KEY (id_empresa_tipo) REFERENCES public.tb_empresa_tipos(id_empresa_tipo) NOT VALID;


--
-- TOC entry 5705 (class 0 OID 0)
-- Dependencies: 5073
-- Name: CONSTRAINT fk_empresas_tipo ON tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresas_tipo ON public.tb_empresas IS 'Chave estrangeira da coluna id_empresa_tipo.';


--
-- TOC entry 5072 (class 2606 OID 22181)
-- Name: tb_empresas fk_empresas_usuario_alteracao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas
    ADD CONSTRAINT fk_empresas_usuario_alteracao FOREIGN KEY (id_usuario_alteracao) REFERENCES public.tb_usuarios(id_usuario) NOT VALID;


--
-- TOC entry 5706 (class 0 OID 0)
-- Dependencies: 5072
-- Name: CONSTRAINT fk_empresas_usuario_alteracao ON tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresas_usuario_alteracao ON public.tb_empresas IS 'Chave estrangeira da coluna id_usuario_alteracao.';


--
-- TOC entry 5071 (class 2606 OID 22176)
-- Name: tb_empresas fk_empresas_usuario_inclusao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_empresas
    ADD CONSTRAINT fk_empresas_usuario_inclusao FOREIGN KEY (id_usuario_inclusao) REFERENCES public.tb_usuarios(id_usuario) NOT VALID;


--
-- TOC entry 5707 (class 0 OID 0)
-- Dependencies: 5071
-- Name: CONSTRAINT fk_empresas_usuario_inclusao ON tb_empresas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_empresas_usuario_inclusao ON public.tb_empresas IS 'Chave estrangeira da coluna id_usuario_inclusao.';


--
-- TOC entry 5107 (class 2606 OID 69795)
-- Name: tb_entregas_sazonais fk_entregas_sazonais_negociacao_rodada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_entregas_sazonais
    ADD CONSTRAINT fk_entregas_sazonais_negociacao_rodada FOREIGN KEY (id_negociacao_rodada) REFERENCES public.tb_negociacao_rodadas(id_negociacao_rodada) NOT VALID;


--
-- TOC entry 5708 (class 0 OID 0)
-- Dependencies: 5107
-- Name: CONSTRAINT fk_entregas_sazonais_negociacao_rodada ON tb_entregas_sazonais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_entregas_sazonais_negociacao_rodada ON public.tb_entregas_sazonais IS 'Chave estrangeira da coluna id_negociacao_rodada.';


--
-- TOC entry 5088 (class 2606 OID 69824)
-- Name: tb_locais fk_locais_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_locais
    ADD CONSTRAINT fk_locais_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5709 (class 0 OID 0)
-- Dependencies: 5088
-- Name: CONSTRAINT fk_locais_empresa ON tb_locais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_locais_empresa ON public.tb_locais IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5087 (class 2606 OID 22417)
-- Name: tb_locais fk_locais_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_locais
    ADD CONSTRAINT fk_locais_endereco FOREIGN KEY (id_endereco) REFERENCES public.tb_enderecos(id_endereco);


--
-- TOC entry 5710 (class 0 OID 0)
-- Dependencies: 5087
-- Name: CONSTRAINT fk_locais_endereco ON tb_locais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_locais_endereco ON public.tb_locais IS 'Chave estrangeira da coluna id_endereco.';


--
-- TOC entry 5118 (class 2606 OID 86252)
-- Name: tb_logistica_coletas fk_logistica_coletas_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_coletas
    ADD CONSTRAINT fk_logistica_coletas_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5711 (class 0 OID 0)
-- Dependencies: 5118
-- Name: CONSTRAINT fk_logistica_coletas_empresa ON tb_logistica_coletas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_coletas_empresa ON public.tb_logistica_coletas IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5119 (class 2606 OID 86242)
-- Name: tb_logistica_coletas fk_logistica_coletas_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_coletas
    ADD CONSTRAINT fk_logistica_coletas_endereco FOREIGN KEY (id_endereco) REFERENCES public.tb_enderecos(id_endereco);


--
-- TOC entry 5712 (class 0 OID 0)
-- Dependencies: 5119
-- Name: CONSTRAINT fk_logistica_coletas_endereco ON tb_logistica_coletas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_coletas_endereco ON public.tb_logistica_coletas IS 'Chave estrangeira da coluna id_endereco.';


--
-- TOC entry 5120 (class 2606 OID 86247)
-- Name: tb_logistica_coletas fk_logistica_coletas_logistica; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_coletas
    ADD CONSTRAINT fk_logistica_coletas_logistica FOREIGN KEY (id_logistica) REFERENCES public.tb_logisticas(id_logistica);


--
-- TOC entry 5713 (class 0 OID 0)
-- Dependencies: 5120
-- Name: CONSTRAINT fk_logistica_coletas_logistica ON tb_logistica_coletas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_coletas_logistica ON public.tb_logistica_coletas IS 'Chave estrangeira da coluna id_logistica.';


--
-- TOC entry 5101 (class 2606 OID 22643)
-- Name: tb_logistica_compras fk_logistica_compras_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_compras
    ADD CONSTRAINT fk_logistica_compras_compra FOREIGN KEY (id_compra) REFERENCES public.tb_compras(id_compra);


--
-- TOC entry 5714 (class 0 OID 0)
-- Dependencies: 5101
-- Name: CONSTRAINT fk_logistica_compras_compra ON tb_logistica_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_compras_compra ON public.tb_logistica_compras IS 'Chave estrangeira da coluna id_compra.';


--
-- TOC entry 5102 (class 2606 OID 22648)
-- Name: tb_logistica_compras fk_logistica_compras_logistica; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_compras
    ADD CONSTRAINT fk_logistica_compras_logistica FOREIGN KEY (id_logistica) REFERENCES public.tb_logisticas(id_logistica);


--
-- TOC entry 5715 (class 0 OID 0)
-- Dependencies: 5102
-- Name: CONSTRAINT fk_logistica_compras_logistica ON tb_logistica_compras; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_compras_logistica ON public.tb_logistica_compras IS 'Chave estrangeira da coluna id_logistica.';


--
-- TOC entry 5116 (class 2606 OID 86229)
-- Name: tb_logistica_dutos fk_logistica_dutos_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_dutos
    ADD CONSTRAINT fk_logistica_dutos_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5716 (class 0 OID 0)
-- Dependencies: 5116
-- Name: CONSTRAINT fk_logistica_dutos_empresa ON tb_logistica_dutos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_dutos_empresa ON public.tb_logistica_dutos IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5117 (class 2606 OID 86224)
-- Name: tb_logistica_dutos fk_logistica_dutos_logistica; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logistica_dutos
    ADD CONSTRAINT fk_logistica_dutos_logistica FOREIGN KEY (id_logistica) REFERENCES public.tb_logisticas(id_logistica);


--
-- TOC entry 5717 (class 0 OID 0)
-- Dependencies: 5117
-- Name: CONSTRAINT fk_logistica_dutos_logistica ON tb_logistica_dutos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logistica_dutos_logistica ON public.tb_logistica_dutos IS 'Chave estrangeira da coluna id_logistica.';


--
-- TOC entry 5100 (class 2606 OID 22593)
-- Name: tb_logisticas fk_logisticas_empresa_transportadora; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_logisticas
    ADD CONSTRAINT fk_logisticas_empresa_transportadora FOREIGN KEY (id_empresa_transportadora) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5718 (class 0 OID 0)
-- Dependencies: 5100
-- Name: CONSTRAINT fk_logisticas_empresa_transportadora ON tb_logisticas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_logisticas_empresa_transportadora ON public.tb_logisticas IS 'Chave estrangeira da coluna id_empresa_transportadora.';


--
-- TOC entry 5111 (class 2606 OID 69770)
-- Name: tb_negociacao_propostas fk_negociacao_propostas_negociacao_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_propostas
    ADD CONSTRAINT fk_negociacao_propostas_negociacao_item FOREIGN KEY (id_negociacao_item) REFERENCES public.tb_negociacao_itens(id_negociacao_item);


--
-- TOC entry 5719 (class 0 OID 0)
-- Dependencies: 5111
-- Name: CONSTRAINT fk_negociacao_propostas_negociacao_item ON tb_negociacao_propostas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_propostas_negociacao_item ON public.tb_negociacao_propostas IS 'Chave estrangeira da coluna id_negociacao_item.';


--
-- TOC entry 5112 (class 2606 OID 69765)
-- Name: tb_negociacao_propostas fk_negociacao_propostas_negociacao_rodada_nova; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_propostas
    ADD CONSTRAINT fk_negociacao_propostas_negociacao_rodada_nova FOREIGN KEY (id_negociacao_rodada) REFERENCES public.tb_negociacao_rodadas(id_negociacao_rodada);


--
-- TOC entry 5720 (class 0 OID 0)
-- Dependencies: 5112
-- Name: CONSTRAINT fk_negociacao_propostas_negociacao_rodada_nova ON tb_negociacao_propostas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_propostas_negociacao_rodada_nova ON public.tb_negociacao_propostas IS 'Chave estrangeira da coluna id_negociacao_rodada_nova.';


--
-- TOC entry 5103 (class 2606 OID 61481)
-- Name: tb_negociacao_rodadas_antiga fk_negociacao_rodadas_empresa_proponente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas_antiga
    ADD CONSTRAINT fk_negociacao_rodadas_empresa_proponente FOREIGN KEY (id_empresa_proponente) REFERENCES public.tb_empresas(id_empresa);


--
-- TOC entry 5721 (class 0 OID 0)
-- Dependencies: 5103
-- Name: CONSTRAINT fk_negociacao_rodadas_empresa_proponente ON tb_negociacao_rodadas_antiga; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_empresa_proponente ON public.tb_negociacao_rodadas_antiga IS 'Chave estrangeira da coluna id_empresa_proponente.';


--
-- TOC entry 5104 (class 2606 OID 61488)
-- Name: tb_negociacao_rodadas_antiga fk_negociacao_rodadas_negociacao_anterior; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas_antiga
    ADD CONSTRAINT fk_negociacao_rodadas_negociacao_anterior FOREIGN KEY (id_negociacao_rodada_anterior) REFERENCES public.tb_negociacao_rodadas_antiga(id_negociacao_rodada) NOT VALID;


--
-- TOC entry 5722 (class 0 OID 0)
-- Dependencies: 5104
-- Name: CONSTRAINT fk_negociacao_rodadas_negociacao_anterior ON tb_negociacao_rodadas_antiga; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_negociacao_anterior ON public.tb_negociacao_rodadas_antiga IS 'Chave estrangeira da coluna id_negociacao_rodada_anterior.';


--
-- TOC entry 5105 (class 2606 OID 61476)
-- Name: tb_negociacao_rodadas_antiga fk_negociacao_rodadas_negociacao_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas_antiga
    ADD CONSTRAINT fk_negociacao_rodadas_negociacao_item FOREIGN KEY (id_negociacao_item) REFERENCES public.tb_negociacao_itens(id_negociacao_item);


--
-- TOC entry 5723 (class 0 OID 0)
-- Dependencies: 5105
-- Name: CONSTRAINT fk_negociacao_rodadas_negociacao_item ON tb_negociacao_rodadas_antiga; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_negociacao_item ON public.tb_negociacao_rodadas_antiga IS 'Chave estrangeira da coluna id_negociacao_item.';


--
-- TOC entry 5108 (class 2606 OID 69785)
-- Name: tb_negociacao_rodadas fk_negociacao_rodadas_nova_empresa_proponente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas
    ADD CONSTRAINT fk_negociacao_rodadas_nova_empresa_proponente FOREIGN KEY (id_empresa_proponente) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5724 (class 0 OID 0)
-- Dependencies: 5108
-- Name: CONSTRAINT fk_negociacao_rodadas_nova_empresa_proponente ON tb_negociacao_rodadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_nova_empresa_proponente ON public.tb_negociacao_rodadas IS 'Chave estrangeira da coluna id_empresa_proponente.';


--
-- TOC entry 5109 (class 2606 OID 69706)
-- Name: tb_negociacao_rodadas fk_negociacao_rodadas_nova_oferta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas
    ADD CONSTRAINT fk_negociacao_rodadas_nova_oferta FOREIGN KEY (id_oferta) REFERENCES public.tb_ofertas(id_oferta);


--
-- TOC entry 5725 (class 0 OID 0)
-- Dependencies: 5109
-- Name: CONSTRAINT fk_negociacao_rodadas_nova_oferta ON tb_negociacao_rodadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_nova_oferta ON public.tb_negociacao_rodadas IS 'Chave estrangeira da coluna id_oferta.';


--
-- TOC entry 5110 (class 2606 OID 69790)
-- Name: tb_negociacao_rodadas fk_negociacao_rodadas_nova_proposta_anterior; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas
    ADD CONSTRAINT fk_negociacao_rodadas_nova_proposta_anterior FOREIGN KEY (id_negociacao_rodada_anterior) REFERENCES public.tb_negociacao_rodadas(id_negociacao_rodada) NOT VALID;


--
-- TOC entry 5726 (class 0 OID 0)
-- Dependencies: 5110
-- Name: CONSTRAINT fk_negociacao_rodadas_nova_proposta_anterior ON tb_negociacao_rodadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_nova_proposta_anterior ON public.tb_negociacao_rodadas IS 'Chave estrangeira da coluna id_negociacao_rodada_anterior.';


--
-- TOC entry 5106 (class 2606 OID 69645)
-- Name: tb_negociacao_rodadas_antiga fk_negociacao_rodadas_oferta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_negociacao_rodadas_antiga
    ADD CONSTRAINT fk_negociacao_rodadas_oferta FOREIGN KEY (id_oferta) REFERENCES public.tb_ofertas(id_oferta) NOT VALID;


--
-- TOC entry 5727 (class 0 OID 0)
-- Dependencies: 5106
-- Name: CONSTRAINT fk_negociacao_rodadas_oferta ON tb_negociacao_rodadas_antiga; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_negociacao_rodadas_oferta ON public.tb_negociacao_rodadas_antiga IS 'Chave estrangeira da coluna id_oferta.';


--
-- TOC entry 5095 (class 2606 OID 22552)
-- Name: tb_noticias fk_noticias_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticias
    ADD CONSTRAINT fk_noticias_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5728 (class 0 OID 0)
-- Dependencies: 5095
-- Name: CONSTRAINT fk_noticias_empresa ON tb_noticias; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_noticias_empresa ON public.tb_noticias IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5096 (class 2606 OID 53235)
-- Name: tb_noticias fk_noticias_situacao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticias
    ADD CONSTRAINT fk_noticias_situacao FOREIGN KEY (id_noticia_situacao) REFERENCES public.tb_noticia_situacoes(id_noticia_situacao) NOT VALID;


--
-- TOC entry 5729 (class 0 OID 0)
-- Dependencies: 5096
-- Name: CONSTRAINT fk_noticias_situacao ON tb_noticias; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_noticias_situacao ON public.tb_noticias IS 'Chave estrangeira da coluna id_noticia_situacao.';


--
-- TOC entry 5097 (class 2606 OID 53245)
-- Name: tb_noticias fk_noticias_usuario_alteracao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticias
    ADD CONSTRAINT fk_noticias_usuario_alteracao FOREIGN KEY (id_usuario_alteracao) REFERENCES public.tb_usuarios(id_usuario) NOT VALID;


--
-- TOC entry 5730 (class 0 OID 0)
-- Dependencies: 5097
-- Name: CONSTRAINT fk_noticias_usuario_alteracao ON tb_noticias; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_noticias_usuario_alteracao ON public.tb_noticias IS 'Chave estrangeira da coluna id_usuario_alteracao.';


--
-- TOC entry 5098 (class 2606 OID 53240)
-- Name: tb_noticias fk_noticias_usuario_inclusao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_noticias
    ADD CONSTRAINT fk_noticias_usuario_inclusao FOREIGN KEY (id_usuario_inclusao) REFERENCES public.tb_usuarios(id_usuario) NOT VALID;


--
-- TOC entry 5731 (class 0 OID 0)
-- Dependencies: 5098
-- Name: CONSTRAINT fk_noticias_usuario_inclusao ON tb_noticias; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_noticias_usuario_inclusao ON public.tb_noticias IS 'Chave estrangeira da coluna id_usuario_inclusao.';


--
-- TOC entry 5094 (class 2606 OID 69836)
-- Name: tb_ofertas fk_ofertas_certificado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_certificado FOREIGN KEY (id_certificado) REFERENCES public.tb_certificados(id_certificado) NOT VALID;


--
-- TOC entry 5732 (class 0 OID 0)
-- Dependencies: 5094
-- Name: CONSTRAINT fk_ofertas_certificado ON tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_ofertas_certificado ON public.tb_ofertas IS 'Chave estrangeira da coluna id_certificado.';


--
-- TOC entry 5091 (class 2606 OID 22535)
-- Name: tb_ofertas fk_ofertas_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5733 (class 0 OID 0)
-- Dependencies: 5091
-- Name: CONSTRAINT fk_ofertas_empresa ON tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_ofertas_empresa ON public.tb_ofertas IS 'Chave estrangeira para a coluna id_empresa.';


--
-- TOC entry 5093 (class 2606 OID 69676)
-- Name: tb_ofertas fk_ofertas_empresa_privada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_empresa_privada FOREIGN KEY (id_empresa_privada) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5734 (class 0 OID 0)
-- Dependencies: 5093
-- Name: CONSTRAINT fk_ofertas_empresa_privada ON tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_ofertas_empresa_privada ON public.tb_ofertas IS 'Chave estrangeira da coluna id_empresa_privada.';


--
-- TOC entry 5092 (class 2606 OID 36851)
-- Name: tb_ofertas fk_ofertas_situacao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_situacao FOREIGN KEY (id_oferta_situacao) REFERENCES public.tb_oferta_situacoes(id_oferta_situacao) NOT VALID;


--
-- TOC entry 5735 (class 0 OID 0)
-- Dependencies: 5092
-- Name: CONSTRAINT fk_ofertas_situacao ON tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_ofertas_situacao ON public.tb_ofertas IS 'Chave estrangeira da coluna id_oferta_situacao.';


--
-- TOC entry 5090 (class 2606 OID 45043)
-- Name: tb_ofertas fk_ofertas_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ofertas
    ADD CONSTRAINT fk_ofertas_tipo FOREIGN KEY (id_oferta_tipo) REFERENCES public.tb_oferta_tipos(id_oferta_tipo) NOT VALID;


--
-- TOC entry 5736 (class 0 OID 0)
-- Dependencies: 5090
-- Name: CONSTRAINT fk_ofertas_tipo ON tb_ofertas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_ofertas_tipo ON public.tb_ofertas IS 'Chave estrangeira da coluna id_oferta_tipo.';


--
-- TOC entry 5067 (class 2606 OID 22115)
-- Name: tb_perfil_permissoes fk_perfil_permissoes_perfil; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfil_permissoes
    ADD CONSTRAINT fk_perfil_permissoes_perfil FOREIGN KEY (id_perfil) REFERENCES public.tb_perfis(id_perfil);


--
-- TOC entry 5737 (class 0 OID 0)
-- Dependencies: 5067
-- Name: CONSTRAINT fk_perfil_permissoes_perfil ON tb_perfil_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_perfil_permissoes_perfil ON public.tb_perfil_permissoes IS 'Chave estrangeira da coluna id_perfil.';


--
-- TOC entry 5068 (class 2606 OID 22120)
-- Name: tb_perfil_permissoes fk_perfil_permissoes_permissao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfil_permissoes
    ADD CONSTRAINT fk_perfil_permissoes_permissao FOREIGN KEY (id_permissao) REFERENCES public.tb_permissoes(id_permissao);


--
-- TOC entry 5738 (class 0 OID 0)
-- Dependencies: 5068
-- Name: CONSTRAINT fk_perfil_permissoes_permissao ON tb_perfil_permissoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_perfil_permissoes_permissao ON public.tb_perfil_permissoes IS 'Chave estrangeira da coluna id_permissao.';


--
-- TOC entry 5065 (class 2606 OID 22085)
-- Name: tb_perfis fk_perfis_usuario_alteracao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfis
    ADD CONSTRAINT fk_perfis_usuario_alteracao FOREIGN KEY (id_usuario_alteracao) REFERENCES public.tb_usuarios(id_usuario);


--
-- TOC entry 5739 (class 0 OID 0)
-- Dependencies: 5065
-- Name: CONSTRAINT fk_perfis_usuario_alteracao ON tb_perfis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_perfis_usuario_alteracao ON public.tb_perfis IS 'Chave estrangeira da coluna id_usuario_alteracao.';


--
-- TOC entry 5066 (class 2606 OID 22090)
-- Name: tb_perfis fk_perfis_usuario_inclusao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_perfis
    ADD CONSTRAINT fk_perfis_usuario_inclusao FOREIGN KEY (id_usuario_inclusao) REFERENCES public.tb_usuarios(id_usuario);


--
-- TOC entry 5740 (class 0 OID 0)
-- Dependencies: 5066
-- Name: CONSTRAINT fk_perfis_usuario_inclusao ON tb_perfis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_perfis_usuario_inclusao ON public.tb_perfis IS 'Chave estrangeira da coluna id_usuario_inclusao.';


--
-- TOC entry 5089 (class 2606 OID 22478)
-- Name: tb_producoes fk_producao_empresa_fornecedora; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_producoes
    ADD CONSTRAINT fk_producao_empresa_fornecedora FOREIGN KEY (id_empresa_fornecedora) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5741 (class 0 OID 0)
-- Dependencies: 5089
-- Name: CONSTRAINT fk_producao_empresa_fornecedora ON tb_producoes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_producao_empresa_fornecedora ON public.tb_producoes IS 'Chave estrangeira da coluna id_empresa_fornecedora.';


--
-- TOC entry 5115 (class 2606 OID 78032)
-- Name: tb_relatorios_anuais fk_relatorios_anuais_compra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_relatorios_anuais
    ADD CONSTRAINT fk_relatorios_anuais_compra FOREIGN KEY (id_compra) REFERENCES public.tb_compras(id_compra);


--
-- TOC entry 5742 (class 0 OID 0)
-- Dependencies: 5115
-- Name: CONSTRAINT fk_relatorios_anuais_compra ON tb_relatorios_anuais; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_relatorios_anuais_compra ON public.tb_relatorios_anuais IS 'Chave estrangeira da coluna id_compra.';


--
-- TOC entry 5074 (class 2606 OID 22253)
-- Name: tb_representantes fk_representantes_endereco; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_representantes
    ADD CONSTRAINT fk_representantes_endereco FOREIGN KEY (id_endereco) REFERENCES public.tb_enderecos(id_endereco);


--
-- TOC entry 5743 (class 0 OID 0)
-- Dependencies: 5074
-- Name: CONSTRAINT fk_representantes_endereco ON tb_representantes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_representantes_endereco ON public.tb_representantes IS 'Chave estrangeira da coluna id_endereco.';


--
-- TOC entry 5062 (class 2606 OID 22653)
-- Name: tb_usuarios fk_usuarios_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_empresa FOREIGN KEY (id_empresa) REFERENCES public.tb_empresas(id_empresa) NOT VALID;


--
-- TOC entry 5744 (class 0 OID 0)
-- Dependencies: 5062
-- Name: CONSTRAINT fk_usuarios_empresa ON tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_usuarios_empresa ON public.tb_usuarios IS 'Chave estrangeira da coluna id_empresa.';


--
-- TOC entry 5061 (class 2606 OID 22137)
-- Name: tb_usuarios fk_usuarios_perfil; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_perfil FOREIGN KEY (id_perfil) REFERENCES public.tb_perfis(id_perfil) NOT VALID;


--
-- TOC entry 5745 (class 0 OID 0)
-- Dependencies: 5061
-- Name: CONSTRAINT fk_usuarios_perfil ON tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_usuarios_perfil ON public.tb_usuarios IS 'Chave estrangeira da coluna id_perfil.';


--
-- TOC entry 5064 (class 2606 OID 53255)
-- Name: tb_usuarios fk_usuarios_usuario_alteracao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_usuario_alteracao FOREIGN KEY (id_usuario_alteracao) REFERENCES public.tb_usuarios(id_usuario) NOT VALID;


--
-- TOC entry 5746 (class 0 OID 0)
-- Dependencies: 5064
-- Name: CONSTRAINT fk_usuarios_usuario_alteracao ON tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_usuarios_usuario_alteracao ON public.tb_usuarios IS 'Chave estrangeira da coluna id_usuario_alteracao.';


--
-- TOC entry 5063 (class 2606 OID 53250)
-- Name: tb_usuarios fk_usuarios_usuario_inclusao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_usuario_inclusao FOREIGN KEY (id_usuario_inclusao) REFERENCES public.tb_usuarios(id_usuario) NOT VALID;


--
-- TOC entry 5747 (class 0 OID 0)
-- Dependencies: 5063
-- Name: CONSTRAINT fk_usuarios_usuario_inclusao ON tb_usuarios; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_usuarios_usuario_inclusao ON public.tb_usuarios IS 'Chave estrangeira da coluna id_usuario_inclusao.';


-- Completed on 2023-12-23 12:32:39

--
-- PostgreSQL database dump complete
--

