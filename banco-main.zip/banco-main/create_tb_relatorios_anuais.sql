-- Table: public.tb_relatorios_anuais

-- DROP TABLE IF EXISTS public.tb_relatorios_anuais;

CREATE TABLE IF NOT EXISTS public.tb_relatorios_anuais
(
    id_relatorio_anual serial NOT NULL,
    id_compra integer NOT NULL,
    dh_relatorio_anual timestamp without time zone NOT NULL,
	arquivo_relatorio bytea,
    CONSTRAINT pk_relatorios_anuais PRIMARY KEY (id_relatorio_anual),
    CONSTRAINT fk_relatorios_anuais_compra FOREIGN KEY (id_compra)
        REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_relatorios_anuais
    OWNER to postgres;

COMMENT ON TABLE public.tb_relatorios_anuais
    IS 'Relatórios anuais de entregas.';

COMMENT ON COLUMN public.tb_relatorios_anuais.id_relatorio_anual
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_relatorios_anuais.id_compra
    IS 'Compra de biometano.';

COMMENT ON COLUMN public.tb_relatorios_anuais.dh_relatorio_anual
    IS 'Data/hora do relatório.';

COMMENT ON COLUMN public.tb_relatorios_anuais.arquivo_relatorio
    IS 'Arquivo contendo o relatório.';
	
COMMENT ON CONSTRAINT pk_relatorios_anuais ON public.tb_relatorios_anuais
    IS 'Chave primária da tabela tb_relatorios_anuais.';

COMMENT ON CONSTRAINT fk_relatorios_anuais_compra ON public.tb_relatorios_anuais
    IS 'Chave estrangeira da coluna id_compra.';