ALTER TABLE IF EXISTS public.tb_noticias
    ADD COLUMN titulo_noticia character varying(60) NOT NULL;

COMMENT ON COLUMN public.tb_noticias.titulo_noticia
    IS 'Título da notícia.';