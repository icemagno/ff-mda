-- Table: public.tb_representante_situacoes

-- DROP TABLE IF EXISTS public.tb_representante_situacoes;

CREATE TABLE IF NOT EXISTS public.tb_representante_situacoes
(
    id_representante_situacao smallserial NOT NULL,
    ds_representante_situacao character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_representante_situacoes PRIMARY KEY (id_representante_situacao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_representante_situacoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_representante_situacoes
    IS 'Situações possíveis de um representante.';

COMMENT ON COLUMN public.tb_representante_situacoes.id_representante_situacao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_representante_situacoes.ds_representante_situacao
    IS 'Descrição da situação do representante.';
COMMENT ON CONSTRAINT pk_representante_situacoes ON public.tb_representante_situacoes
    IS 'Chave primária da tabela tb_representante_situacoes.';