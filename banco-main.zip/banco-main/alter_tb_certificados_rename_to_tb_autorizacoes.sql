ALTER TABLE IF EXISTS public.tb_certificados
    RENAME TO tb_autorizacoes;

COMMENT ON TABLE public.tb_autorizacoes
  IS 'Autorização de empresas.';

ALTER TABLE IF EXISTS public.tb_autorizacoes
    RENAME id_certificado TO id_autorizacao;

ALTER TABLE IF EXISTS public.tb_autorizacoes
    RENAME dt_certificado TO dt_autorizacao;

COMMENT ON COLUMN public.tb_autorizacoes.dt_autorizacao
    IS 'Data da autorização.';

COMMENT ON COLUMN public.tb_autorizacoes.dt_validade
    IS 'Data de validade da autorização.';

ALTER TABLE IF EXISTS public.tb_autorizacoes
    RENAME id_empresa_certificada TO id_empresa_autorizada;

COMMENT ON COLUMN public.tb_autorizacoes.id_empresa_autorizada
    IS 'Empresa autorizada.';

ALTER TABLE IF EXISTS public.tb_autorizacoes
    RENAME id_empresa_certificadora TO id_empresa_autorizadora;

COMMENT ON COLUMN public.tb_autorizacoes.id_empresa_autorizadora
    IS 'Empresa autorizadora.';