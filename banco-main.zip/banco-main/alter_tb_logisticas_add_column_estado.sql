COMMENT ON COLUMN public.tb_logisticas.tipo_transporte
    IS 'Transporte, distribuição, outros (campo livre).';

ALTER TABLE IF EXISTS public.tb_logisticas
    ADD COLUMN estado character varying(3) NOT NULL;

COMMENT ON COLUMN public.tb_logisticas.estado
    IS 'GNC/GNL';