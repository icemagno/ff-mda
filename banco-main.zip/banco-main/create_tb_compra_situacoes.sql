-- Table: public.tb_compra_situacoes

-- DROP TABLE IF EXISTS public.tb_compra_situacoes;

CREATE TABLE IF NOT EXISTS public.tb_compra_situacoes
(
    id_compra_situacao smallserial NOT NULL,
    ds_compra_situacao character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_compra_situacoes PRIMARY KEY (id_compra_situacao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_compra_situacoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_compra_situacoes
    IS 'Situações possíveis de uma compra.';

COMMENT ON COLUMN public.tb_compra_situacoes.id_compra_situacao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_compra_situacoes.ds_compra_situacao
    IS 'Descrição da situação da compra.';
COMMENT ON CONSTRAINT pk_compra_situacoes ON public.tb_compra_situacoes
    IS 'Chave primária da tabela tb_compra_situacoes.';