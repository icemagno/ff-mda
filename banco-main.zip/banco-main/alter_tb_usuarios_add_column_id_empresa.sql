ALTER TABLE IF EXISTS public.tb_usuarios
    ADD COLUMN id_empresa integer;

COMMENT ON COLUMN public.tb_usuarios.id_empresa
    IS 'Empresa a que pertence o usuário.';
	
ALTER TABLE IF EXISTS public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_empresa FOREIGN KEY (id_empresa)
    REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_usuarios_empresa ON public.tb_usuarios
    IS 'Chave estrangeira da coluna id_empresa.';