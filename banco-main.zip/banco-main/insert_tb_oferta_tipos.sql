insert into public.tb_oferta_tipos(id_oferta_tipo,ds_oferta_tipo) values (1,'OT_BIOMETANO');
insert into public.tb_oferta_tipos(id_oferta_tipo,ds_oferta_tipo) values (2,'OT_BIOMETANO_CERTIFICADO');
insert into public.tb_oferta_tipos(id_oferta_tipo,ds_oferta_tipo) values (3,'OT_CERTIFICADO');
