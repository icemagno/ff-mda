ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN id_oferta integer;

COMMENT ON COLUMN public.tb_compras.id_oferta
    IS 'Oferta a partir da qual a compra foi gerada.';
	
ALTER TABLE IF EXISTS public.tb_compras
    ADD CONSTRAINT fk_compras_oferta FOREIGN KEY (id_oferta)
    REFERENCES public.tb_ofertas (id_oferta) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_compras_oferta ON public.tb_compras
    IS 'Chave estrangeira da coluna id_oferta.';