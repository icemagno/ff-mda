-- Table: public.tb_perfis

-- DROP TABLE IF EXISTS public.tb_perfis;

CREATE TABLE IF NOT EXISTS public.tb_perfis
(
    id_perfil smallserial NOT NULL,
    nome_perfil character varying(100) COLLATE pg_catalog."default" NOT NULL,
    ds_perfil character varying(255) COLLATE pg_catalog."default" NOT NULL,
    id_perfil_situacao smallint NOT NULL,
    id_perfil_tipo smallint NOT NULL,
    id_usuario_inclusao integer NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    id_usuario_alteracao integer,
    dt_alteracao timestamp without time zone,
    CONSTRAINT pk_perfis PRIMARY KEY (id_perfil),
    CONSTRAINT uk_perfis_nomeperfil UNIQUE (nome_perfil),
    CONSTRAINT fk_perfis_perfil_situacao FOREIGN KEY (id_perfil_situacao)
        REFERENCES public.tb_perfil_situacoes (id_perfil_situacao) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_perfis_perfil_tipo FOREIGN KEY (id_perfil_tipo)
        REFERENCES public.tb_perfil_tipos (id_perfil_tipo) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_perfis_usuario_alteracao FOREIGN KEY (id_usuario_alteracao)
        REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_perfis_usuario_inclusao FOREIGN KEY (id_usuario_inclusao)
        REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_perfis
    OWNER to postgres;

COMMENT ON TABLE public.tb_perfis
    IS 'Perfil a ser atribuído a um usuário.';

COMMENT ON COLUMN public.tb_perfis.id_perfil
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_perfis.nome_perfil
    IS 'Nome do perfil.';

COMMENT ON COLUMN public.tb_perfis.ds_perfil
    IS 'Descrição do perfil.';

COMMENT ON COLUMN public.tb_perfis.id_perfil_situacao
    IS 'Situação do perfil.';

COMMENT ON COLUMN public.tb_perfis.id_perfil_tipo
    IS 'Tipo do perfil.';

COMMENT ON COLUMN public.tb_perfis.id_usuario_inclusao
    IS 'Usuário responsável pela inclusão do perfil.';

COMMENT ON COLUMN public.tb_perfis.dt_inclusao
    IS 'Data/hora da inclusão do perfil.';

COMMENT ON COLUMN public.tb_perfis.id_usuario_alteracao
    IS 'Usuário responsável pela alteração do perfil.';

COMMENT ON COLUMN public.tb_perfis.dt_alteracao
    IS 'Data/hora da alteração do perfil.';
	
COMMENT ON CONSTRAINT pk_perfis ON public.tb_perfis
    IS 'Chave primária da tabela tb_perfis.';

COMMENT ON CONSTRAINT fk_perfis_usuario_alteracao ON public.tb_perfis
    IS 'Chave estrangeira da coluna id_usuario_alteracao.';
	
COMMENT ON CONSTRAINT fk_perfis_usuario_inclusao ON public.tb_perfis
    IS 'Chave estrangeira da coluna id_usuario_inclusao.';
	
------------------------------------------------------------------------

ALTER TABLE IF EXISTS public.tb_usuarios DROP CONSTRAINT IF EXISTS fk_usuarios_perfil;

ALTER TABLE IF EXISTS public.tb_usuarios
    ADD CONSTRAINT fk_usuarios_perfil FOREIGN KEY (id_perfil)
    REFERENCES public.tb_perfis (id_perfil) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_usuarios_perfil ON public.tb_usuarios
    IS 'Chave estrangeira da coluna id_perfil.';