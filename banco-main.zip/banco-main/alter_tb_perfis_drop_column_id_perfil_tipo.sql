ALTER TABLE public.tb_perfis
    DROP COLUMN id_perfil_tipo CASCADE;
