-- Table: public.tb_duto_tipos

-- DROP TABLE IF EXISTS public.tb_duto_tipos;

CREATE TABLE IF NOT EXISTS public.tb_duto_tipos
(
    id_duto_tipo smallserial NOT NULL,
    sg_duto_tipo character varying(50) COLLATE pg_catalog."default" NOT NULL,
    ds_duto_tipo character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_duto_tipos PRIMARY KEY (id_duto_tipo)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_duto_tipos
    OWNER to postgres;

COMMENT ON TABLE public.tb_duto_tipos
    IS 'Tipos de duto: transporte/distribuição.';

COMMENT ON COLUMN public.tb_duto_tipos.id_duto_tipo
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_duto_tipos.sg_duto_tipo
    IS 'Sigla do tipo de duto.';

COMMENT ON COLUMN public.tb_duto_tipos.ds_duto_tipo
    IS 'Descrição do tipo de duto.';
	
COMMENT ON CONSTRAINT pk_duto_tipos ON public.tb_duto_tipos
    IS 'Chave primária da tabela tb_duto_tipos.';