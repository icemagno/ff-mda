package br.com.cmabreu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.cmabreu.model.Empresa;

// @Repository
// @Transactional
public interface MigradorRepository extends JpaRepository<Empresa, Long>  {
	
	@Modifying
	@Query(nativeQuery = true, value="INSERT INTO cenario_grupos m WHERE m.groupid = :groupid AND m.cenarioid = :cenarioid")
	public void deleteAllByGroupIdAndCenarioId( @Param("groupid") Long groupId, @Param("cenarioid") Long cenarioId );	

}
