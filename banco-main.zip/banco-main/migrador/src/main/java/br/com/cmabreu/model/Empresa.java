package br.com.cmabreu.model;


import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;


@Entity
@Table(name = "tb_empresas")
public class Empresa implements  Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="tb_empresas_id_empresa_seq")
	@SequenceGenerator(name = "tb_empresas_id_empresa_seq", sequenceName = "tb_empresas_id_empresa_seq", allocationSize = 1)
	@Column(name = "id_empresa")
	private Long id;

	@Column(name = "cnpj", unique = true)
	private String cnpj;
	
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="ID_ENDERECO",referencedColumnName = "ID_ENDERECO")
	private Endereco endereco;	

	@Column(name = "razao_social")
	private String razaoSocial;

	@Column(name = "nome_fantasia")
	private String nomeFatasia;

	@Column(name = "inscricao_estadual")
	private String inscricaoEstadual;

	@Column(name = "inscricao_municipal")
	private String inscricaoMunicipal;

	@Column(name = "nicho_mercado")
	private String nichoMercado;

	@Column(name = "servicos_produtos")
	private String servicosProdutos;

	@Column(name = "port_empr")
	private String porteEmpresa;

	@Column(name = "dt_inclusao")
	private LocalDateTime dataInclusao;

	@Column(name = "dt_alteracao")
	private LocalDateTime dataAlteracao;

	@Column(name = "id_empresa_situacao")
	private Integer situacao;
	
	@Column(name = "id_usuario_inclusao")
	private Integer usuarioInclusao;
	
	@Column(name = "id_usuario_alteracao")
	private Integer usuarioAlteracao;

	
	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public Integer getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(Integer usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public Integer getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(Integer usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public Integer getSituacao() {
		return situacao;
	}

	public void setSituacao(Integer situacao) {
		this.situacao = situacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getNomeFatasia() {
		return nomeFatasia;
	}

	public void setNomeFatasia(String nomeFatasia) {
		this.nomeFatasia = nomeFatasia;
	}

	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	public String getInscricaoMunicipal() {
		return inscricaoMunicipal;
	}

	public void setInscricaoMunicipal(String inscricaoMunicipal) {
		this.inscricaoMunicipal = inscricaoMunicipal;
	}

	public String getNichoMercado() {
		return nichoMercado;
	}

	public void setNichoMercado(String nichoMercado) {
		this.nichoMercado = nichoMercado;
	}

	public String getServicosProdutos() {
		return servicosProdutos;
	}

	public void setServicosProdutos(String servicosProdutos) {
		this.servicosProdutos = servicosProdutos;
	}

	public String getPorteEmpresa() {
		return porteEmpresa;
	}

	public void setPorteEmpresa(String porteEmpresa) {
		this.porteEmpresa = porteEmpresa;
	}

	public LocalDateTime getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(LocalDateTime dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public LocalDateTime getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(LocalDateTime dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	

}