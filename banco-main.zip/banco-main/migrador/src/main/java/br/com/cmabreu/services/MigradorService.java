package br.com.cmabreu.services;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.com.cmabreu.model.Empresa;
import br.com.cmabreu.model.Endereco;
import br.com.cmabreu.repository.EmpresaRepository;

@Service
public class MigradorService {
	
	@Autowired private EntityManagerFactory emf;
	
	@Autowired private EmpresaRepository empresaRepository;
	
	private RestTemplate rt;
	private EntityManager entityManager;
	
	
	@PostConstruct
	private void init() {
		try {
			migraBiogas();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void migraBiogas() throws Exception {
		this.rt = new RestTemplate();
		entityManager = emf.createEntityManager();
		 
		String content = readFile("/migrador/biometano.json", StandardCharsets.UTF_8);
		JSONObject config = new JSONObject(content);
		
		// System.out.println( config.toString(5) );
		
		JSONArray features = config.getJSONArray("features");
		for( int x=0; x < features.length(); x++  ) {
			JSONObject feature = features.getJSONObject(x);
			JSONObject attributes = feature.getJSONObject("attributes");
			JSONObject geometry = feature.getJSONObject("geometry");
			String nome = attributes.getString("Empresa");
			String cnpj = attributes.getString("CNPJ").replaceAll("[^0-9]","");
			double lat = geometry.getDouble("y");
			double lon = geometry.getDouble("x");
			JSONObject cnpjData = getCNPJData(cnpj);
			JSONObject estabelecimento = cnpjData.getJSONObject("estabelecimento");
			JSONObject estadoObj = estabelecimento.getJSONObject("estado");
			JSONObject cidadeObj = estabelecimento.getJSONObject("cidade");
			
			String razaoSocial = "";
			try { razaoSocial = cnpjData.getString("razao_social"); } catch (Exception e) { }
			
			String ddd = ""; 
			try { ddd = estabelecimento.getString("ddd1"); } catch (Exception e) { }
			
			String telefone = ""; 
			try { telefone = estabelecimento.getString("telefone1"); } catch (Exception e) { }
			
			String nomeFantasia = ""; 
			try { nomeFantasia = estabelecimento.getString("nome_fantasia"); } catch (Exception e) { }
			
			String tipoLogradouro = ""; 
			try { tipoLogradouro =	estabelecimento.getString("tipo_logradouro"); } catch (Exception e) { }
			
			String logradouro = ""; 
			try { logradouro = estabelecimento.getString("logradouro"); } catch (Exception e) { }
			
			String numero = "";
			try { numero = estabelecimento.getString("numero"); } catch (Exception e) { }
			
			String complemento = "";
			try { complemento =	estabelecimento.getString("complemento"); } catch (Exception e) { }
			
			String bairro = "";
			try { bairro = estabelecimento.getString("bairro"); } catch (Exception e) { }
			
			String cep = "";
			try { cep = estabelecimento.getString("cep"); } catch (Exception e) { }
			
			String email = ""; 
			try { email = estabelecimento.getString("email"); } catch (Exception e) { }
			
			String estado = "";
			try { estado = estadoObj.getString("nome"); } catch (Exception e) { }
			
			String estadoSigla = "";
			try { estadoSigla = estadoObj.getString("sigla"); } catch (Exception e) { }
			
			String cidade = ""; 
			try { cidade = cidadeObj.getString("nome"); } catch (Exception e) { }
			
			Empresa empresa = new Empresa();

			try {
				JSONArray inscricoesEstaduais = estabelecimento.getJSONArray("inscricoes_estaduais");
				JSONObject inscricaoEstadualObj = inscricoesEstaduais.getJSONObject(0);			
				String inscricaoEstadual = "";
				try { inscricaoEstadualObj.getString("inscricao_estadual"); } catch (Exception e) { }
				String inscricaoEstadualEstado = "";
				try { inscricaoEstadualObj.getJSONObject("estado").getString("sigla"); } catch (Exception e) { }
				empresa.setInscricaoEstadual(inscricaoEstadual);
			} catch (Exception e) { }
			
			empresa.setCnpj(cnpj);
			empresa.setNomeFatasia(nomeFantasia);
			empresa.setRazaoSocial(razaoSocial);
			empresa.setSituacao(1);
			empresa.setUsuarioInclusao(1);
			empresa.setUsuarioAlteracao(1);
			empresa.setDataInclusao( LocalDateTime.now() );
			empresa.setDataAlteracao( LocalDateTime.now() );
			
			Endereco endereco = new Endereco();
			endereco.setBairro(bairro);
			endereco.setCep(cep);
			endereco.setCidade(cidade);
			endereco.setComplemento(complemento);
			endereco.setEstado(estado);
			endereco.setLogradouro(tipoLogradouro + " " +logradouro);
			endereco.setNumero(numero);
			endereco.setTelefone("("+ddd+") " + telefone);
			endereco.setPais("Brasil");

			empresa.setEndereco(endereco);
			
			
			
			System.out.println( "[ " + attributes.getString("CNPJ") + " ] " + nome +  "  " + lat + "," + lon  );
			System.out.println("    > Razão Social    : " + razaoSocial );
			System.out.println("    > Nome Fantasia   : " + nomeFantasia );
			System.out.println("    > Email           : " + email );
			System.out.println("    > End. : " + tipoLogradouro + " " + logradouro + ", " + numero + " " + complemento + " - " + bairro + " " + cidade + " " + estado + " - " + estadoSigla + " CEP: " + cep);
			
			
			Empresa savedEmpresa = empresaRepository.save( empresa );

			EntityTransaction et = entityManager.getTransaction();
			et.begin();
			entityManager.createNativeQuery("UPDATE tb_enderecos set the_geom = ST_GeomFromText('POINT("+lon+" "+lat+")', 4326) where id_endereco = "+savedEmpresa.getEndereco().getId()+" ;").executeUpdate();
			et.commit();			
			
			// Excedido o limite máximo de 3 consultas por minuto
			Thread.sleep(1000 * 30);
			
			
		}
	}
	
	private void migraMetano() throws Exception {
		this.rt = new RestTemplate();
		entityManager = emf.createEntityManager();
		 
		String content = readFile("/migrador/biodiesel.json", StandardCharsets.UTF_8);
		JSONObject config = new JSONObject(content);
		
		// System.out.println( config.toString(5) );
		
		JSONArray features = config.getJSONArray("features");
		for( int x=0; x < features.length(); x++  ) {
			JSONObject feature = features.getJSONObject(x);
			JSONObject attributes = feature.getJSONObject("attributes");
			JSONObject geometry = feature.getJSONObject("geometry");
			String nome = attributes.getString("Nome");
			String cnpj = attributes.getString("CNPJ").replaceAll("[^0-9]","");
			double lat = geometry.getDouble("y");
			double lon = geometry.getDouble("x");
			JSONObject cnpjData = getCNPJData(cnpj);
			JSONObject estabelecimento = cnpjData.getJSONObject("estabelecimento");
			JSONObject estadoObj = estabelecimento.getJSONObject("estado");
			JSONObject cidadeObj = estabelecimento.getJSONObject("cidade");
			JSONArray inscricoesEstaduais = estabelecimento.getJSONArray("inscricoes_estaduais");
			JSONObject inscricaoEstadualObj = inscricoesEstaduais.getJSONObject(0);
			
			String razaoSocial = "";
			try { razaoSocial = cnpjData.getString("razao_social"); } catch (Exception e) { }
			
			String ddd = ""; 
			try { ddd = estabelecimento.getString("ddd1"); } catch (Exception e) { }
			
			String telefone = ""; 
			try { telefone = estabelecimento.getString("telefone1"); } catch (Exception e) { }
			
			String nomeFantasia = ""; 
			try { nomeFantasia = estabelecimento.getString("nome_fantasia"); } catch (Exception e) { }
			
			String tipoLogradouro = ""; 
			try { tipoLogradouro =	estabelecimento.getString("tipo_logradouro"); } catch (Exception e) { }
			
			String logradouro = ""; 
			try { logradouro = estabelecimento.getString("logradouro"); } catch (Exception e) { }
			
			String numero = "";
			try { numero = estabelecimento.getString("numero"); } catch (Exception e) { }
			
			String complemento = "";
			try { complemento =	estabelecimento.getString("complemento"); } catch (Exception e) { }
			
			String bairro = "";
			try { bairro = estabelecimento.getString("bairro"); } catch (Exception e) { }
			
			String cep = "";
			try { cep = estabelecimento.getString("cep"); } catch (Exception e) { }
			
			String email = ""; 
			try { email = estabelecimento.getString("email"); } catch (Exception e) { }
			
			String estado = "";
			try { estado = estadoObj.getString("nome"); } catch (Exception e) { }
			
			String estadoSigla = "";
			try { estadoSigla = estadoObj.getString("sigla"); } catch (Exception e) { }
			
			String cidade = ""; 
			try { cidade = cidadeObj.getString("nome"); } catch (Exception e) { }
			
			String inscricaoEstadual = "";
			try { inscricaoEstadualObj.getString("inscricao_estadual"); } catch (Exception e) { }
			
			String inscricaoEstadualEstado = "";
			try { inscricaoEstadualObj.getJSONObject("estado").getString("sigla"); } catch (Exception e) { }
			
			System.out.println( "[ " + attributes.getString("CNPJ") + " ] " + nome +  "  " + lat + "," + lon  );
			System.out.println("    > Razão Social    : " + razaoSocial );
			System.out.println("    > Nome Fantasia   : " + nomeFantasia );
			System.out.println("    > Email           : " + email );
			System.out.println("    > Inscr. Estadual : " + inscricaoEstadual + " (" + inscricaoEstadualEstado + ")");
			System.out.println("    > End. : " + tipoLogradouro + " " + logradouro + ", " + numero + " " + complemento + " - " + bairro + " " + cidade + " " + estado + " - " + estadoSigla + " CEP: " + cep);
			
			Empresa empresa = new Empresa();
			empresa.setCnpj(cnpj);
			empresa.setInscricaoEstadual(inscricaoEstadual);
			empresa.setNomeFatasia(nomeFantasia);
			empresa.setRazaoSocial(razaoSocial);
			empresa.setSituacao(1);
			empresa.setUsuarioInclusao(1);
			empresa.setUsuarioAlteracao(1);
			empresa.setDataInclusao( LocalDateTime.now() );
			empresa.setDataAlteracao( LocalDateTime.now() );
			
			Endereco endereco = new Endereco();
			endereco.setBairro(bairro);
			endereco.setCep(cep);
			endereco.setCidade(cidade);
			endereco.setComplemento(complemento);
			endereco.setEstado(estado);
			endereco.setLogradouro(tipoLogradouro + " " +logradouro);
			endereco.setNumero(numero);
			endereco.setTelefone("("+ddd+") " + telefone);
			endereco.setPais("Brasil");
			
			empresa.setEndereco(endereco);
			Empresa savedEmpresa = empresaRepository.save( empresa );
			
			EntityTransaction et = entityManager.getTransaction();
			et.begin();
			entityManager.createNativeQuery("UPDATE tb_enderecos set the_geom = ST_GeomFromText('POINT("+lon+" "+lat+")', 4326) where id_endereco = "+savedEmpresa.getEndereco().getId()+" ;").executeUpdate();
			et.commit();			
			
			// Excedido o limite máximo de 3 consultas por minuto
			Thread.sleep(1000 * 30);
			
		}

		/*
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
		entityManager.createNativeQuery("select  UpdateGeometrySRID( 'public','tb_enderecos', 'the_geom', 4326);").executeUpdate();
		et.commit();
		*/			

		
	}

	private JSONObject getCNPJData( String cnpj ) throws Exception {
		// https://publica.cnpj.ws/cnpj/02916265013300
		String url = "https://publica.cnpj.ws/cnpj/" + cnpj;
		String response = rt.getForObject(url, String.class);
		JSONObject resp = new JSONObject( response );
		return resp;
	}	
	
	private String readFile(String path, Charset encoding)  throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}  	
	
}
