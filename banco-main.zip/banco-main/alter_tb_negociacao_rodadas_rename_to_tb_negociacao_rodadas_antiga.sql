ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    RENAME TO tb_negociacao_rodadas_antiga;