CREATE TABLE public.tb_negociacao_rodadas_nova
(
    id_negociacao_rodada_nova serial NOT NULL,
    id_oferta integer NOT NULL,
    nr_rodada smallint NOT NULL,
    dh_rodada timestamp without time zone NOT NULL,
    observacao character varying(500),
    finalizada boolean NOT NULL DEFAULT false,
    CONSTRAINT pk_negociacao_rodadas_nova PRIMARY KEY (id_negociacao_rodada_nova),
    CONSTRAINT fk_negociacao_rodadas_nova_oferta FOREIGN KEY (id_oferta)
        REFERENCES public.tb_ofertas (id_oferta) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas_nova
    OWNER to postgres;

COMMENT ON TABLE public.tb_negociacao_rodadas_nova
    IS 'Rodadas de uma negociação.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.id_negociacao_rodada_nova
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.id_oferta
    IS 'Oferta sendo negociada.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.nr_rodada
    IS 'Número da rodada de negociação.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.dh_rodada
    IS 'Data/hora da rodada de negociação.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.observacao
    IS 'Campo livre para observações acerca da negociação.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.finalizada
    IS 'Flag indicando se a negociação se encerrou nessa rodada.';
	
COMMENT ON CONSTRAINT pk_negociacao_rodadas_nova ON public.tb_negociacao_rodadas_nova
    IS 'Chave primária da tabela tb_negociacao_rodadas_nova.';

COMMENT ON CONSTRAINT fk_negociacao_rodadas_nova_oferta ON public.tb_negociacao_rodadas_nova
    IS 'Chave estrangeira da coluna id_oferta.';