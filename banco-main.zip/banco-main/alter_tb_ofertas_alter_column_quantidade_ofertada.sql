ALTER TABLE IF EXISTS public.tb_ofertas
    ALTER COLUMN quantidade_ofertada DROP NOT NULL;
	