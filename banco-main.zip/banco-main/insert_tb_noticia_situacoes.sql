insert into public.tb_noticia_situacoes(id_noticia_situacao,ds_noticia_situacao) values (1,'Pendente');
insert into public.tb_noticia_situacoes(id_noticia_situacao,ds_noticia_situacao) values (2,'Aprovado');
insert into public.tb_noticia_situacoes(id_noticia_situacao,ds_noticia_situacao) values (3,'Reprovado');
