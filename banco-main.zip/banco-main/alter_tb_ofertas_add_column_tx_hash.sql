ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN tx_hash character varying(70);