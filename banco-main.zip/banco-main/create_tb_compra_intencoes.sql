-- Table: public.tb_compra_intencoes

-- DROP TABLE IF EXISTS public.tb_compra_intencoes;

CREATE TABLE IF NOT EXISTS public.tb_compra_intencoes
(
    id_compra_intencao serial NOT NULL,
    dt_compra_intencao timestamp without time zone NOT NULL,
    quantidade_pretendida numeric NOT NULL,
    atendida boolean NOT NULL DEFAULT false,
    id_compra integer,
    id_empresa integer NOT NULL,
    CONSTRAINT pk_compra_intencoes PRIMARY KEY (id_compra_intencao),
    CONSTRAINT fk_compra_intencoes_compra FOREIGN KEY (id_compra)
        REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_compra_intencoes_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_compra_intencoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_compra_intencoes
    IS 'Intenções de compra de biometano.';

COMMENT ON COLUMN public.tb_compra_intencoes.id_compra_intencao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_compra_intencoes.dt_compra_intencao
    IS 'Data da intenção de compra.';

COMMENT ON COLUMN public.tb_compra_intencoes.quantidade_pretendida
    IS 'Quantidade de material pretendido.';

COMMENT ON COLUMN public.tb_compra_intencoes.atendida
    IS 'Flag indicando se a intenção de compra resultou em compra.';

COMMENT ON COLUMN public.tb_compra_intencoes.id_compra
    IS 'Compra resultante da intenção de compra.';

COMMENT ON COLUMN public.tb_compra_intencoes.id_empresa
    IS 'Empresa com a intenção de compra.';
COMMENT ON CONSTRAINT pk_compra_intencoes ON public.tb_compra_intencoes
    IS 'Chave primária da tabela tb_compra_intencoes.';

COMMENT ON CONSTRAINT fk_compra_intencoes_compra ON public.tb_compra_intencoes
    IS 'Chave estrangeira da coluna id_compra.';
COMMENT ON CONSTRAINT fk_compra_intencoes_empresa ON public.tb_compra_intencoes
    IS 'Chave estrangeira da coluna id_empresa.';