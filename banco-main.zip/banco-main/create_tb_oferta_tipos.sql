-- Table: public.tb_oferta_tipos

-- DROP TABLE IF EXISTS public.tb_oferta_tipos;

CREATE TABLE IF NOT EXISTS public.tb_oferta_tipos
(
    id_oferta_tipo smallserial NOT NULL,
    ds_oferta_tipo character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_oferta_tipos PRIMARY KEY (id_oferta_tipo)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_oferta_tipos
    OWNER to postgres;

COMMENT ON TABLE public.tb_oferta_tipos
    IS 'Tipos possíveis de uma oferta.';

COMMENT ON COLUMN public.tb_oferta_tipos.id_oferta_tipo
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_oferta_tipos.ds_oferta_tipo
    IS 'Descrição do tipo de oferta.';
	
COMMENT ON CONSTRAINT pk_oferta_tipos ON public.tb_oferta_tipos
    IS 'Chave primária da tabela tb_oferta_tipos.';