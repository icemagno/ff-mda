ALTER TABLE IF EXISTS public.tb_usuarios
    ADD COLUMN email character varying(50);