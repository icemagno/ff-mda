CREATE TABLE public.tb_negociacao_propostas
(
    id_negociacao_proposta serial NOT NULL,
    id_negociacao_rodada_nova integer NOT NULL,
    id_negociacao_item smallint NOT NULL,
    valor_proposto character varying(50) NOT NULL,
    id_empresa_proponente integer NOT NULL,
    id_negociacao_proposta_anterior integer NOT NULL,
    CONSTRAINT pk_negociacao_proposta PRIMARY KEY (id_negociacao_proposta),
    CONSTRAINT fk_negociacao_propostas_negociacao_rodada_nova FOREIGN KEY (id_negociacao_rodada_nova)
        REFERENCES public.tb_negociacao_rodadas_nova (id_negociacao_rodada_nova) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_negociacao_propostas_negociacao_item FOREIGN KEY (id_negociacao_item)
        REFERENCES public.tb_negociacao_itens (id_negociacao_item) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_negociacao_propostas_empresa_proponente FOREIGN KEY (id_empresa_proponente)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_negociacao_propostas_proposta_anterior FOREIGN KEY (id_negociacao_proposta_anterior)
        REFERENCES public.tb_negociacao_propostas (id_negociacao_proposta) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE IF EXISTS public.tb_negociacao_propostas
    OWNER to postgres;

COMMENT ON TABLE public.tb_negociacao_propostas
    IS 'Propostas feitas em uma rodada de negociação.';

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_proposta
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_rodada_nova
    IS 'Rodada de negociação a que pertence a proposta sendo feita.';

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_item
    IS 'Item sendo negociado na proposta.';

COMMENT ON COLUMN public.tb_negociacao_propostas.valor_proposto
    IS 'Valor proposto do item.';

COMMENT ON COLUMN public.tb_negociacao_propostas.id_empresa_proponente
    IS 'Empresa que fez a proposta sobre o item.';

COMMENT ON COLUMN public.tb_negociacao_propostas.id_negociacao_proposta_anterior
    IS 'Proposta a que se está respondendo.';
	
COMMENT ON CONSTRAINT pk_negociacao_proposta ON public.tb_negociacao_propostas
    IS 'Chave primária da tabela tb_negociacao_proposta.';

COMMENT ON CONSTRAINT fk_negociacao_propostas_negociacao_rodada_nova ON public.tb_negociacao_propostas
    IS 'Chave estrangeira da coluna id_negociacao_rodada_nova.';
	
COMMENT ON CONSTRAINT fk_negociacao_propostas_negociacao_item ON public.tb_negociacao_propostas
    IS 'Chave estrangeira da coluna id_negociacao_item.';
	
COMMENT ON CONSTRAINT fk_negociacao_propostas_empresa_proponente ON public.tb_negociacao_propostas
    IS 'Chave estrangeira da coluna id_empresa_proponente.';
	
COMMENT ON CONSTRAINT fk_negociacao_propostas_proposta_anterior ON public.tb_negociacao_propostas
    IS 'Chave estrangeira da coluna id_negociacao_proposta_anterior.';