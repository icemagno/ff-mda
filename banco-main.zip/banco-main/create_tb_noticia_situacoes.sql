-- Table: public.tb_noticia_situacoes

-- DROP TABLE IF EXISTS public.tb_noticia_situacoes;

CREATE TABLE IF NOT EXISTS public.tb_noticia_situacoes
(
    id_noticia_situacao smallserial NOT NULL,
    ds_noticia_situacao character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_noticia_situacoes PRIMARY KEY (id_noticia_situacao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_noticia_situacoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_noticia_situacoes
    IS 'Situações possíveis de uma notícia.';

COMMENT ON COLUMN public.tb_noticia_situacoes.id_noticia_situacao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_noticia_situacoes.ds_noticia_situacao
    IS 'Descrição da situação da notícia.';
	
COMMENT ON CONSTRAINT pk_noticia_situacoes ON public.tb_noticia_situacoes
    IS 'Chave primária da tabela tb_noticia_situacoes.';