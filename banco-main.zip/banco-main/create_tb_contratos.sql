CREATE TABLE public.tb_contratos
(
    id_contrato serial NOT NULL,
    id_compra integer NOT NULL,
    documento bytea,
    CONSTRAINT pk_contratos PRIMARY KEY (id_contrato),
    CONSTRAINT fk_contratos_compra FOREIGN KEY (id_compra)
        REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE IF EXISTS public.tb_contratos
    OWNER to postgres;

COMMENT ON TABLE public.tb_contratos
    IS 'Contrato gerado a partir de uma compra.';

COMMENT ON COLUMN public.tb_contratos.id_contrato
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_contratos.id_compra
    IS 'Compra a que corresponde o contrato.';

COMMENT ON COLUMN public.tb_contratos.documento
    IS 'Arquivo contendo o contrato.';
	
COMMENT ON CONSTRAINT pk_contratos ON public.tb_contratos
    IS 'Chave primária da tabela tb_contratos.';

COMMENT ON CONSTRAINT fk_contratos_compra ON public.tb_contratos
    IS 'Chave estrangeira da coluna id_compra.';