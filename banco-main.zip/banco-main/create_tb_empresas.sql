-- Table: public.tb_empresas

-- DROP TABLE IF EXISTS public.tb_empresas;

CREATE TABLE IF NOT EXISTS public.tb_empresas
(
    id_empresa serial NOT NULL,
    cnpj character varying(14) COLLATE pg_catalog."default",
    razao_social character varying(100) COLLATE pg_catalog."default",
    nome_fantasia character varying(100) COLLATE pg_catalog."default",
    id_endereco integer,
    inscricao_estadual character varying(20) COLLATE pg_catalog."default",
    inscricao_municipal character varying(20) COLLATE pg_catalog."default",
    nicho_mercado character varying(100) COLLATE pg_catalog."default",
    servicos_produtos character varying(200) COLLATE pg_catalog."default",
    port_empr character varying(100) COLLATE pg_catalog."default",
    id_empresa_situacao smallint NOT NULL,
    id_usuario_inclusao integer NOT NULL,
    id_usuario_alteracao integer NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    dt_alteracao timestamp without time zone NOT NULL,
    CONSTRAINT pk_empresas PRIMARY KEY (id_empresa),
    CONSTRAINT fk_empresas_endereco FOREIGN KEY (id_endereco)
        REFERENCES public.tb_enderecos (id_endereco) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresas_situacao FOREIGN KEY (id_empresa_situacao)
        REFERENCES public.tb_empresa_situacoes (id_empresa_situacao) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresas_usuario_alteracao FOREIGN KEY (id_usuario_alteracao)
        REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresas_usuario_inclusao FOREIGN KEY (id_usuario_inclusao)
        REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_empresas
    OWNER to postgres;

COMMENT ON TABLE public.tb_empresas
    IS 'Empresas.';

COMMENT ON COLUMN public.tb_empresas.id_empresa
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_empresas.cnpj
    IS 'Cadastro Nacional da Pessoa Jurídica.';

COMMENT ON COLUMN public.tb_empresas.razao_social
    IS 'Razão social.';

COMMENT ON COLUMN public.tb_empresas.nome_fantasia
    IS 'Nome-fantasia.';

COMMENT ON COLUMN public.tb_empresas.id_endereco
    IS 'Endereço.';

COMMENT ON COLUMN public.tb_empresas.inscricao_estadual
    IS 'Inscrição estadual.';

COMMENT ON COLUMN public.tb_empresas.inscricao_municipal
    IS 'Inscrição municipal.';

COMMENT ON COLUMN public.tb_empresas.nicho_mercado
    IS 'Nicho de mercado.';

COMMENT ON COLUMN public.tb_empresas.servicos_produtos
    IS 'Descrição dos produtos/serviços oferecidos pela empresa? Flag do que a empresa oferece?';

COMMENT ON COLUMN public.tb_empresas.port_empr
    IS '???';

COMMENT ON COLUMN public.tb_empresas.id_empresa_situacao
    IS 'Situação da empresa.';

COMMENT ON COLUMN public.tb_empresas.id_usuario_inclusao
    IS 'Usuário responsável pela inclusão da empresa.';

COMMENT ON COLUMN public.tb_empresas.id_usuario_alteracao
    IS 'Usuário responsável pela alteração da empresa.';

COMMENT ON COLUMN public.tb_empresas.dt_inclusao
    IS 'Data/hora da inclusão da empresa.';

COMMENT ON COLUMN public.tb_empresas.dt_alteracao
    IS 'Data/hora da alteração da empresa.';
	
COMMENT ON CONSTRAINT pk_empresas ON public.tb_empresas
    IS 'Chave primária da tabela tb_empresas.';

COMMENT ON CONSTRAINT fk_empresas_endereco ON public.tb_empresas
    IS 'Chave estrangeira da coluna id_endereco.';
	
COMMENT ON CONSTRAINT fk_empresas_situacao ON public.tb_empresas
    IS 'Chave estrangeira da coluna id_empresa_situacao';
	
COMMENT ON CONSTRAINT fk_empresas_usuario_alteracao ON public.tb_empresas
    IS 'Chave estrangeira da coluna id_usuario_alteracao.';
	
COMMENT ON CONSTRAINT fk_empresas_usuario_inclusao ON public.tb_empresas
    IS 'Chave estrangeira da coluna id_usuario_inclusao.';