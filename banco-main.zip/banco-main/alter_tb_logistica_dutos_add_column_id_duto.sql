ALTER TABLE IF EXISTS public.tb_logistica_dutos DROP COLUMN IF EXISTS nome_duto;

ALTER TABLE IF EXISTS public.tb_logistica_dutos
    RENAME diametro_duto TO id_duto;

ALTER TABLE public.tb_logistica_dutos
    ALTER COLUMN id_duto TYPE integer;
	
COMMENT ON COLUMN public.tb_logistica_dutos.id_duto
    IS 'Duto utilizado na logística.';
	
ALTER TABLE IF EXISTS public.tb_logistica_dutos
    ADD CONSTRAINT fk_logistica_dutos_duto FOREIGN KEY (id_duto)
    REFERENCES public.tb_dutos (id_duto) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_logistica_dutos_duto ON public.tb_logistica_dutos
    IS 'Chave estrangeira da coluna id_duto.';