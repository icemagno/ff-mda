ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN quantidade_comprada DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ALTER COLUMN valor_compra DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN quantidade_certificados integer;

COMMENT ON COLUMN public.tb_compras.quantidade_certificados
    IS 'Quantidade de certificados comprados.';

ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN valor_certificados numeric;

COMMENT ON COLUMN public.tb_compras.valor_certificados
    IS 'Valor (em moeda corrente) dos certificados comprados.';