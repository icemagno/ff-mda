ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    RENAME id_compra TO id_oferta;

COMMENT ON COLUMN public.tb_negociacao_rodadas.id_oferta
    IS 'Oferta sendo negociada.';

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    ADD COLUMN finalizada boolean NOT NULL DEFAULT false;
	
ALTER TABLE IF EXISTS public.tb_negociacao_rodadas DROP CONSTRAINT IF EXISTS fk_negociacao_rodadas_compra;

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    ADD CONSTRAINT fk_negociacao_rodadas_oferta FOREIGN KEY (id_oferta)
    REFERENCES public.tb_ofertas (id_oferta) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_negociacao_rodadas_oferta ON public.tb_negociacao_rodadas
    IS 'Chave estrangeira da coluna id_oferta.';