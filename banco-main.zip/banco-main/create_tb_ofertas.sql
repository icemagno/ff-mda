-- Table: public.tb_ofertas

-- DROP TABLE IF EXISTS public.tb_ofertas;

CREATE TABLE IF NOT EXISTS public.tb_ofertas
(
    id_oferta serial NOT NULL,
    dt_oferta timestamp without time zone NOT NULL,
    quantidade_ofertada numeric NOT NULL,
    atendida boolean NOT NULL DEFAULT false,
    id_compra integer,
    id_empresa integer NOT NULL,
    CONSTRAINT pk_oferta PRIMARY KEY (id_oferta),
    CONSTRAINT fk_ofertas_compra FOREIGN KEY (id_compra)
        REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_ofertas_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_ofertas
    OWNER to postgres;

COMMENT ON TABLE public.tb_ofertas
    IS 'Ofertas de biometano.';

COMMENT ON COLUMN public.tb_ofertas.id_oferta
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_ofertas.dt_oferta
    IS 'Data da oferta.';

COMMENT ON COLUMN public.tb_ofertas.quantidade_ofertada
    IS 'Quantidade de material ofertado.';

COMMENT ON COLUMN public.tb_ofertas.atendida
    IS 'Flag indicando se a oferta resultou em compra.';

COMMENT ON COLUMN public.tb_ofertas.id_compra
    IS 'Compra resultante da oferta.';

COMMENT ON COLUMN public.tb_ofertas.id_empresa
    IS 'Empresa com a oferta.';
COMMENT ON CONSTRAINT pk_oferta ON public.tb_ofertas
    IS 'Chave primária da tabela tb_ofertas.';

COMMENT ON CONSTRAINT fk_ofertas_compra ON public.tb_ofertas
    IS 'Chave estrangeira da coluna id_compra.';
	
COMMENT ON CONSTRAINT fk_ofertas_empresa ON public.tb_ofertas
    IS 'Chave estrangeira para a coluna id_empresa.';