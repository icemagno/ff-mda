ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN valor_frete numeric;