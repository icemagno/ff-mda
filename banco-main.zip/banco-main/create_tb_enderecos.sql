-- Table: public.tb_enderecos

-- DROP TABLE IF EXISTS public.tb_enderecos;

CREATE TABLE IF NOT EXISTS public.tb_enderecos
(
    id_endereco serial NOT NULL,
    logradouro character varying COLLATE pg_catalog."default",
    numero character varying COLLATE pg_catalog."default",
    complemento character varying COLLATE pg_catalog."default",
    bairro character varying COLLATE pg_catalog."default",
    cep character varying COLLATE pg_catalog."default",
    cidade character varying COLLATE pg_catalog."default",
    estado character varying COLLATE pg_catalog."default",
    pais character varying COLLATE pg_catalog."default",
    telefone character varying COLLATE pg_catalog."default",
    email character varying COLLATE pg_catalog."default",
    the_geom geometry,
    CONSTRAINT pk_enderecos PRIMARY KEY (id_endereco)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_enderecos
    OWNER to postgres;

COMMENT ON TABLE public.tb_enderecos
    IS 'Endereços de empresas e representantes.';

COMMENT ON COLUMN public.tb_enderecos.id_endereco
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_enderecos.logradouro
    IS 'Rua, Avenida, Praça, etc.';

COMMENT ON COLUMN public.tb_enderecos.numero
    IS 'Número do logradouro.';

COMMENT ON COLUMN public.tb_enderecos.complemento
    IS 'Apto, bloco, casa, quadra, etc.';

COMMENT ON COLUMN public.tb_enderecos.bairro
    IS 'Bairro.';

COMMENT ON COLUMN public.tb_enderecos.cep
    IS 'Código de Endereçamento Postal (CEP).';

COMMENT ON COLUMN public.tb_enderecos.estado
    IS 'Unidade da Federação (Pode ser a partir de uma tabela de domínio)';

COMMENT ON COLUMN public.tb_enderecos.pais
    IS 'País.';

COMMENT ON COLUMN public.tb_enderecos.telefone
    IS 'Telefone(s) com DDD, separados por algum caracter (talvez /)';

COMMENT ON COLUMN public.tb_enderecos.email
    IS 'Endereços de correio eletrônico, separados por algum caracter (talvez /)';

COMMENT ON COLUMN public.tb_enderecos.the_geom
    IS 'Dado georreferenciado: localização do endereço.';
	
COMMENT ON CONSTRAINT pk_enderecos ON public.tb_enderecos
    IS 'Chave primária da tabela tb_enderecos.';