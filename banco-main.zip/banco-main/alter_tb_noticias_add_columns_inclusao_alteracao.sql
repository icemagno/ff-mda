ALTER TABLE IF EXISTS public.tb_noticias
    ADD COLUMN id_usuario_inclusao integer NOT NULL;

COMMENT ON COLUMN public.tb_noticias.id_usuario_inclusao
    IS 'Usuário responsável pela inclusão da notícia.';

ALTER TABLE IF EXISTS public.tb_noticias
    ADD COLUMN dt_inclusao timestamp without time zone NOT NULL;

COMMENT ON COLUMN public.tb_noticias.dt_inclusao
    IS 'Data/hora da inclusão da notícia.';

ALTER TABLE IF EXISTS public.tb_noticias
    ADD COLUMN id_usuario_alteracao integer;

COMMENT ON COLUMN public.tb_noticias.id_usuario_alteracao
    IS 'Usuário responsável pela alteração da notícia.';

ALTER TABLE IF EXISTS public.tb_noticias
    ADD COLUMN dt_alteracao timestamp without time zone;

COMMENT ON COLUMN public.tb_noticias.dt_alteracao
    IS 'Data/hora da alteração da notícia.';
	
ALTER TABLE IF EXISTS public.tb_noticias
    ADD CONSTRAINT fk_noticias_usuario_inclusao FOREIGN KEY (id_usuario_inclusao)
    REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_noticias_usuario_inclusao ON public.tb_noticias
    IS 'Chave estrangeira da coluna id_usuario_inclusao.';

ALTER TABLE IF EXISTS public.tb_noticias
    ADD CONSTRAINT fk_noticias_usuario_alteracao FOREIGN KEY (id_usuario_alteracao)
    REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_noticias_usuario_alteracao ON public.tb_noticias
    IS 'Chave estrangeira da coluna id_usuario_alteracao.';