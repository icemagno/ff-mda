ALTER TABLE IF EXISTS public.tb_negociacao_rodadas_nova
    ADD COLUMN id_empresa_proponente integer NOT NULL;

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas_nova
    ADD COLUMN id_negociacao_rodada_anterior integer NOT NULL;

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas_nova
    ADD CONSTRAINT fk_negociacao_rodadas_nova_empresa_proponente FOREIGN KEY (id_empresa_proponente)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID;

ALTER TABLE IF EXISTS public.tb_negociacao_rodadas_nova
    ADD CONSTRAINT fk_negociacao_rodadas_nova_proposta_anterior FOREIGN KEY (id_negociacao_rodada_anterior)
        REFERENCES public.tb_negociacao_rodadas_nova (id_negociacao_rodada_nova) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID;

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.id_empresa_proponente
    IS 'Empresa que fez a proposta sobre o item.';

COMMENT ON COLUMN public.tb_negociacao_rodadas_nova.id_negociacao_rodada_anterior
    IS 'Rodada anterior na negociação.';

COMMENT ON CONSTRAINT fk_negociacao_rodadas_nova_empresa_proponente ON public.tb_negociacao_rodadas_nova
    IS 'Chave estrangeira da coluna id_empresa_proponente.';
	
COMMENT ON CONSTRAINT fk_negociacao_rodadas_nova_proposta_anterior ON public.tb_negociacao_rodadas_nova
    IS 'Chave estrangeira da coluna id_negociacao_rodada_anterior.';