ALTER TABLE IF EXISTS public.tb_logistica_dutos
    ADD COLUMN id_duto_tipo smallint;

COMMENT ON COLUMN public.tb_logistica_dutos.id_duto_tipo
    IS 'Tipo de duto: distribuição ou transporte.';
	
ALTER TABLE IF EXISTS public.tb_logistica_dutos
    ADD CONSTRAINT fk_logistica_dutos_tipo_duto FOREIGN KEY (id_duto_tipo)
    REFERENCES public.tb_duto_tipos (id_duto_tipo) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_logistica_dutos_tipo_duto ON public.tb_logistica_dutos
    IS 'Chave estrangeira da coluna id_duto_tipo.';