ALTER TABLE IF EXISTS public.tb_empresas
    ALTER COLUMN id_empresa_tipo DROP NOT NULL;