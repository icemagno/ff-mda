ALTER TABLE IF EXISTS public.tb_negociacao_rodadas
    ALTER COLUMN id_negociacao_rodada_anterior DROP NOT NULL;