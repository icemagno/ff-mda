-- Table: public.tb_empresa_situacoes

-- DROP TABLE IF EXISTS public.tb_empresa_situacoes;

CREATE TABLE IF NOT EXISTS public.tb_empresa_situacoes
(
    id_empresa_situacao smallserial NOT NULL,
    ds_empresa_situacao character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_empresa_situacoes PRIMARY KEY (id_empresa_situacao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_empresa_situacoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_empresa_situacoes
    IS 'Situações possíveis de uma empresa.';

COMMENT ON COLUMN public.tb_empresa_situacoes.id_empresa_situacao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_empresa_situacoes.ds_empresa_situacao
    IS 'Descrição da situação da empresa.';
COMMENT ON CONSTRAINT pk_empresa_situacoes ON public.tb_empresa_situacoes
    IS 'Chave primária da tabela tb_empresa_situacoes.';