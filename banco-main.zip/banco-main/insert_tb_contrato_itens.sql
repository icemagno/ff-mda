insert into public.tb_contrato_itens(id_contrato_item,ds_contrato_item) values (1,'PRESSAO_FORNECIMENTO');
insert into public.tb_contrato_itens(id_contrato_item,ds_contrato_item) values (2,'VAZAO_FORNECIMENTO');
insert into public.tb_contrato_itens(id_contrato_item,ds_contrato_item) values (3,'PODER_CALORIFICO_REFERENCIA');
insert into public.tb_contrato_itens(id_contrato_item,ds_contrato_item) values (4,'PODER_CALORIFICO_SUPERIOR');
insert into public.tb_contrato_itens(id_contrato_item,ds_contrato_item) values (5,'PONTO_DE_ENTREGA');
insert into public.tb_contrato_itens(id_contrato_item,ds_contrato_item) values (6,'QUALIDADE_DO_GAS');
