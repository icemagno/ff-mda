ALTER TABLE IF EXISTS public.tb_empresas
    ADD COLUMN id_empresa_tipo smallint NOT NULL;

COMMENT ON COLUMN public.tb_empresas.id_empresa_tipo
    IS 'Tipo de empresa.';
	
ALTER TABLE IF EXISTS public.tb_empresas
    ADD CONSTRAINT fk_empresas_tipo FOREIGN KEY (id_empresa_tipo)
    REFERENCES public.tb_empresa_tipos (id_empresa_tipo) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_empresas_tipo ON public.tb_empresas
    IS 'Chave estrangeira da coluna id_empresa_tipo.';