-- Table: public.tb_noticia_tipos

-- DROP TABLE IF EXISTS public.tb_noticia_tipos;

CREATE TABLE IF NOT EXISTS public.tb_noticia_tipos
(
    id_noticia_tipo smallserial NOT NULL,
    ds_noticia_tipo character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_noticia_tipos PRIMARY KEY (id_noticia_tipo)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_noticia_tipos
    OWNER to postgres;

COMMENT ON TABLE public.tb_noticia_tipos
    IS 'Tipos de notícia.';

COMMENT ON COLUMN public.tb_noticia_tipos.id_noticia_tipo
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_noticia_tipos.ds_noticia_tipo
    IS 'Descrição do tipo de notícia.';
COMMENT ON CONSTRAINT pk_noticia_tipos ON public.tb_noticia_tipos
    IS 'Chave primária da tabela tb_noticia_tipos.';