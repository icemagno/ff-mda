-- Table: public.tb_empresa_representantes

-- DROP TABLE IF EXISTS public.tb_empresa_representantes;

CREATE TABLE IF NOT EXISTS public.tb_empresa_representantes
(
    id_empresa_representante serial NOT NULL,
    id_empresa integer NOT NULL,
    id_representante integer NOT NULL,
    id_representante_situacao smallint NOT NULL,
    id_usuario_inclusao integer NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    id_usuario_alteracao integer NOT NULL,
    dt_alteracao timestamp without time zone NOT NULL,
    CONSTRAINT pk_empresa_representantes PRIMARY KEY (id_empresa_representante),
    CONSTRAINT fk_empresa_representantes_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresa_representantes_representante FOREIGN KEY (id_representante)
        REFERENCES public.tb_representantes (id_representante) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresa_representantes_situacao FOREIGN KEY (id_representante_situacao)
        REFERENCES public.tb_representante_situacoes (id_representante_situacao) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresa_representantes_usuario_alteracao FOREIGN KEY (id_usuario_alteracao)
        REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_empresa_representantes_usuario_inclusao FOREIGN KEY (id_usuario_inclusao)
        REFERENCES public.tb_usuarios (id_usuario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_empresa_representantes
    OWNER to postgres;

COMMENT ON TABLE public.tb_empresa_representantes
    IS 'Representantes das empresas.';

COMMENT ON COLUMN public.tb_empresa_representantes.id_empresa_representante
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_empresa_representantes.id_empresa
    IS 'Empresa representada.';

COMMENT ON COLUMN public.tb_empresa_representantes.id_representante
    IS 'Representante da empresa.';

COMMENT ON COLUMN public.tb_empresa_representantes.id_representante_situacao
    IS 'Situação do representante.';

COMMENT ON COLUMN public.tb_empresa_representantes.id_usuario_inclusao
    IS 'Usuário responsável pela inclusão do representante.';

COMMENT ON COLUMN public.tb_empresa_representantes.dt_inclusao
    IS 'Data/hora da inclusão do representante.';

COMMENT ON COLUMN public.tb_empresa_representantes.id_usuario_alteracao
    IS 'Usuário responsável pela alteração do representante.';

COMMENT ON COLUMN public.tb_empresa_representantes.dt_alteracao
    IS 'Data/hora da alteração do representante.';
	
COMMENT ON CONSTRAINT pk_empresa_representantes ON public.tb_empresa_representantes
    IS 'Chave primária da tabela tb_empresa_representantes.';

COMMENT ON CONSTRAINT fk_empresa_representantes_empresa ON public.tb_empresa_representantes
    IS 'Chave estrangeira da coluna id_empresa.';

COMMENT ON CONSTRAINT fk_empresa_representantes_representante ON public.tb_empresa_representantes
    IS 'Chave estrangeira da coluna id_representante.';
	
COMMENT ON CONSTRAINT fk_empresa_representantes_situacao ON public.tb_empresa_representantes
    IS 'Chave estrangeira da coluna id_representante_situacao';
	
COMMENT ON CONSTRAINT fk_empresa_representantes_usuario_alteracao ON public.tb_empresa_representantes
    IS 'Chave estrangeira da coluna id_usuario_alteracao.';
	
COMMENT ON CONSTRAINT fk_empresa_representantes_usuario_inclusao ON public.tb_empresa_representantes
    IS 'Chave estrangeira da coluna id_usuario_inclusao.';