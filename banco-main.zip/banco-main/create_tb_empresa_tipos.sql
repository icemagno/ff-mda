-- Table: public.tb_empresa_tipos

-- DROP TABLE IF EXISTS public.tb_empresa_tipos;

CREATE TABLE IF NOT EXISTS public.tb_empresa_tipos
(
    id_empresa_tipo smallserial NOT NULL,
    ds_empresa_tipo character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_empresa_tipos PRIMARY KEY (id_empresa_tipo)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_empresa_tipos
    OWNER to postgres;

COMMENT ON TABLE public.tb_empresa_tipos
    IS 'Tipos possíveis de uma empresa.';

COMMENT ON COLUMN public.tb_empresa_tipos.id_empresa_tipo
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_empresa_tipos.ds_empresa_tipo
    IS 'Descrição do tipo de empresa.';
	
COMMENT ON CONSTRAINT pk_empresa_tipos ON public.tb_empresa_tipos
    IS 'Chave primária da tabela tb_empresa_tipos.';