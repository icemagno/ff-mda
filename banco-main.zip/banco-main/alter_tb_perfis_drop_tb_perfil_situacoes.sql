
ALTER TABLE IF EXISTS public.tb_perfis DROP CONSTRAINT IF EXISTS fk_perfis_perfil_situacao;

ALTER TABLE IF EXISTS public.tb_perfis DROP COLUMN IF EXISTS id_perfil_situacao;

ALTER TABLE IF EXISTS public.tb_perfis
    ADD COLUMN ativo boolean;
	
DROP TABLE public.tb_perfil_situacoes;
