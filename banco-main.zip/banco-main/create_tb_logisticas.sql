-- Table: public.tb_logisticas

-- DROP TABLE IF EXISTS public.tb_logisticas;

CREATE TABLE IF NOT EXISTS public.tb_logisticas
(
    id_logistica serial NOT NULL,
    tipo_transporte boolean NOT NULL,
    id_empresa_transportadora integer NOT NULL,
    CONSTRAINT pk_logisticas PRIMARY KEY (id_logistica),
    CONSTRAINT fk_logisticas_empresa_transportadora FOREIGN KEY (id_empresa_transportadora)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_logisticas
    OWNER to postgres;

COMMENT ON TABLE public.tb_logisticas
    IS 'Logística de transporte.';

COMMENT ON COLUMN public.tb_logisticas.id_logistica
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_logisticas.tipo_transporte
    IS 'Flag para tipo de transporte: true = GNC, false = duto.';

COMMENT ON COLUMN public.tb_logisticas.id_empresa_transportadora
    IS 'Empresa responsável pelo transporte.';
COMMENT ON CONSTRAINT pk_logisticas ON public.tb_logisticas
    IS 'Chave primária da tabela tb_logisticas.';

COMMENT ON CONSTRAINT fk_logisticas_empresa_transportadora ON public.tb_logisticas
    IS 'Chave estrangeira da coluna id_empresa_transportadora.';