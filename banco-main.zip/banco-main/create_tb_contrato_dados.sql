-- Table: public.tb_contrato_dados

-- DROP TABLE IF EXISTS public.tb_contrato_dados;

CREATE TABLE IF NOT EXISTS public.tb_contrato_dados
(
    id_contrato_dado serial NOT NULL,
    id_contrato integer NOT NULL,
    id_contrato_item smallint NOT NULL,
    valor_contrato_dado character varying(500) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_contrato_dado PRIMARY KEY (id_contrato_dado),
    CONSTRAINT fk_contrato_dados_contrato_item FOREIGN KEY (id_contrato_item)
        REFERENCES public.tb_contrato_itens (id_contrato_item) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_contrato_dados_contrato FOREIGN KEY (id_contrato)
        REFERENCES public.tb_contratos (id_contrato) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_contrato_dados
    OWNER to postgres;

COMMENT ON TABLE public.tb_contrato_dados
    IS 'Dados variáveis de um contrato.';

COMMENT ON COLUMN public.tb_contrato_dados.id_contrato_dado
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_contrato_dados.id_contrato
    IS 'Contrato cujos ítens estão sendo preenchidos.';

COMMENT ON COLUMN public.tb_contrato_dados.id_contrato_item
    IS 'Item de contrato sendo preenchido.';

COMMENT ON COLUMN public.tb_contrato_dados.valor_contrato_dado
    IS 'Valor do item.';
	
COMMENT ON CONSTRAINT pk_contrato_dado ON public.tb_contrato_dados
    IS 'Chave primária da tabela tb_contrato_dados.';

COMMENT ON CONSTRAINT fk_contrato_dados_contrato_item ON public.tb_contrato_dados
    IS 'Chave estrangeira da coluna id_contrato_item.';
	
COMMENT ON CONSTRAINT fk_contrato_dados_contrato ON public.tb_contrato_dados
    IS 'Chave estrangeira da coluna id_contrato.';