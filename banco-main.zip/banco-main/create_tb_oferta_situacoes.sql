-- Table: public.tb_oferta_situacoes

-- DROP TABLE IF EXISTS public.tb_oferta_situacoes;

CREATE TABLE IF NOT EXISTS public.tb_oferta_situacoes
(
    id_oferta_situacao smallserial NOT NULL,
    ds_oferta_situacao character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_oferta_situacoes PRIMARY KEY (id_oferta_situacao)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_oferta_situacoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_oferta_situacoes
    IS 'Situações possíveis de uma oferta.';

COMMENT ON COLUMN public.tb_oferta_situacoes.id_oferta_situacao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_oferta_situacoes.ds_oferta_situacao
    IS 'Descrição da situação da oferta.';
COMMENT ON CONSTRAINT pk_oferta_situacoes ON public.tb_oferta_situacoes
    IS 'Chave primária da tabela tb_oferta_situacoes.';