-- Table: public.tb_contrato_itens

-- DROP TABLE IF EXISTS public.tb_contrato_itens;

CREATE TABLE IF NOT EXISTS public.tb_contrato_itens
(
    id_contrato_item smallserial NOT NULL,
    ds_contrato_item character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_contrato_itens PRIMARY KEY (id_contrato_item)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_contrato_itens
    OWNER to postgres;

COMMENT ON TABLE public.tb_contrato_itens
    IS 'Ítens de contrato de uma compra.';

COMMENT ON COLUMN public.tb_contrato_itens.id_contrato_item
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_contrato_itens.ds_contrato_item
    IS 'Descrição do item de contrato.';
	
COMMENT ON CONSTRAINT pk_contrato_itens ON public.tb_contrato_itens
    IS 'Chave primária da tabela tb_contrato_itens.';