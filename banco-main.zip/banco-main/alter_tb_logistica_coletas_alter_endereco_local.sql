ALTER TABLE IF EXISTS public.tb_logistica_coletas
    RENAME id_endereco TO id_local;

COMMENT ON COLUMN public.tb_logistica_coletas.id_local
    IS 'Local correspondente ao ponto de coleta.';
	
ALTER TABLE IF EXISTS public.tb_logistica_coletas DROP CONSTRAINT IF EXISTS fk_logistica_coletas_endereco;

ALTER TABLE IF EXISTS public.tb_logistica_coletas
    ADD CONSTRAINT fk_logistica_coletas_local FOREIGN KEY (id_local)
    REFERENCES public.tb_locais (id_local) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_logistica_coletas_local ON public.tb_logistica_coletas
    IS 'Chave esrangeira da coluna id_local.';