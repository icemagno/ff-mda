ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN exibe_nome_empresa boolean;

COMMENT ON COLUMN public.tb_ofertas.exibe_nome_empresa
    IS 'No caso de uma oferta pública, true exibe o nome da empresa, false não exibe.';