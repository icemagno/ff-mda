ALTER TABLE IF EXISTS public.tb_compras
    ADD COLUMN id_compra_aditivada integer;

COMMENT ON COLUMN public.tb_compras.id_compra_aditivada
    IS 'Compra cujo contrato recebeu um aditivo.';
	
ALTER TABLE IF EXISTS public.tb_compras
    ADD CONSTRAINT fk_compras_compra_aditivada FOREIGN KEY (id_compra_aditivada)
    REFERENCES public.tb_compras (id_compra) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_compras_compra_aditivada ON public.tb_compras
    IS 'Chave estrangeira da coluna id_compra_aditivada.';