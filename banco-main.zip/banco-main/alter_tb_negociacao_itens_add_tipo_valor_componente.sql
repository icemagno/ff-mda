ALTER TABLE IF EXISTS public.tb_negociacao_itens
    ADD COLUMN tipo_valor character varying(30);

ALTER TABLE IF EXISTS public.tb_negociacao_itens
    ADD COLUMN componente character varying(50);