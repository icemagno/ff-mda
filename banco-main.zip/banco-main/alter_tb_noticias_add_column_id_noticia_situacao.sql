ALTER TABLE IF EXISTS public.tb_noticias
    ADD COLUMN id_noticia_situacao smallint NOT NULL;

COMMENT ON COLUMN public.tb_noticias.id_noticia_situacao
    IS 'Situação em que se encontra a notícia.';

ALTER TABLE IF EXISTS public.tb_noticias
    ADD CONSTRAINT fk_noticias_situacao FOREIGN KEY (id_noticia_situacao)
    REFERENCES public.tb_noticia_situacoes (id_noticia_situacao) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

COMMENT ON CONSTRAINT fk_noticias_situacao ON public.tb_noticias
    IS 'Chave estrangeira da coluna id_noticia_situacao.';