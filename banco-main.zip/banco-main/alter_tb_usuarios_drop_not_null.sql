ALTER TABLE IF EXISTS public.tb_usuarios
    ALTER COLUMN id_usuario_inclusao DROP NOT NULL;

ALTER TABLE IF EXISTS public.tb_usuarios
    ALTER COLUMN dt_inclusao DROP NOT NULL;