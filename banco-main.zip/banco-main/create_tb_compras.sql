-- Table: public.tb_compras

-- DROP TABLE IF EXISTS public.tb_compras;

CREATE TABLE IF NOT EXISTS public.tb_compras
(
    id_compra serial NOT NULL,
    id_empresa_compradora integer NOT NULL,
    sazonalidade boolean NOT NULL,
    id_local_entrega integer,
    id_local_retirada integer,
    entrega_concluida boolean NOT NULL,
    quantidade_comprada numeric NOT NULL,
    valor_compra numeric NOT NULL,
    id_empresa_fornecedora integer,
    contrato bytea,
    CONSTRAINT pk_compras PRIMARY KEY (id_compra),
    CONSTRAINT fk_compras_empresa_compradora FOREIGN KEY (id_empresa_compradora)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_compras_empresa_fornecedora FOREIGN KEY (id_empresa_fornecedora)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_compras_local_entrega FOREIGN KEY (id_local_entrega)
        REFERENCES public.tb_locais (id_local) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_compras_local_retirada FOREIGN KEY (id_local_retirada)
        REFERENCES public.tb_locais (id_local) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_compras
    OWNER to postgres;

COMMENT ON TABLE public.tb_compras
    IS 'Compras de biometano.';

COMMENT ON COLUMN public.tb_compras.id_compra
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_compras.id_empresa_compradora
    IS 'Empresa que está fazendo a compra.';

COMMENT ON COLUMN public.tb_compras.sazonalidade
    IS 'Flag para sazonalidade: true = sazonal; false = contínua.';

COMMENT ON COLUMN public.tb_compras.id_local_entrega
    IS 'Local de entrega do material comprado.';

COMMENT ON COLUMN public.tb_compras.id_local_retirada
    IS 'Local de retirada do material comprado.';

COMMENT ON COLUMN public.tb_compras.entrega_concluida
    IS 'Flag indicando se o material comprado já foi todo entregue ou não.';

COMMENT ON COLUMN public.tb_compras.quantidade_comprada
    IS 'Quantidade de material comprado.';

COMMENT ON COLUMN public.tb_compras.valor_compra
    IS 'Valor (em moeda corrente) da compra.';

COMMENT ON COLUMN public.tb_compras.id_empresa_fornecedora
    IS 'Empresa que está fornecendo o produto.';

COMMENT ON COLUMN public.tb_compras.contrato
    IS 'Arquivo contendo o contrato.';
COMMENT ON CONSTRAINT pk_compras ON public.tb_compras
    IS 'Chave primária da tabela tb_compras.';

COMMENT ON CONSTRAINT fk_compras_empresa_compradora ON public.tb_compras
    IS 'Chave estrangeira da coluna id_empresa_compradora.';
COMMENT ON CONSTRAINT fk_compras_empresa_fornecedora ON public.tb_compras
    IS 'Chave estrangeira da coluna id_empresa_fornecedora.';
COMMENT ON CONSTRAINT fk_compras_local_entrega ON public.tb_compras
    IS 'Chave estrangeira da coluna id_local_entrega.';
COMMENT ON CONSTRAINT fk_compras_local_retirada ON public.tb_compras
    IS 'Chave estrangeira da coluna id_local_retirada.';