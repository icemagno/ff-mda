-- Table: public.tb_producoes

-- DROP TABLE IF EXISTS public.tb_producoes;

CREATE TABLE IF NOT EXISTS public.tb_producoes
(
    id_producao serial NOT NULL,
    dt_producao timestamp without time zone NOT NULL,
    quantidade_produzida numeric NOT NULL,
    id_empresa_fornecedora integer NOT NULL,
    CONSTRAINT pk_producoes PRIMARY KEY (id_producao),
    CONSTRAINT fk_producao_empresa_fornecedora FOREIGN KEY (id_empresa_fornecedora)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_producoes
    OWNER to postgres;

COMMENT ON TABLE public.tb_producoes
    IS 'Produção de biometano.';

COMMENT ON COLUMN public.tb_producoes.id_producao
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_producoes.dt_producao
    IS 'Data de produção do material.';

COMMENT ON COLUMN public.tb_producoes.quantidade_produzida
    IS 'Quantidade de material produzido.';

COMMENT ON COLUMN public.tb_producoes.id_empresa_fornecedora
    IS 'Empresa fornecedora da produção.';
COMMENT ON CONSTRAINT pk_producoes ON public.tb_producoes
    IS 'Chave primária da tabela tb_producoes.';

COMMENT ON CONSTRAINT fk_producao_empresa_fornecedora ON public.tb_producoes
    IS 'Chave estrangeira da coluna id_empresa_fornecedora.';