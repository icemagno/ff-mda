ALTER TABLE IF EXISTS public.tb_ofertas
    ADD COLUMN dt_validade timestamp without time zone;

COMMENT ON COLUMN public.tb_ofertas.dt_validade
    IS 'Validade da oferta.';