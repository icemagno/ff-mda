ALTER TABLE IF EXISTS public.tb_empresas
    ADD COLUMN area_atuacao geometry;