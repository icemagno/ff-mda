-- Table: public.tb_noticias

-- DROP TABLE IF EXISTS public.tb_noticias;

CREATE TABLE IF NOT EXISTS public.tb_noticias
(
    id_noticia serial NOT NULL,
    dt_noticia timestamp without time zone NOT NULL,
    texto_noticia text COLLATE pg_catalog."default" NOT NULL,
    id_empresa integer NOT NULL,
    id_noticia_tipo smallint NOT NULL,
    CONSTRAINT pk_noticias PRIMARY KEY (id_noticia),
    CONSTRAINT fk_noticias_empresa FOREIGN KEY (id_empresa)
        REFERENCES public.tb_empresas (id_empresa) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_noticias_noticia_tipo FOREIGN KEY (id_noticia_tipo)
        REFERENCES public.tb_noticia_tipos (id_noticia_tipo) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tb_noticias
    OWNER to postgres;

COMMENT ON TABLE public.tb_noticias
    IS 'Notícias das empresas.';

COMMENT ON COLUMN public.tb_noticias.id_noticia
    IS 'Identificador.';

COMMENT ON COLUMN public.tb_noticias.dt_noticia
    IS 'Data da notícia';

COMMENT ON COLUMN public.tb_noticias.texto_noticia
    IS 'Texto da notícia.';

COMMENT ON COLUMN public.tb_noticias.id_empresa
    IS 'Empresa relacionada (ou responsável?) pela notícia.';

COMMENT ON COLUMN public.tb_noticias.id_noticia_tipo
    IS 'Tipo de notícia.';
COMMENT ON CONSTRAINT pk_noticias ON public.tb_noticias
    IS 'Chave primária da tabela tb_noticias.';

COMMENT ON CONSTRAINT fk_noticias_empresa ON public.tb_noticias
    IS 'Chave estrangeira da coluna id_empresa.';
COMMENT ON CONSTRAINT fk_noticias_noticia_tipo ON public.tb_noticias
    IS 'Chave estrangeira do campo id_noticia_tipo.';