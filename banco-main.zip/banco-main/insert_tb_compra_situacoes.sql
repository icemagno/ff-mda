insert into public.tb_compra_situacoes(id_compra_situacao,ds_compra_situacao) values (1,'CP_CONFIRMADA');
insert into public.tb_compra_situacoes(id_compra_situacao,ds_compra_situacao) values (2,'CP_CONTRATADA');
insert into public.tb_compra_situacoes(id_compra_situacao,ds_compra_situacao) values (3,'CP_EM_ANDAMENTO');
insert into public.tb_compra_situacoes(id_compra_situacao,ds_compra_situacao) values (4,'CP_FINALIZADA');
insert into public.tb_compra_situacoes(id_compra_situacao,ds_compra_situacao) values (5,'CP_CANCELADA');
